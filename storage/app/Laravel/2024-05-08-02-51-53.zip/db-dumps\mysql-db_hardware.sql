
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `brands` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `abbrevation` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `brands` WRITE;
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
INSERT INTO `brands` VALUES (1,'MYS','1','MYS','2024-05-08 03:10:36','2024-05-08 03:10:36'),(2,'TTN','2','TTN','2024-05-08 03:10:36','2024-05-08 03:10:36'),(3,'BTY','3','BTY','2024-05-08 03:10:36','2024-05-08 03:10:36'),(4,'UIO','4','UIO','2024-05-08 03:10:36','2024-05-08 03:10:36'),(5,'RTYR','5','RTYR','2024-05-08 03:10:36','2024-05-08 03:10:36');
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `category_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category_products` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `category_products` WRITE;
/*!40000 ALTER TABLE `category_products` DISABLE KEYS */;
INSERT INTO `category_products` VALUES (1,'Pinturas','Pinturas','2024-05-08 03:11:23','2024-05-08 03:11:23'),(2,'Madera','Madera','2024-05-08 03:11:23','2024-05-08 03:11:23'),(3,'Ceramica','Ceramica','2024-05-08 03:11:23','2024-05-08 03:11:23'),(4,'Tubos','Tubos','2024-05-08 03:11:23','2024-05-08 03:11:23'),(5,'Tornillos','Tornillos','2024-05-08 03:11:23','2024-05-08 03:11:23');
/*!40000 ALTER TABLE `category_products` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `countries` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` tinyint NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `credit_note_sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `credit_note_sales` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `date_invoice` date NOT NULL,
  `sellers` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payments_methods` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gross_totals` decimal(8,2) NOT NULL,
  `taxes_total` decimal(8,2) NOT NULL,
  `net_total` decimal(8,2) NOT NULL,
  `date_credit_notes` date NOT NULL,
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `clients_id` bigint unsigned NOT NULL,
  `sale_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `credit_note_sales_clients_id_foreign` (`clients_id`),
  KEY `credit_note_sales_sale_id_foreign` (`sale_id`),
  CONSTRAINT `credit_note_sales_clients_id_foreign` FOREIGN KEY (`clients_id`) REFERENCES `people` (`id`),
  CONSTRAINT `credit_note_sales_sale_id_foreign` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `credit_note_sales` WRITE;
/*!40000 ALTER TABLE `credit_note_sales` DISABLE KEYS */;
/*!40000 ALTER TABLE `credit_note_sales` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `credit_note_sales_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `credit_note_sales_product` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `credit_note_sales_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `references` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` int NOT NULL,
  `selling_price` decimal(10,2) NOT NULL,
  `discounts` decimal(8,2) NOT NULL,
  `tax` decimal(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `credit_note_sales_product_credit_note_sales_id_foreign` (`credit_note_sales_id`),
  KEY `credit_note_sales_product_product_id_foreign` (`product_id`),
  CONSTRAINT `credit_note_sales_product_credit_note_sales_id_foreign` FOREIGN KEY (`credit_note_sales_id`) REFERENCES `credit_note_sales` (`id`) ON DELETE CASCADE,
  CONSTRAINT `credit_note_sales_product_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `credit_note_sales_product` WRITE;
/*!40000 ALTER TABLE `credit_note_sales_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `credit_note_sales_product` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `debit_note_suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `debit_note_suppliers` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `debit_note_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_invoice` date NOT NULL,
  `detail_purchase_id` bigint unsigned NOT NULL,
  `users_id` bigint unsigned NOT NULL,
  `purchase_suppliers_id` int unsigned NOT NULL,
  `quantity` int NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total` decimal(8,2) NOT NULL,
  `net_total` decimal(20,2) NOT NULL,
  `gross_total` decimal(20,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `debit_note_suppliers_detail_purchase_id_foreign` (`detail_purchase_id`),
  KEY `debit_note_suppliers_users_id_foreign` (`users_id`),
  KEY `debit_note_suppliers_purchase_suppliers_id_foreign` (`purchase_suppliers_id`),
  CONSTRAINT `debit_note_suppliers_detail_purchase_id_foreign` FOREIGN KEY (`detail_purchase_id`) REFERENCES `detail_purchase` (`id`) ON DELETE CASCADE,
  CONSTRAINT `debit_note_suppliers_purchase_suppliers_id_foreign` FOREIGN KEY (`purchase_suppliers_id`) REFERENCES `purchase_suppliers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `debit_note_suppliers_users_id_foreign` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `debit_note_suppliers` WRITE;
/*!40000 ALTER TABLE `debit_note_suppliers` DISABLE KEYS */;
/*!40000 ALTER TABLE `debit_note_suppliers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `departments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` tinyint NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `countries_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `departments_countries_id_foreign` (`countries_id`),
  CONSTRAINT `departments_countries_id_foreign` FOREIGN KEY (`countries_id`) REFERENCES `countries` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `detail_purchase`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detail_purchase` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `note` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price_unit` decimal(20,2) NOT NULL,
  `product_tax` decimal(20,2) NOT NULL,
  `quantity_units` double NOT NULL,
  `date_purchase` date NOT NULL,
  `form_of_payment` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gross_total` decimal(20,2) NOT NULL,
  `total_tax` decimal(20,2) NOT NULL,
  `net_total` decimal(20,2) NOT NULL,
  `total_value` decimal(20,2) NOT NULL,
  `discount_total` decimal(20,2) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `method_of_payment` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `purchase_suppliers_id` int unsigned NOT NULL,
  `products_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `detail_purchase_purchase_suppliers_id_foreign` (`purchase_suppliers_id`),
  KEY `detail_purchase_products_id_foreign` (`products_id`),
  CONSTRAINT `detail_purchase_products_id_foreign` FOREIGN KEY (`products_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `detail_purchase_purchase_suppliers_id_foreign` FOREIGN KEY (`purchase_suppliers_id`) REFERENCES `purchase_suppliers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `detail_purchase` WRITE;
/*!40000 ALTER TABLE `detail_purchase` DISABLE KEYS */;
INSERT INTO `detail_purchase` VALUES (1,NULL,'.',10.00,5.00,10,'2024-05-07','tarjeta',100.00,5.00,105.00,105.00,0.00,1,'cuotas',1,3,'2024-05-08 03:19:35','2024-05-08 03:19:35'),(2,NULL,'.',90.00,5.00,10,'2024-05-07','tarjeta',900.00,45.00,945.00,945.00,0.00,1,'cuotas',1,1,'2024-05-08 03:19:35','2024-05-08 03:19:35'),(3,NULL,'.',78.00,0.00,7,'2024-05-07','tarjeta',546.00,0.00,546.00,546.00,0.00,1,'cuotas',1,2,'2024-05-08 03:19:35','2024-05-08 03:19:35');
/*!40000 ALTER TABLE `detail_purchase` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
INSERT INTO `jobs` VALUES (8,'default','{\"uuid\":\"da6e8bc2-350d-4ca3-ad2f-bcc7f2e41678\",\"displayName\":\"App\\\\Jobs\\\\BackupProcess\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"App\\\\Jobs\\\\BackupProcess\",\"command\":\"O:22:\\\"App\\\\Jobs\\\\BackupProcess\\\":0:{}\"}}',1,1715136712,1715136712,1715136712);
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `measurement_units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `measurement_units` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1089 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `measurement_units` WRITE;
/*!40000 ALTER TABLE `measurement_units` DISABLE KEYS */;
INSERT INTO `measurement_units` VALUES (1,'10','grupo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(2,'11','equipar','2024-05-08 03:10:11','2024-05-08 03:10:11'),(3,'13','ración','2024-05-08 03:10:11','2024-05-08 03:10:11'),(4,'14','Disparo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(5,'15','palo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(6,'16','tambor de ciento quince kg','2024-05-08 03:10:11','2024-05-08 03:10:11'),(7,'17','tambor de cien libras','2024-05-08 03:10:11','2024-05-08 03:10:11'),(8,'18','tambor de cincuenta y cinco galones (US)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(9,'19','camión cisterna','2024-05-08 03:10:11','2024-05-08 03:10:11'),(10,'20','contenedor de veinte pies','2024-05-08 03:10:11','2024-05-08 03:10:11'),(11,'21','contenedor de cuarenta pies','2024-05-08 03:10:11','2024-05-08 03:10:11'),(12,'22','decilitro por gramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(13,'23','gramo por centímetro cúbico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(14,'24','libra teórica','2024-05-08 03:10:11','2024-05-08 03:10:11'),(15,'25','gramo por centímetro cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(16,'26','tonelada real','2024-05-08 03:10:11','2024-05-08 03:10:11'),(17,'27','tonelada teórica','2024-05-08 03:10:11','2024-05-08 03:10:11'),(18,'28','kilogramo por metro cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(19,'29','libra por mil pies cuadrados','2024-05-08 03:10:11','2024-05-08 03:10:11'),(20,'30','Día de potencia del caballo por tonelada métrica seca al aire.','2024-05-08 03:10:11','2024-05-08 03:10:11'),(21,'31','coger peso','2024-05-08 03:10:11','2024-05-08 03:10:11'),(22,'32','kilogramo por aire seco tonelada métrica','2024-05-08 03:10:11','2024-05-08 03:10:11'),(23,'33','kilopascales metros cuadrados por gramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(24,'34','kilopascales por milímetro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(25,'35','mililitros por centímetro cuadrado segundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(26,'36','pies cúbicos por minuto por pie cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(27,'37','onza por pie cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(28,'38','onzas por pie cuadrado por 0,01 pulgadas','2024-05-08 03:10:11','2024-05-08 03:10:11'),(29,'40','mililitro por segundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(30,'41','mililitro por minuto','2024-05-08 03:10:11','2024-05-08 03:10:11'),(31,'43','bolsa súper a granel','2024-05-08 03:10:11','2024-05-08 03:10:11'),(32,'44','bolsa a granel de quinientos kg','2024-05-08 03:10:11','2024-05-08 03:10:11'),(33,'45','bolsa a granel de trescientos kg','2024-05-08 03:10:11','2024-05-08 03:10:11'),(34,'46','bolsa a granel de cincuenta libras','2024-05-08 03:10:11','2024-05-08 03:10:11'),(35,'47','bolsa de cincuenta libras','2024-05-08 03:10:11','2024-05-08 03:10:11'),(36,'48','carga de automóviles a granel','2024-05-08 03:10:11','2024-05-08 03:10:11'),(37,'53','kilogramos teóricos','2024-05-08 03:10:11','2024-05-08 03:10:11'),(38,'54','tonelada teórica','2024-05-08 03:10:11','2024-05-08 03:10:11'),(39,'56','sitas','2024-05-08 03:10:11','2024-05-08 03:10:11'),(40,'57','malla','2024-05-08 03:10:11','2024-05-08 03:10:11'),(41,'58','kilogramo neto','2024-05-08 03:10:11','2024-05-08 03:10:11'),(42,'59','parte por millón','2024-05-08 03:10:11','2024-05-08 03:10:11'),(43,'60','porcentaje de peso','2024-05-08 03:10:11','2024-05-08 03:10:11'),(44,'61','parte por billón (US)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(45,'62','porcentaje por 1000 horas','2024-05-08 03:10:11','2024-05-08 03:10:11'),(46,'63','tasa de fracaso en el tiempo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(47,'64','libra por pulgada cuadrada, calibre','2024-05-08 03:10:11','2024-05-08 03:10:11'),(48,'66','Oersted','2024-05-08 03:10:11','2024-05-08 03:10:11'),(49,'69','prueba de escala específica','2024-05-08 03:10:11','2024-05-08 03:10:11'),(50,'71','voltio amperio por libra','2024-05-08 03:10:11','2024-05-08 03:10:11'),(51,'72','vatio por libra','2024-05-08 03:10:11','2024-05-08 03:10:11'),(52,'73','amperio tum por centímetro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(53,'74','milipascal','2024-05-08 03:10:11','2024-05-08 03:10:11'),(54,'76','gauss','2024-05-08 03:10:11','2024-05-08 03:10:11'),(55,'77','mili pulgadas','2024-05-08 03:10:11','2024-05-08 03:10:11'),(56,'78','kilogauss','2024-05-08 03:10:11','2024-05-08 03:10:11'),(57,'80','libras por pulgada cuadrada absoluta','2024-05-08 03:10:11','2024-05-08 03:10:11'),(58,'81','Enrique','2024-05-08 03:10:11','2024-05-08 03:10:11'),(59,'84','kilopound por pulgada cuadrada','2024-05-08 03:10:11','2024-05-08 03:10:11'),(60,'85','fuerza libra pie','2024-05-08 03:10:11','2024-05-08 03:10:11'),(61,'87','libra por pie cúbico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(62,'89','equilibrio','2024-05-08 03:10:11','2024-05-08 03:10:11'),(63,'90','Saybold segundo universal','2024-05-08 03:10:11','2024-05-08 03:10:11'),(64,'91','alimenta','2024-05-08 03:10:11','2024-05-08 03:10:11'),(65,'92','calorías por centímetro cúbico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(66,'93','calorías por gramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(67,'94','unidad','2024-05-08 03:10:11','2024-05-08 03:10:11'),(68,'95','veinte mil galones (US) de carros','2024-05-08 03:10:11','2024-05-08 03:10:11'),(69,'96','diez mil galones (US) de carros','2024-05-08 03:10:11','2024-05-08 03:10:11'),(70,'97','tambor de diez kg','2024-05-08 03:10:11','2024-05-08 03:10:11'),(71,'98','tambor de quince kg','2024-05-08 03:10:11','2024-05-08 03:10:11'),(72,'04','spray pequeño','2024-05-08 03:10:11','2024-05-08 03:10:11'),(73,'05','levantar','2024-05-08 03:10:11','2024-05-08 03:10:11'),(74,'08','Lote calor','2024-05-08 03:10:11','2024-05-08 03:10:11'),(75,'1A','milla de coche','2024-05-08 03:10:11','2024-05-08 03:10:11'),(76,'1B','recuento de coches','2024-05-08 03:10:11','2024-05-08 03:10:11'),(77,'1C','recuento de locomotoras','2024-05-08 03:10:11','2024-05-08 03:10:11'),(78,'1D','recuento de cabos','2024-05-08 03:10:11','2024-05-08 03:10:11'),(79,'1E','carro vacio','2024-05-08 03:10:11','2024-05-08 03:10:11'),(80,'1F','millas de tren','2024-05-08 03:10:11','2024-05-08 03:10:11'),(81,'1G','uso de combustible galón (US)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(82,'1H','milla del caboose','2024-05-08 03:10:11','2024-05-08 03:10:11'),(83,'1I','tipo de interés fijo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(84,'1J','tonelada milla','2024-05-08 03:10:11','2024-05-08 03:10:11'),(85,'1K','milla locomotora','2024-05-08 03:10:11','2024-05-08 03:10:11'),(86,'1L','recuento total de coches','2024-05-08 03:10:11','2024-05-08 03:10:11'),(87,'1M','milla de coche total','2024-05-08 03:10:11','2024-05-08 03:10:11'),(88,'1X','cuarto de milla','2024-05-08 03:10:11','2024-05-08 03:10:11'),(89,'2A','radianes por segundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(90,'2B','radianes por segundo al cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(91,'2C','Röntgen','2024-05-08 03:10:11','2024-05-08 03:10:11'),(92,'2I','Unidad térmica británica por hora.','2024-05-08 03:10:11','2024-05-08 03:10:11'),(93,'2J','centímetro cúbico por segundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(94,'2K','pie cúbico por hora','2024-05-08 03:10:11','2024-05-08 03:10:11'),(95,'2L','pie cúbico por minuto','2024-05-08 03:10:11','2024-05-08 03:10:11'),(96,'2M','centímetro por segundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(97,'2N','decibel','2024-05-08 03:10:11','2024-05-08 03:10:11'),(98,'2P','kilobyte','2024-05-08 03:10:11','2024-05-08 03:10:11'),(99,'2Q','kilobecquerel','2024-05-08 03:10:11','2024-05-08 03:10:11'),(100,'2R','kilocurie','2024-05-08 03:10:11','2024-05-08 03:10:11'),(101,'2U','megagramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(102,'2V','megagramo por hora','2024-05-08 03:10:11','2024-05-08 03:10:11'),(103,'2W','compartimiento','2024-05-08 03:10:11','2024-05-08 03:10:11'),(104,'2X','metro por minuto','2024-05-08 03:10:11','2024-05-08 03:10:11'),(105,'2Y','milliröntgen','2024-05-08 03:10:11','2024-05-08 03:10:11'),(106,'2Z','milivoltios','2024-05-08 03:10:11','2024-05-08 03:10:11'),(107,'3B','megajulio','2024-05-08 03:10:11','2024-05-08 03:10:11'),(108,'3C','manmonth','2024-05-08 03:10:11','2024-05-08 03:10:11'),(109,'3E','libra por libra de producto','2024-05-08 03:10:11','2024-05-08 03:10:11'),(110,'3G','libra por pieza de producto','2024-05-08 03:10:11','2024-05-08 03:10:11'),(111,'3H','kilogramo por kilogramo de producto','2024-05-08 03:10:11','2024-05-08 03:10:11'),(112,'3I','kilogramo por pieza de producto','2024-05-08 03:10:11','2024-05-08 03:10:11'),(113,'4A','bobina','2024-05-08 03:10:11','2024-05-08 03:10:11'),(114,'4B','gorra','2024-05-08 03:10:11','2024-05-08 03:10:11'),(115,'4C','centistokes','2024-05-08 03:10:11','2024-05-08 03:10:11'),(116,'4E','paquete de veinte','2024-05-08 03:10:11','2024-05-08 03:10:11'),(117,'4G','microlitro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(118,'4H','micrometro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(119,'4K','miliamperio','2024-05-08 03:10:11','2024-05-08 03:10:11'),(120,'4L','megabyte','2024-05-08 03:10:11','2024-05-08 03:10:11'),(121,'4M','miligramo por hora','2024-05-08 03:10:11','2024-05-08 03:10:11'),(122,'4N','megabecquerel','2024-05-08 03:10:11','2024-05-08 03:10:11'),(123,'4O','microfarad','2024-05-08 03:10:11','2024-05-08 03:10:11'),(124,'4P','newton por metro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(125,'4Q','onza pulgada','2024-05-08 03:10:11','2024-05-08 03:10:11'),(126,'4R','pie onza','2024-05-08 03:10:11','2024-05-08 03:10:11'),(127,'4T','picofarad','2024-05-08 03:10:11','2024-05-08 03:10:11'),(128,'4U','libra por hora','2024-05-08 03:10:11','2024-05-08 03:10:11'),(129,'4W','tonelada (US) por hora','2024-05-08 03:10:11','2024-05-08 03:10:11'),(130,'4X','kilolitro por hora','2024-05-08 03:10:11','2024-05-08 03:10:11'),(131,'BTU','Unidad Térmica Británica','2024-05-08 03:10:11','2024-05-08 03:10:11'),(132,'BUA','bushel (EE. UU.)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(133,'BUI','bushel (Reino Unido)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(134,'BW','peso base','2024-05-08 03:10:11','2024-05-08 03:10:11'),(135,'BX','caja','2024-05-08 03:10:11','2024-05-08 03:10:11'),(136,'BZ','millones de BTUs','2024-05-08 03:10:11','2024-05-08 03:10:11'),(137,'C0','llamada','2024-05-08 03:10:11','2024-05-08 03:10:11'),(138,'C1','producto compuesto libra (peso total)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(139,'C10','millifarad','2024-05-08 03:10:11','2024-05-08 03:10:11'),(140,'C11','miligal','2024-05-08 03:10:11','2024-05-08 03:10:11'),(141,'C12','miligramo por metro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(142,'C13','miligray','2024-05-08 03:10:11','2024-05-08 03:10:11'),(143,'C14','milihenry','2024-05-08 03:10:11','2024-05-08 03:10:11'),(144,'C15','milijoule','2024-05-08 03:10:11','2024-05-08 03:10:11'),(145,'C16','milímetro por segundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(146,'C17','milímetro cuadrado por segundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(147,'C18','milimol','2024-05-08 03:10:11','2024-05-08 03:10:11'),(148,'C19','mol por kilogramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(149,'C2','carset','2024-05-08 03:10:11','2024-05-08 03:10:11'),(150,'C20','millinewton','2024-05-08 03:10:11','2024-05-08 03:10:11'),(151,'C22','millinewton por metro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(152,'C23','medidor de miliohm','2024-05-08 03:10:11','2024-05-08 03:10:11'),(153,'C24','segundo milipascal','2024-05-08 03:10:11','2024-05-08 03:10:11'),(154,'C25','miliradian','2024-05-08 03:10:11','2024-05-08 03:10:11'),(155,'C26','milisegundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(156,'C27','milisiemens','2024-05-08 03:10:11','2024-05-08 03:10:11'),(157,'C28','milisievert','2024-05-08 03:10:11','2024-05-08 03:10:11'),(158,'C29','millitesla','2024-05-08 03:10:11','2024-05-08 03:10:11'),(159,'C3','microvoltios por metro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(160,'INK','pulgada cuadrada','2024-05-08 03:10:11','2024-05-08 03:10:11'),(161,'INQ','pulgada en cubos','2024-05-08 03:10:11','2024-05-08 03:10:11'),(162,'IP','póliza de seguros','2024-05-08 03:10:11','2024-05-08 03:10:11'),(163,'IT','conteo por centímetro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(164,'IU','pulgada por segundo (velocidad lineal)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(165,'IV','pulgada por segundo al cuadrado (aceleración)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(166,'J2','julios por kilogramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(167,'JB','jumbo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(168,'JE','joule por kelvin','2024-05-08 03:10:11','2024-05-08 03:10:11'),(169,'JG','jarra','2024-05-08 03:10:11','2024-05-08 03:10:11'),(170,'JK','megajulio por kilogramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(171,'JM','megajulio por metro cúbico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(172,'JO','articulación','2024-05-08 03:10:11','2024-05-08 03:10:11'),(173,'JOU','joule','2024-05-08 03:10:11','2024-05-08 03:10:11'),(174,'JR','tarro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(175,'K1','demanda de kilovatios','2024-05-08 03:10:11','2024-05-08 03:10:11'),(176,'K2','kilovoltios amperios reactivos de demanda','2024-05-08 03:10:11','2024-05-08 03:10:11'),(177,'K3','kilovoltio amperio hora reactiva','2024-05-08 03:10:11','2024-05-08 03:10:11'),(178,'K5','amperios kilovoltios (reactivos)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(179,'K6','kilolitro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(180,'KA','pastel','2024-05-08 03:10:11','2024-05-08 03:10:11'),(181,'KB','kilocharacter','2024-05-08 03:10:11','2024-05-08 03:10:11'),(182,'KBA','kilobar','2024-05-08 03:10:11','2024-05-08 03:10:11'),(183,'KD','kilogramo decimal','2024-05-08 03:10:11','2024-05-08 03:10:11'),(184,'KEL','kelvin','2024-05-08 03:10:11','2024-05-08 03:10:11'),(185,'KF','kilopacket','2024-05-08 03:10:11','2024-05-08 03:10:11'),(186,'KG','barrilete','2024-05-08 03:10:11','2024-05-08 03:10:11'),(187,'KGM','kilogramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(188,'KGS','kilogramo por segundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(189,'KHZ','kilohercio','2024-05-08 03:10:11','2024-05-08 03:10:11'),(190,'5A','barril por minuto','2024-05-08 03:10:11','2024-05-08 03:10:11'),(191,'5B','lote','2024-05-08 03:10:11','2024-05-08 03:10:11'),(192,'5C','galón (US) por mil','2024-05-08 03:10:11','2024-05-08 03:10:11'),(193,'5E','MMSCF / día','2024-05-08 03:10:11','2024-05-08 03:10:11'),(194,'5F','libras por mil','2024-05-08 03:10:11','2024-05-08 03:10:11'),(195,'5G','bomba','2024-05-08 03:10:11','2024-05-08 03:10:11'),(196,'5H','escenario','2024-05-08 03:10:11','2024-05-08 03:10:11'),(197,'5I','pie cúbico estándar','2024-05-08 03:10:11','2024-05-08 03:10:11'),(198,'5J','potencia hidráulica de caballos','2024-05-08 03:10:11','2024-05-08 03:10:11'),(199,'5K','contar por minuto','2024-05-08 03:10:11','2024-05-08 03:10:11'),(200,'5P','nivel sismico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(201,'5Q','260nfor sismica','2024-05-08 03:10:11','2024-05-08 03:10:11'),(202,'A1','15 calorías C','2024-05-08 03:10:11','2024-05-08 03:10:11'),(203,'A10','amperio metro cuadrado por joule segundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(204,'A11','Ã ¥ ngström','2024-05-08 03:10:11','2024-05-08 03:10:11'),(205,'A12','unidad astronómica','2024-05-08 03:10:11','2024-05-08 03:10:11'),(206,'A13','attojoule','2024-05-08 03:10:11','2024-05-08 03:10:11'),(207,'A14','granero','2024-05-08 03:10:11','2024-05-08 03:10:11'),(208,'A15','granero por electrón voltio','2024-05-08 03:10:11','2024-05-08 03:10:11'),(209,'A16','granero por voltio de electrones esteradiano,','2024-05-08 03:10:11','2024-05-08 03:10:11'),(210,'A17','granero por sterdian','2024-05-08 03:10:11','2024-05-08 03:10:11'),(211,'A18','becquerel por kilogramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(212,'A19','becquerel por metro cúbico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(213,'A2','amperio por centímetro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(214,'A20','Unidad térmica británica por segundo pie cuadrado grado Rankin','2024-05-08 03:10:11','2024-05-08 03:10:11'),(215,'A21','Unidad térmica británica por libra grado Rankin','2024-05-08 03:10:11','2024-05-08 03:10:11'),(216,'A22','Unidad térmica británica por segundo pie grado Rankin','2024-05-08 03:10:11','2024-05-08 03:10:11'),(217,'A23','Unidad térmica británica por hora pie cuadrado grado Rankin','2024-05-08 03:10:11','2024-05-08 03:10:11'),(218,'A24','candela por metro cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(219,'A25','cheval vapeur','2024-05-08 03:10:11','2024-05-08 03:10:11'),(220,'A26','medidor de culombio','2024-05-08 03:10:11','2024-05-08 03:10:11'),(221,'A27','medidor de culombio al cuadrado por voltio','2024-05-08 03:10:11','2024-05-08 03:10:11'),(222,'A28','Coulomb por centímetro cúbico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(223,'A29','Coulomb por metro cúbico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(224,'A3','amperio por milímetro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(225,'A30','Coulomb por milímetro cúbico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(226,'A31','Coulomb por kilogramo segundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(227,'A32','Coulomb por mol','2024-05-08 03:10:11','2024-05-08 03:10:11'),(228,'A33','Coulomb por centímetro cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(229,'A34','Coulomb por metro cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(230,'A35','Coulomb por milímetro cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(231,'A36','centímetro cúbico por mol','2024-05-08 03:10:11','2024-05-08 03:10:11'),(232,'A37','261nformaci cúbico por mol','2024-05-08 03:10:11','2024-05-08 03:10:11'),(233,'A38','metro cúbico por coulomb','2024-05-08 03:10:11','2024-05-08 03:10:11'),(234,'A39','metro cúbico por kilogramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(235,'A4','amperio por centímetro cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(236,'A40','metro cúbico por mol','2024-05-08 03:10:11','2024-05-08 03:10:11'),(237,'A41','amperio por metro cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(238,'A42','curie por kilogramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(239,'A43','tonelaje de peso muerto','2024-05-08 03:10:11','2024-05-08 03:10:11'),(240,'A44','decalitro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(241,'A45','decámetro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(242,'A47','decitex','2024-05-08 03:10:11','2024-05-08 03:10:11'),(243,'A48','grado Rankin','2024-05-08 03:10:11','2024-05-08 03:10:11'),(244,'A49','negador','2024-05-08 03:10:11','2024-05-08 03:10:11'),(245,'A5','amperio metro cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(246,'A50','dyn segundo por centímetro cúbico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(247,'A51','dina segundo por centímetro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(248,'A52','dina segundo por centímetro al quinto','2024-05-08 03:10:11','2024-05-08 03:10:11'),(249,'A53','electronvolt','2024-05-08 03:10:11','2024-05-08 03:10:11'),(250,'A54','electronvoltio por metro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(251,'A55','metro electronvolt cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(252,'A56','electronvoltio de metro cuadrado por kilogramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(253,'A57','ergio','2024-05-08 03:10:11','2024-05-08 03:10:11'),(254,'A58','erg por centímetro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(255,'A6','amperio por metro cuadrado kelvin al cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(256,'A60','erg por centímetro cúbico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(257,'A61','erg por gramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(258,'A62','erg por gramo de segundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(259,'A63','erg por segundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(260,'A64','erg por segundo centímetro cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(261,'A65','erg por centímetro cuadrado segundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(262,'A66','erg centímetro cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(263,'A67','ergímetro cuadrado por gramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(264,'A68','exajulio','2024-05-08 03:10:11','2024-05-08 03:10:11'),(265,'A69','faradio por metro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(266,'A7','amperio por milímetro cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(267,'A70','femtojoule','2024-05-08 03:10:11','2024-05-08 03:10:11'),(268,'A71','femtometro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(269,'A73','pie por segundo al cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(270,'A74','pie-fuerza de la libra por segundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(271,'A75','tonelada de carga','2024-05-08 03:10:11','2024-05-08 03:10:11'),(272,'A76','galón','2024-05-08 03:10:11','2024-05-08 03:10:11'),(273,'A77','Unidad de desplazamiento CGS gaussiana','2024-05-08 03:10:11','2024-05-08 03:10:11'),(274,'A78','Unidad gaussiana CGS de corriente eléctrica.','2024-05-08 03:10:11','2024-05-08 03:10:11'),(275,'A79','Unidad Gaussian CGS de carga eléctrica.','2024-05-08 03:10:11','2024-05-08 03:10:11'),(276,'A8','amperio segundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(277,'A80','Unidad Gaussian CGS de intensidad de campo eléctrico.','2024-05-08 03:10:11','2024-05-08 03:10:11'),(278,'A81','Unidad Gaussian CGS de polarización eléctrica.','2024-05-08 03:10:11','2024-05-08 03:10:11'),(279,'A82','Unidad Gaussian CGS de potencial eléctrico.','2024-05-08 03:10:11','2024-05-08 03:10:11'),(280,'A83','Unidad Gaussiana CGS de magnetización.','2024-05-08 03:10:11','2024-05-08 03:10:11'),(281,'A84','gigacoulomb por metro cúbico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(282,'A85','Gigaelectronvolt','2024-05-08 03:10:11','2024-05-08 03:10:11'),(283,'A86','gigahercios','2024-05-08 03:10:11','2024-05-08 03:10:11'),(284,'A87','gigaohm','2024-05-08 03:10:11','2024-05-08 03:10:11'),(285,'A88','medidor de gigaohm','2024-05-08 03:10:11','2024-05-08 03:10:11'),(286,'A89','gigapascal','2024-05-08 03:10:11','2024-05-08 03:10:11'),(287,'A9','tarifa','2024-05-08 03:10:11','2024-05-08 03:10:11'),(288,'A90','gigavatios','2024-05-08 03:10:11','2024-05-08 03:10:11'),(289,'A91','gon','2024-05-08 03:10:11','2024-05-08 03:10:11'),(290,'A93','gramo por metro cúbico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(291,'A94','gramo por mol','2024-05-08 03:10:11','2024-05-08 03:10:11'),(292,'gris','A95','2024-05-08 03:10:11','2024-05-08 03:10:11'),(293,'A96','gris por segundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(294,'A97','hectopascal','2024-05-08 03:10:11','2024-05-08 03:10:11'),(295,'A98','Henry por metro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(296,'AA','bola','2024-05-08 03:10:11','2024-05-08 03:10:11'),(297,'AB','paquete a granel','2024-05-08 03:10:11','2024-05-08 03:10:11'),(298,'ACR','acre','2024-05-08 03:10:11','2024-05-08 03:10:11'),(299,'AD','byte','2024-05-08 03:10:11','2024-05-08 03:10:11'),(300,'AE','amperio por metro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(301,'AH','minuto adicional','2024-05-08 03:10:11','2024-05-08 03:10:11'),(302,'AI','minuto promedio por llamada','2024-05-08 03:10:11','2024-05-08 03:10:11'),(303,'AJ','policía','2024-05-08 03:10:11','2024-05-08 03:10:11'),(304,'AK','braza','2024-05-08 03:10:11','2024-05-08 03:10:11'),(305,'AL','263nfor de acceso','2024-05-08 03:10:11','2024-05-08 03:10:11'),(306,'AM','ampolla','2024-05-08 03:10:11','2024-05-08 03:10:11'),(307,'AMH','hora amperio','2024-05-08 03:10:11','2024-05-08 03:10:11'),(308,'AMP','amperio','2024-05-08 03:10:11','2024-05-08 03:10:11'),(309,'ANA','año','2024-05-08 03:10:11','2024-05-08 03:10:11'),(310,'AP','solo libra de aluminio','2024-05-08 03:10:11','2024-05-08 03:10:11'),(311,'APZ','onza troy o onza de boticarios','2024-05-08 03:10:11','2024-05-08 03:10:11'),(312,'AQ','Unidad de factor antihemofílico (AHF)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(313,'AR','supositorio','2024-05-08 03:10:11','2024-05-08 03:10:11'),(314,'SON','son','2024-05-08 03:10:11','2024-05-08 03:10:11'),(315,'COMO','surtido','2024-05-08 03:10:11','2024-05-08 03:10:11'),(316,'ASM','fuerza alcohólica en masa','2024-05-08 03:10:11','2024-05-08 03:10:11'),(317,'ASU','fuerza alcohólica por volumen','2024-05-08 03:10:11','2024-05-08 03:10:11'),(318,'ATM','ambiente estándar','2024-05-08 03:10:11','2024-05-08 03:10:11'),(319,'ATT','ambiente técnico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(320,'AV','cápsula','2024-05-08 03:10:11','2024-05-08 03:10:11'),(321,'AW','vial lleno de polvo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(322,'SÍ','montaje','2024-05-08 03:10:11','2024-05-08 03:10:11'),(323,'AZ','Unidad térmica británica por libra','2024-05-08 03:10:11','2024-05-08 03:10:11'),(324,'B0','Btu por pie cúbico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(325,'B1','barril (US) por día','2024-05-08 03:10:11','2024-05-08 03:10:11'),(326,'B11','julios por kilogramo kelvin','2024-05-08 03:10:11','2024-05-08 03:10:11'),(327,'B12','julios por metro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(328,'B13','julios por metro cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(329,'B14','julios por metro a la cuarta potencia','2024-05-08 03:10:11','2024-05-08 03:10:11'),(330,'B15','julios por mol','2024-05-08 03:10:11','2024-05-08 03:10:11'),(331,'B16','julios por mol kelvin','2024-05-08 03:10:11','2024-05-08 03:10:11'),(332,'B18','joule segundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(333,'B2','litera','2024-05-08 03:10:11','2024-05-08 03:10:11'),(334,'B20','joule metro cuadrado por kilogramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(335,'B21','kelvin por vatio','2024-05-08 03:10:11','2024-05-08 03:10:11'),(336,'B22','Kiloampere','2024-05-08 03:10:11','2024-05-08 03:10:11'),(337,'B23','kiloampere por metro cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(338,'B24','kiloampere por metro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(339,'B25','kilobecquerel por kilogramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(340,'B26','kilocoulomb','2024-05-08 03:10:11','2024-05-08 03:10:11'),(341,'B27','kilocoulomb por metro cúbico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(342,'B28','kilocoulomb por metro cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(343,'B29','kiloelectronvolt','2024-05-08 03:10:11','2024-05-08 03:10:11'),(344,'B3','libra de bateo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(345,'B31','kilogramo metro por segundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(346,'B32','kilogramo metro cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(347,'B33','kilogramo metro cuadrado por segundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(348,'B34','kilogramo por decímetro cúbico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(349,'B35','kilogramo por litro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(350,'B36','caloría termoquímica por gramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(351,'B37','kilogramo de fuerza','2024-05-08 03:10:11','2024-05-08 03:10:11'),(352,'B38','metro de fuerza de kilogramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(353,'B39','metro de fuerza de kilogramo por segundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(354,'B4','barril, imperial','2024-05-08 03:10:11','2024-05-08 03:10:11'),(355,'B40','kilogramo de fuerza por metro cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(356,'B41','kilojoule per kelvin','2024-05-08 03:10:11','2024-05-08 03:10:11'),(357,'B42','kilojoule por kilogramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(358,'B43','kilojoule por kilogramo kelvin','2024-05-08 03:10:11','2024-05-08 03:10:11'),(359,'B44','kilojoule por mol','2024-05-08 03:10:11','2024-05-08 03:10:11'),(360,'B45','kilomol','2024-05-08 03:10:11','2024-05-08 03:10:11'),(361,'B46','kilomol por metro cúbico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(362,'B47','Kilonewton','2024-05-08 03:10:11','2024-05-08 03:10:11'),(363,'B48','medidor de kilonewton','2024-05-08 03:10:11','2024-05-08 03:10:11'),(364,'B49','kiloohm','2024-05-08 03:10:11','2024-05-08 03:10:11'),(365,'B5','palanquilla','2024-05-08 03:10:11','2024-05-08 03:10:11'),(366,'B50','medidor de kiloohm','2024-05-08 03:10:11','2024-05-08 03:10:11'),(367,'B51','kilopond','2024-05-08 03:10:11','2024-05-08 03:10:11'),(368,'B52','kilosegundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(369,'B53','kilosiemens','2024-05-08 03:10:11','2024-05-08 03:10:11'),(370,'B54','kilosiemens por metro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(371,'B55','kilovoltios por metro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(372,'B56','kiloveber por metro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(373,'B57','año luz','2024-05-08 03:10:11','2024-05-08 03:10:11'),(374,'B58','litro por mol','2024-05-08 03:10:11','2024-05-08 03:10:11'),(375,'B59','hora lumen','2024-05-08 03:10:11','2024-05-08 03:10:11'),(376,'B6','bollo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(377,'B60','lumen por metro cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(378,'B61','lumen por vatio','2024-05-08 03:10:11','2024-05-08 03:10:11'),(379,'B62','lumen segundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(380,'B63','hora de lux','2024-05-08 03:10:11','2024-05-08 03:10:11'),(381,'B64','lux segundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(382,'B65','Maxwell','2024-05-08 03:10:11','2024-05-08 03:10:11'),(383,'B66','megaamperios por metro cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(384,'B67','megabecquerel por kilogramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(385,'B69','megacoulomb por metro cúbico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(386,'B7','ciclo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(387,'B70','megacoulomb por metro cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(388,'B71','megaelectronvolt','2024-05-08 03:10:11','2024-05-08 03:10:11'),(389,'B72','megagramo por metro cúbico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(390,'B73','meganewton','2024-05-08 03:10:11','2024-05-08 03:10:11'),(391,'B74','medidor de meganewton','2024-05-08 03:10:11','2024-05-08 03:10:11'),(392,'B75','megaohm','2024-05-08 03:10:11','2024-05-08 03:10:11'),(393,'B76','metro megaohm','2024-05-08 03:10:11','2024-05-08 03:10:11'),(394,'B77','megasiemens por metro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(395,'B78','megavoltio','2024-05-08 03:10:11','2024-05-08 03:10:11'),(396,'B79','megavolt por metro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(397,'B8','julios por metro cúbico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(398,'B81','metro recíproco cuadrado recíproco segundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(399,'B83','metro a la cuarta potencia','2024-05-08 03:10:11','2024-05-08 03:10:11'),(400,'B84','microamperios','2024-05-08 03:10:11','2024-05-08 03:10:11'),(401,'B85','microbar','2024-05-08 03:10:11','2024-05-08 03:10:11'),(402,'B86','microcoulomb','2024-05-08 03:10:11','2024-05-08 03:10:11'),(403,'B87','microcoulomb por metro cúbico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(404,'B88','microcoulomb por metro cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(405,'B89','microfarada por metro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(406,'B9','batt','2024-05-08 03:10:11','2024-05-08 03:10:11'),(407,'B90','microhenry','2024-05-08 03:10:11','2024-05-08 03:10:11'),(408,'B91','microhenry por metro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(409,'B92','micronewton','2024-05-08 03:10:11','2024-05-08 03:10:11'),(410,'B93','medidor de micronewton','2024-05-08 03:10:11','2024-05-08 03:10:11'),(411,'B94','microohm','2024-05-08 03:10:11','2024-05-08 03:10:11'),(412,'B95','medidor de microohmios','2024-05-08 03:10:11','2024-05-08 03:10:11'),(413,'B96','micropascal','2024-05-08 03:10:11','2024-05-08 03:10:11'),(414,'B97','microradiano','2024-05-08 03:10:11','2024-05-08 03:10:11'),(415,'B98','microsegundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(416,'B99','microsiemens','2024-05-08 03:10:11','2024-05-08 03:10:11'),(417,'BAR','bar','2024-05-08 03:10:11','2024-05-08 03:10:11'),(418,'BB','caja base','2024-05-08 03:10:11','2024-05-08 03:10:11'),(419,'BD','tablero','2024-05-08 03:10:11','2024-05-08 03:10:11'),(420,'haz','SER','2024-05-08 03:10:11','2024-05-08 03:10:11'),(421,'BFT','pie de tabla','2024-05-08 03:10:11','2024-05-08 03:10:11'),(422,'BG','bolso','2024-05-08 03:10:11','2024-05-08 03:10:11'),(423,'BH','cepillo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(424,'BHP','potencia al freno','2024-05-08 03:10:11','2024-05-08 03:10:11'),(425,'BIL','trillón de dólares','2024-05-08 03:10:11','2024-05-08 03:10:11'),(426,'BJ','cangilón','2024-05-08 03:10:11','2024-05-08 03:10:11'),(427,'BK','cesta','2024-05-08 03:10:11','2024-05-08 03:10:11'),(428,'BL','bala','2024-05-08 03:10:11','2024-05-08 03:10:11'),(429,'BLD','barril seco','2024-05-08 03:10:11','2024-05-08 03:10:11'),(430,'BLL','barril (EE. UU.) (petróleo, etc.)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(431,'BO','botella','2024-05-08 03:10:11','2024-05-08 03:10:11'),(432,'BP','cien pies de tabla','2024-05-08 03:10:11','2024-05-08 03:10:11'),(433,'BQL','becquerel','2024-05-08 03:10:11','2024-05-08 03:10:11'),(434,'BR','bar','2024-05-08 03:10:11','2024-05-08 03:10:11'),(435,'BT','tornillo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(436,'C30','milivoltios por metro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(437,'C31','milivatios','2024-05-08 03:10:11','2024-05-08 03:10:11'),(438,'C32','milivatios por metro cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(439,'C33','milliweber','2024-05-08 03:10:11','2024-05-08 03:10:11'),(440,'C34','Topo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(441,'C35','mol por decímetro cúbico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(442,'C36','mol por metro cúbico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(443,'C38','mol por litro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(444,'C39','Nanoampere','2024-05-08 03:10:11','2024-05-08 03:10:11'),(445,'C4','partido de carga','2024-05-08 03:10:11','2024-05-08 03:10:11'),(446,'C40','nanocoulomb','2024-05-08 03:10:11','2024-05-08 03:10:11'),(447,'C41','nanofarad','2024-05-08 03:10:11','2024-05-08 03:10:11'),(448,'C42','nanofarad por metro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(449,'C43','nanohenry','2024-05-08 03:10:11','2024-05-08 03:10:11'),(450,'C44','nanohenry por metro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(451,'C45','nanometro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(452,'C46','medidor de nanoohm','2024-05-08 03:10:11','2024-05-08 03:10:11'),(453,'C47','nanosegundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(454,'C48','nanotesla','2024-05-08 03:10:11','2024-05-08 03:10:11'),(455,'C49','nanovatio','2024-05-08 03:10:11','2024-05-08 03:10:11'),(456,'C5','costo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(457,'C50','neper','2024-05-08 03:10:11','2024-05-08 03:10:11'),(458,'C51','neper por segundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(459,'C52','picometro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(460,'C53','metro de newton segundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(461,'C54','newton metro cuadrado kilogramo cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(462,'C55','newton por metro cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(463,'C56','newton por milímetro cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(464,'C57','newton segundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(465,'C58','newton segundo por metro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(466,'C59','octava','2024-05-08 03:10:11','2024-05-08 03:10:11'),(467,'C6','célula','2024-05-08 03:10:11','2024-05-08 03:10:11'),(468,'C60','ohm centímetro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(469,'C61','ohm metro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(470,'C62','uno','2024-05-08 03:10:11','2024-05-08 03:10:11'),(471,'C63','parsec','2024-05-08 03:10:11','2024-05-08 03:10:11'),(472,'C64','pascal por kelvin','2024-05-08 03:10:11','2024-05-08 03:10:11'),(473,'C65','segundo pascal','2024-05-08 03:10:11','2024-05-08 03:10:11'),(474,'C66','segundo pascal por metro cúbico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(475,'C67','segundo pascal por metro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(476,'C68','petajoule','2024-05-08 03:10:11','2024-05-08 03:10:11'),(477,'C69','telefono','2024-05-08 03:10:11','2024-05-08 03:10:11'),(478,'C7','centipoise','2024-05-08 03:10:11','2024-05-08 03:10:11'),(479,'C70','picoampere','2024-05-08 03:10:11','2024-05-08 03:10:11'),(480,'C71','picocoulomb','2024-05-08 03:10:11','2024-05-08 03:10:11'),(481,'C72','picofarad por metro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(482,'C73','picohenry','2024-05-08 03:10:11','2024-05-08 03:10:11'),(483,'C75','picowatt','2024-05-08 03:10:11','2024-05-08 03:10:11'),(484,'C76','picowatt por metro cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(485,'C77','medidor de libras','2024-05-08 03:10:11','2024-05-08 03:10:11'),(486,'C78','fuerza de libra','2024-05-08 03:10:11','2024-05-08 03:10:11'),(487,'C8','Millicoulomb por kilogramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(488,'C80','rad','2024-05-08 03:10:11','2024-05-08 03:10:11'),(489,'C81','radián','2024-05-08 03:10:11','2024-05-08 03:10:11'),(490,'C82','medidor de radianes al cuadrado por mol','2024-05-08 03:10:11','2024-05-08 03:10:11'),(491,'C83','medidor de radianes al cuadrado por kilogramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(492,'C84','radian por metro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(493,'C85','â € ngstr recíproco “m','2024-05-08 03:10:11','2024-05-08 03:10:11'),(494,'C86','metro cúbico recíproco','2024-05-08 03:10:11','2024-05-08 03:10:11'),(495,'C87','metro cúbico recíproco por segundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(496,'C88','voltios de electrones recíprocos por metro cúbico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(497,'C89','Henry Recíproco','2024-05-08 03:10:11','2024-05-08 03:10:11'),(498,'C9','grupo de bobina','2024-05-08 03:10:11','2024-05-08 03:10:11'),(499,'C90','Joule recíproco por metro cúbico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(500,'C91','kelvin recíproco o kelvin al poder menos uno','2024-05-08 03:10:11','2024-05-08 03:10:11'),(501,'C92','medidor recíproco','2024-05-08 03:10:11','2024-05-08 03:10:11'),(502,'C93','metro cuadrado recíproco','2024-05-08 03:10:11','2024-05-08 03:10:11'),(503,'C94','minuto recíproco','2024-05-08 03:10:11','2024-05-08 03:10:11'),(504,'C95','mole recíproco','2024-05-08 03:10:11','2024-05-08 03:10:11'),(505,'C96','Pascal recíproco o pascal a la potencia menos uno.','2024-05-08 03:10:11','2024-05-08 03:10:11'),(506,'C97','segundo recíproco','2024-05-08 03:10:11','2024-05-08 03:10:11'),(507,'C98','segundo recíproco por metro cúbico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(508,'C99','segundo recíproco por metro cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(509,'CA','Caja','2024-05-08 03:10:11','2024-05-08 03:10:11'),(510,'CCT','Capacidad de carga en toneladas métricas.','2024-05-08 03:10:11','2024-05-08 03:10:11'),(511,'CDL','candela','2024-05-08 03:10:11','2024-05-08 03:10:11'),(512,'CEL','grado Celsius','2024-05-08 03:10:11','2024-05-08 03:10:11'),(513,'CEN','cien','2024-05-08 03:10:11','2024-05-08 03:10:11'),(514,'CG','tarjeta','2024-05-08 03:10:11','2024-05-08 03:10:11'),(515,'CGM','centigramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(516,'CH','envase','2024-05-08 03:10:11','2024-05-08 03:10:11'),(517,'CJ','cono','2024-05-08 03:10:11','2024-05-08 03:10:11'),(518,'CK','conector','2024-05-08 03:10:11','2024-05-08 03:10:11'),(519,'CKG','Coulomb por kilogramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(520,'CL','bobina','2024-05-08 03:10:11','2024-05-08 03:10:11'),(521,'CLF','cientos de licencia','2024-05-08 03:10:11','2024-05-08 03:10:11'),(522,'CLT','centilitro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(523,'CMK','centímetro cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(524,'CMQ','centímetro cúbico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(525,'CMT','centímetro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(526,'CNP','paquete de cien','2024-05-08 03:10:11','2024-05-08 03:10:11'),(527,'CNT','Cental (Reino Unido)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(528,'CO','garrafón','2024-05-08 03:10:11','2024-05-08 03:10:11'),(529,'COU','culombio','2024-05-08 03:10:11','2024-05-08 03:10:11'),(530,'CQ','cartucho','2024-05-08 03:10:11','2024-05-08 03:10:11'),(531,'CR','caja','2024-05-08 03:10:11','2024-05-08 03:10:11'),(532,'CS','caso','2024-05-08 03:10:11','2024-05-08 03:10:11'),(533,'CT','caja de cartón','2024-05-08 03:10:11','2024-05-08 03:10:11'),(534,'CTM','quilate métrico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(535,'CU','vaso','2024-05-08 03:10:11','2024-05-08 03:10:11'),(536,'CUR','curie','2024-05-08 03:10:11','2024-05-08 03:10:11'),(537,'CV','cubrir','2024-05-08 03:10:11','2024-05-08 03:10:11'),(538,'CWA','cien libras (quintales) / cien pesos (US)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(539,'CWI','cien pesos (Reino Unido)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(540,'CY','cilindro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(541,'CZ','combo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(542,'D1','segundo recíproco por esteradiano','2024-05-08 03:10:11','2024-05-08 03:10:11'),(543,'D10','siemens por metro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(544,'D12','siemens metro cuadrado por mol','2024-05-08 03:10:11','2024-05-08 03:10:11'),(545,'D13','sievert','2024-05-08 03:10:11','2024-05-08 03:10:11'),(546,'D14','mil yardas lineales','2024-05-08 03:10:11','2024-05-08 03:10:11'),(547,'D15','sone','2024-05-08 03:10:11','2024-05-08 03:10:11'),(548,'D16','centímetro cuadrado por ergio','2024-05-08 03:10:11','2024-05-08 03:10:11'),(549,'D17','centímetro cuadrado por erg esterlina','2024-05-08 03:10:11','2024-05-08 03:10:11'),(550,'D18','metro kelvin','2024-05-08 03:10:11','2024-05-08 03:10:11'),(551,'D19','kelvin metro cuadrado por vatio','2024-05-08 03:10:11','2024-05-08 03:10:11'),(552,'D2','segundo recíproco por metros cuadrados esteradianos','2024-05-08 03:10:11','2024-05-08 03:10:11'),(553,'D20','metro cuadrado por julio','2024-05-08 03:10:11','2024-05-08 03:10:11'),(554,'D21','metro cuadrado por kilogramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(555,'D22','metro cuadrado por mol','2024-05-08 03:10:11','2024-05-08 03:10:11'),(556,'D23','pluma gramo (proteína)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(557,'D24','metro cuadrado por esterilizador','2024-05-08 03:10:11','2024-05-08 03:10:11'),(558,'D25','metro cuadrado por julios esteradianos','2024-05-08 03:10:11','2024-05-08 03:10:11'),(559,'D26','metro cuadrado por voltio segundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(560,'D27','esteradiano','2024-05-08 03:10:11','2024-05-08 03:10:11'),(561,'D28','sifón','2024-05-08 03:10:11','2024-05-08 03:10:11'),(562,'D29','terahercios','2024-05-08 03:10:11','2024-05-08 03:10:11'),(563,'D30','terajulio','2024-05-08 03:10:11','2024-05-08 03:10:11'),(564,'D31','teravatio','2024-05-08 03:10:11','2024-05-08 03:10:11'),(565,'D32','hora de teravatio','2024-05-08 03:10:11','2024-05-08 03:10:11'),(566,'D33','tesla','2024-05-08 03:10:11','2024-05-08 03:10:11'),(567,'D34','Texas','2024-05-08 03:10:11','2024-05-08 03:10:11'),(568,'D35','caloría termoquímica','2024-05-08 03:10:11','2024-05-08 03:10:11'),(569,'D37','caloría termoquímica por gramo kelvin','2024-05-08 03:10:11','2024-05-08 03:10:11'),(570,'D38','calorías termoquímicas por segundo centímetro kelvin','2024-05-08 03:10:11','2024-05-08 03:10:11'),(571,'D39','calorías termoquímicas por segundo centímetro cuadrado kelvin','2024-05-08 03:10:11','2024-05-08 03:10:11'),(572,'D40','mil litros','2024-05-08 03:10:11','2024-05-08 03:10:11'),(573,'D41','tonelada por metro cúbico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(574,'D42','año tropical','2024-05-08 03:10:11','2024-05-08 03:10:11'),(575,'D43','unidad de masa atómica unificada','2024-05-08 03:10:11','2024-05-08 03:10:11'),(576,'D44','var','2024-05-08 03:10:11','2024-05-08 03:10:11'),(577,'D45','voltios al cuadrado por kelvin al cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(578,'D46','voltio – amperio','2024-05-08 03:10:11','2024-05-08 03:10:11'),(579,'D47','voltio por centímetro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(580,'D48','voltio por kelvin','2024-05-08 03:10:11','2024-05-08 03:10:11'),(581,'D49','milivoltios por kelvin','2024-05-08 03:10:11','2024-05-08 03:10:11'),(582,'D5','kilogramo por centímetro cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(583,'D50','voltios por metro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(584,'D51','voltios por milímetro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(585,'D52','vatios por kelvin','2024-05-08 03:10:11','2024-05-08 03:10:11'),(586,'D53','vatios por metro kelvin','2024-05-08 03:10:11','2024-05-08 03:10:11'),(587,'D54','vatios por metro cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(588,'D55','vatios por metro cuadrado kelvin','2024-05-08 03:10:11','2024-05-08 03:10:11'),(589,'D56','vatios por metro cuadrado de kelvin a la cuarta potencia','2024-05-08 03:10:11','2024-05-08 03:10:11'),(590,'D57','vatios por steradian','2024-05-08 03:10:11','2024-05-08 03:10:11'),(591,'D58','vatios por metro cuadrado esterlino','2024-05-08 03:10:11','2024-05-08 03:10:11'),(592,'D59','weber por metro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(593,'D6','röntgen por segundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(594,'D60','weber por milímetro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(595,'D61','minuto','2024-05-08 03:10:11','2024-05-08 03:10:11'),(596,'D62','segundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(597,'D63','libro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(598,'D64','bloquear','2024-05-08 03:10:11','2024-05-08 03:10:11'),(599,'D65','redondo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(600,'D66','casete','2024-05-08 03:10:11','2024-05-08 03:10:11'),(601,'D67','dólar por hora','2024-05-08 03:10:11','2024-05-08 03:10:11'),(602,'D69','pulgada a la cuarta potencia','2024-05-08 03:10:11','2024-05-08 03:10:11'),(603,'D7','Sandwich','2024-05-08 03:10:11','2024-05-08 03:10:11'),(604,'D70','Tabla Internacional (IT) caloría','2024-05-08 03:10:11','2024-05-08 03:10:11'),(605,'D71','Tabla Internacional (IT) calorías por segundo centímetro kelvin','2024-05-08 03:10:11','2024-05-08 03:10:11'),(606,'D72','Tabla Internacional (IT) calorías por segundo centímetro cuadrado kelvin','2024-05-08 03:10:11','2024-05-08 03:10:11'),(607,'D73','joule metro cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(608,'D74','kilogramo por mol','2024-05-08 03:10:11','2024-05-08 03:10:11'),(609,'D75','Tabla Internacional (IT) calorías por gramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(610,'D76','Tabla Internacional (IT) calorías por gramo kelvin','2024-05-08 03:10:11','2024-05-08 03:10:11'),(611,'D77','megacoulomb','2024-05-08 03:10:11','2024-05-08 03:10:11'),(612,'D79','haz','2024-05-08 03:10:11','2024-05-08 03:10:11'),(613,'D8','puntaje de drenaje','2024-05-08 03:10:11','2024-05-08 03:10:11'),(614,'D80','microwatt','2024-05-08 03:10:11','2024-05-08 03:10:11'),(615,'D81','microtesla','2024-05-08 03:10:11','2024-05-08 03:10:11'),(616,'D82','microvoltio','2024-05-08 03:10:11','2024-05-08 03:10:11'),(617,'D83','medidor de millinewton','2024-05-08 03:10:11','2024-05-08 03:10:11'),(618,'D85','microwatt por metro cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(619,'D86','Millicoulomb','2024-05-08 03:10:11','2024-05-08 03:10:11'),(620,'D87','milimol por kilogramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(621,'D88','millicoulomb por metro cúbico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(622,'D89','millicoulomb por metro cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(623,'D9','dina por centímetro cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(624,'D90','metro cúbico (neto)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(625,'D91','movimiento rápido del ojo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(626,'D92','banda','2024-05-08 03:10:11','2024-05-08 03:10:11'),(627,'D93','segundo por metro cúbico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(628,'D94','segundo por metro cúbico radianes','2024-05-08 03:10:11','2024-05-08 03:10:11'),(629,'D95','julios por gramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(630,'D96','libra bruta','2024-05-08 03:10:11','2024-05-08 03:10:11'),(631,'D97','carga de palet / unidad','2024-05-08 03:10:11','2024-05-08 03:10:11'),(632,'D98','libra de masa','2024-05-08 03:10:11','2024-05-08 03:10:11'),(633,'D99','manga','2024-05-08 03:10:11','2024-05-08 03:10:11'),(634,'DAA','despreciar','2024-05-08 03:10:11','2024-05-08 03:10:11'),(635,'DAD','diez dias','2024-05-08 03:10:11','2024-05-08 03:10:11'),(636,'día','DAY','2024-05-08 03:10:11','2024-05-08 03:10:11'),(637,'DB','libra seca','2024-05-08 03:10:11','2024-05-08 03:10:11'),(638,'DC','disco','2024-05-08 03:10:11','2024-05-08 03:10:11'),(639,'DD','la licenciatura','2024-05-08 03:10:11','2024-05-08 03:10:11'),(640,'DE','acuerdo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(641,'DEC','década','2024-05-08 03:10:11','2024-05-08 03:10:11'),(642,'DG','decigramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(643,'DI','dispensador','2024-05-08 03:10:11','2024-05-08 03:10:11'),(644,'DJ','decagramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(645,'DLT','decilitro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(646,'DMK','263nformaci cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(647,'DMQ','decímetro cúbico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(648,'DMT','decímetro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(649,'DN','medidor de decinewton','2024-05-08 03:10:11','2024-05-08 03:10:11'),(650,'DPC','docena pieza','2024-05-08 03:10:11','2024-05-08 03:10:11'),(651,'DPR','docena par','2024-05-08 03:10:11','2024-05-08 03:10:11'),(652,'DPT','tonelaje de desplazamiento','2024-05-08 03:10:11','2024-05-08 03:10:11'),(653,'DQ','registro de datos','2024-05-08 03:10:11','2024-05-08 03:10:11'),(654,'DR','tambor','2024-05-08 03:10:11','2024-05-08 03:10:11'),(655,'DRA','dram (US)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(656,'DRI','dram (Reino Unido)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(657,'DRL','docena rollo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(658,'DRM','dracma (Reino Unido)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(659,'DS','monitor','2024-05-08 03:10:11','2024-05-08 03:10:11'),(660,'DT','tonelada seca','2024-05-08 03:10:11','2024-05-08 03:10:11'),(661,'DTN','Decitonne','2024-05-08 03:10:11','2024-05-08 03:10:11'),(662,'DU','dina','2024-05-08 03:10:11','2024-05-08 03:10:11'),(663,'DWT','pennyweight','2024-05-08 03:10:11','2024-05-08 03:10:11'),(664,'DX','dina por centímetro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(665,'DY','libro de directorio','2024-05-08 03:10:11','2024-05-08 03:10:11'),(666,'DZN','docena','2024-05-08 03:10:11','2024-05-08 03:10:11'),(667,'DZP','paquete de doce','2024-05-08 03:10:11','2024-05-08 03:10:11'),(668,'E2','cinturón','2024-05-08 03:10:11','2024-05-08 03:10:11'),(669,'E3','remolque','2024-05-08 03:10:11','2024-05-08 03:10:11'),(670,'E4','kilogramo bruto','2024-05-08 03:10:11','2024-05-08 03:10:11'),(671,'E5','tonelada métrica larga','2024-05-08 03:10:11','2024-05-08 03:10:11'),(672,'EA','cada','2024-05-08 03:10:11','2024-05-08 03:10:11'),(673,'EB','casilla de correo electrónico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(674,'CE','cada uno por mes','2024-05-08 03:10:11','2024-05-08 03:10:11'),(675,'EP','paquete de once','2024-05-08 03:10:11','2024-05-08 03:10:11'),(676,'EQ','galón equivalente','2024-05-08 03:10:11','2024-05-08 03:10:11'),(677,'EV','sobre','2024-05-08 03:10:11','2024-05-08 03:10:11'),(678,'F1','mil pies cúbicos por día','2024-05-08 03:10:11','2024-05-08 03:10:11'),(679,'F9','Fibra por centímetro cúbico de aire','2024-05-08 03:10:11','2024-05-08 03:10:11'),(680,'FAH','grado Fahrenheit','2024-05-08 03:10:11','2024-05-08 03:10:11'),(681,'FAR','faradio','2024-05-08 03:10:11','2024-05-08 03:10:11'),(682,'FB','campo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(683,'FC','mil pies cúbicos','2024-05-08 03:10:11','2024-05-08 03:10:11'),(684,'FD','millón de partículas por pie cúbico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(685,'FE','pie de pista','2024-05-08 03:10:11','2024-05-08 03:10:11'),(686,'FF','cien metros cúbicos','2024-05-08 03:10:11','2024-05-08 03:10:11'),(687,'FG','parche transdérmico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(688,'FH','micromol','2024-05-08 03:10:11','2024-05-08 03:10:11'),(689,'FL','tonelada en escamas','2024-05-08 03:10:11','2024-05-08 03:10:11'),(690,'FM','millones de pies cúbicos','2024-05-08 03:10:11','2024-05-08 03:10:11'),(691,'pie','FOT','2024-05-08 03:10:11','2024-05-08 03:10:11'),(692,'FP','libra por pie cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(693,'FR','pie por minuto','2024-05-08 03:10:11','2024-05-08 03:10:11'),(694,'FS','pie por segundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(695,'FTK','pie cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(696,'FTQ','pie cubico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(697,'G2','US galones por minuto','2024-05-08 03:10:11','2024-05-08 03:10:11'),(698,'G3','Galon imperial por minuto','2024-05-08 03:10:11','2024-05-08 03:10:11'),(699,'G7','hoja de microficha','2024-05-08 03:10:11','2024-05-08 03:10:11'),(700,'GB','galón (US) por día','2024-05-08 03:10:11','2024-05-08 03:10:11'),(701,'GBQ','gigabecquerel','2024-05-08 03:10:11','2024-05-08 03:10:11'),(702,'GC','gramo por 100 gramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(703,'GD','barril bruto','2024-05-08 03:10:11','2024-05-08 03:10:11'),(704,'GE','libra por galón (US)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(705,'GF','gramo por metro (gramo por 100 centímetros)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(706,'GFI','gramo de isótopo fisionable','2024-05-08 03:10:11','2024-05-08 03:10:11'),(707,'GGR','gramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(708,'GH','medio galón (EE. UU.)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(709,'GIA','branquias','2024-05-08 03:10:11','2024-05-08 03:10:11'),(710,'GII','Gill (Reino Unido)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(711,'GJ','gramo por mililitro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(712,'GL','gramo por litro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(713,'GLD','galón seco (EE. UU.)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(714,'GLI','galón (Reino Unido)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(715,'GLL','galón','2024-05-08 03:10:11','2024-05-08 03:10:11'),(716,'GM','gramo por metro cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(717,'GN','galón bruto','2024-05-08 03:10:11','2024-05-08 03:10:11'),(718,'GO','miligramos por metro cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(719,'GP','miligramo por metro cúbico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(720,'GQ','microgramos por metro cúbico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(721,'GRM','gramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(722,'GRN','grano','2024-05-08 03:10:11','2024-05-08 03:10:11'),(723,'GRO','bruto','2024-05-08 03:10:11','2024-05-08 03:10:11'),(724,'GRT','tonelada de registro bruto','2024-05-08 03:10:11','2024-05-08 03:10:11'),(725,'GT','tonelada bruta','2024-05-08 03:10:11','2024-05-08 03:10:11'),(726,'GV','gigajoule','2024-05-08 03:10:11','2024-05-08 03:10:11'),(727,'GW','galón por mil pies cúbicos','2024-05-08 03:10:11','2024-05-08 03:10:11'),(728,'GWH','hora de gigavatios','2024-05-08 03:10:11','2024-05-08 03:10:11'),(729,'GY','patio bruto','2024-05-08 03:10:11','2024-05-08 03:10:11'),(730,'GZ','sistema de medición','2024-05-08 03:10:11','2024-05-08 03:10:11'),(731,'H1','media página – electrónica','2024-05-08 03:10:11','2024-05-08 03:10:11'),(732,'H2','medio litro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(733,'HA','madeja','2024-05-08 03:10:11','2024-05-08 03:10:11'),(734,'HAR','hectárea','2024-05-08 03:10:11','2024-05-08 03:10:11'),(735,'HBA','hectobar','2024-05-08 03:10:11','2024-05-08 03:10:11'),(736,'HBX','cien cajas','2024-05-08 03:10:11','2024-05-08 03:10:11'),(737,'HC','cien cuentas','2024-05-08 03:10:11','2024-05-08 03:10:11'),(738,'HD','media docena','2024-05-08 03:10:11','2024-05-08 03:10:11'),(739,'ÉL','centésima de quilate','2024-05-08 03:10:11','2024-05-08 03:10:11'),(740,'HF','cien pies','2024-05-08 03:10:11','2024-05-08 03:10:11'),(741,'HGM','hectogramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(742,'HH','cien pies cúbicos','2024-05-08 03:10:11','2024-05-08 03:10:11'),(743,'HI','cien hojas','2024-05-08 03:10:11','2024-05-08 03:10:11'),(744,'HIU','cien unidades internacionales','2024-05-08 03:10:11','2024-05-08 03:10:11'),(745,'HJ','caballo métrico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(746,'HK','cien kilogramos','2024-05-08 03:10:11','2024-05-08 03:10:11'),(747,'HL','cien pies (lineales)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(748,'HLT','hectolitro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(749,'HM','milla por hora','2024-05-08 03:10:11','2024-05-08 03:10:11'),(750,'HMQ','millones de metros cúbicos','2024-05-08 03:10:11','2024-05-08 03:10:11'),(751,'HMT','hectómetro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(752,'HN','milímetro convencional de mercurio','2024-05-08 03:10:11','2024-05-08 03:10:11'),(753,'HO','cien onzas troy','2024-05-08 03:10:11','2024-05-08 03:10:11'),(754,'HP','milímetro convencional de agua','2024-05-08 03:10:11','2024-05-08 03:10:11'),(755,'HPA','hectolitro de alcohol puro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(756,'HS','cien pies cuadrados','2024-05-08 03:10:11','2024-05-08 03:10:11'),(757,'HT','media hora','2024-05-08 03:10:11','2024-05-08 03:10:11'),(758,'HTZ','hertz','2024-05-08 03:10:11','2024-05-08 03:10:11'),(759,'HUR','hora','2024-05-08 03:10:11','2024-05-08 03:10:11'),(760,'HY','cien yardas','2024-05-08 03:10:11','2024-05-08 03:10:11'),(761,'IA','pulgada libra','2024-05-08 03:10:11','2024-05-08 03:10:11'),(762,'IC','contar por pulgada','2024-05-08 03:10:11','2024-05-08 03:10:11'),(763,'IE','persona','2024-05-08 03:10:11','2024-05-08 03:10:11'),(764,'IF','pulgadas de agua','2024-05-08 03:10:11','2024-05-08 03:10:11'),(765,'II','columna pulgada','2024-05-08 03:10:11','2024-05-08 03:10:11'),(766,'IL','pulgada por minuto','2024-05-08 03:10:11','2024-05-08 03:10:11'),(767,'IM','impresión','2024-05-08 03:10:11','2024-05-08 03:10:11'),(768,'INH','pulgada','2024-05-08 03:10:11','2024-05-08 03:10:11'),(769,'KI','Kilogramo por milímetro de ancho','2024-05-08 03:10:11','2024-05-08 03:10:11'),(770,'KJ','kilosegmento','2024-05-08 03:10:11','2024-05-08 03:10:11'),(771,'KJO','kilojoule','2024-05-08 03:10:11','2024-05-08 03:10:11'),(772,'KL','kilogramo por metro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(773,'KMH','kilómetro por hora','2024-05-08 03:10:11','2024-05-08 03:10:11'),(774,'KMK','kilometro cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(775,'KMQ','kilogramo por metro cúbico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(776,'KNI','kilogramo de nitrógeno','2024-05-08 03:10:11','2024-05-08 03:10:11'),(777,'KNS','kilogramo de sustancia nombrada','2024-05-08 03:10:11','2024-05-08 03:10:11'),(778,'nudo','KNT','2024-05-08 03:10:11','2024-05-08 03:10:11'),(779,'KO','Milliequivalencia de potasa cáustica por gramo de producto.','2024-05-08 03:10:11','2024-05-08 03:10:11'),(780,'KPA','kilopascal','2024-05-08 03:10:11','2024-05-08 03:10:11'),(781,'KPH','kilogramo de hidróxido de potasio (potasa cáustica)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(782,'KPO','kilogramo de óxido de potasio','2024-05-08 03:10:11','2024-05-08 03:10:11'),(783,'KPP','kilogramo de pentóxido de fósforo (anhídrido fosfórico)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(784,'KR','KilorÃ¶ntgen','2024-05-08 03:10:11','2024-05-08 03:10:11'),(785,'KS','mil libras por pulgada cuadrada','2024-05-08 03:10:11','2024-05-08 03:10:11'),(786,'KSD','kilogramo de sustancia 90% seca','2024-05-08 03:10:11','2024-05-08 03:10:11'),(787,'KSH','kilogramo de hidróxido de sodio (soda cáustica)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(788,'KT','equipo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(789,'KTM','kilómetro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(790,'KTN','kilotonne','2024-05-08 03:10:11','2024-05-08 03:10:11'),(791,'KUR','kilogramo de uranio','2024-05-08 03:10:11','2024-05-08 03:10:11'),(792,'KVA','kilovoltio – ampere','2024-05-08 03:10:11','2024-05-08 03:10:11'),(793,'KVR','kilovar','2024-05-08 03:10:11','2024-05-08 03:10:11'),(794,'KVT','kilovoltio','2024-05-08 03:10:11','2024-05-08 03:10:11'),(795,'KW','kilogramos por milímetro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(796,'KWH','kilovatios hora','2024-05-08 03:10:11','2024-05-08 03:10:11'),(797,'KWT','kilovatio','2024-05-08 03:10:11','2024-05-08 03:10:11'),(798,'KX','mililitro por kilogramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(799,'L2','litro por minuto','2024-05-08 03:10:11','2024-05-08 03:10:11'),(800,'LA','libra por pulgada cúbica','2024-05-08 03:10:11','2024-05-08 03:10:11'),(801,'LBR','libra','2024-05-08 03:10:11','2024-05-08 03:10:11'),(802,'LBT','libra troy','2024-05-08 03:10:11','2024-05-08 03:10:11'),(803,'LC','centímetro lineal','2024-05-08 03:10:11','2024-05-08 03:10:11'),(804,'LD','litro por día','2024-05-08 03:10:11','2024-05-08 03:10:11'),(805,'LE','lite','2024-05-08 03:10:11','2024-05-08 03:10:11'),(806,'LEF','hoja','2024-05-08 03:10:11','2024-05-08 03:10:11'),(807,'LF','pie lineal','2024-05-08 03:10:11','2024-05-08 03:10:11'),(808,'LH','hora de trabajo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(809,'LI','pulgada lineal','2024-05-08 03:10:11','2024-05-08 03:10:11'),(810,'LJ','spray grande','2024-05-08 03:10:11','2024-05-08 03:10:11'),(811,'LK','enlazar','2024-05-08 03:10:11','2024-05-08 03:10:11'),(812,'LM','metro lineal','2024-05-08 03:10:11','2024-05-08 03:10:11'),(813,'LN','longitud','2024-05-08 03:10:11','2024-05-08 03:10:11'),(814,'LO','mucho','2024-05-08 03:10:11','2024-05-08 03:10:11'),(815,'LP','libra liquida','2024-05-08 03:10:11','2024-05-08 03:10:11'),(816,'LPA','litro de alcohol puro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(817,'LR','capa','2024-05-08 03:10:11','2024-05-08 03:10:11'),(818,'LS','Suma global','2024-05-08 03:10:11','2024-05-08 03:10:11'),(819,'LTN','ton (Reino Unido) o longton (EE. UU.)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(820,'LTR','litro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(821,'LUM','lumen','2024-05-08 03:10:11','2024-05-08 03:10:11'),(822,'lux','LUX','2024-05-08 03:10:11','2024-05-08 03:10:11'),(823,'LX','yarda lineal por libra','2024-05-08 03:10:11','2024-05-08 03:10:11'),(824,'LY','yarda lineal','2024-05-08 03:10:11','2024-05-08 03:10:11'),(825,'M0','cinta magnética','2024-05-08 03:10:11','2024-05-08 03:10:11'),(826,'M1','miligramos por litro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(827,'M4','valor monetario','2024-05-08 03:10:11','2024-05-08 03:10:11'),(828,'M5','microcurie','2024-05-08 03:10:11','2024-05-08 03:10:11'),(829,'M7','micropulgada','2024-05-08 03:10:11','2024-05-08 03:10:11'),(830,'M9','millones de Btu por 1000 pies cúbicos','2024-05-08 03:10:11','2024-05-08 03:10:11'),(831,'MA','máquina por unidad','2024-05-08 03:10:11','2024-05-08 03:10:11'),(832,'MAL','mega litro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(833,'MAM','megametro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(834,'MAW','megavatio','2024-05-08 03:10:11','2024-05-08 03:10:11'),(835,'MBE','mil equivalentes de ladrillo estándar','2024-05-08 03:10:11','2024-05-08 03:10:11'),(836,'MBF','mil pies de tabla','2024-05-08 03:10:11','2024-05-08 03:10:11'),(837,'MBR','milibar','2024-05-08 03:10:11','2024-05-08 03:10:11'),(838,'MC','microgramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(839,'MCU','milicurie','2024-05-08 03:10:11','2024-05-08 03:10:11'),(840,'MD','aire seco tonelada métrica','2024-05-08 03:10:11','2024-05-08 03:10:11'),(841,'MF','miligramo por pie cuadrado por lado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(842,'MGM','miligramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(843,'MIK','milla cuadrada','2024-05-08 03:10:11','2024-05-08 03:10:11'),(844,'mil','MIL','2024-05-08 03:10:11','2024-05-08 03:10:11'),(845,'MIN','minuto','2024-05-08 03:10:11','2024-05-08 03:10:11'),(846,'MIO','millón','2024-05-08 03:10:11','2024-05-08 03:10:11'),(847,'MIU','millones de unidades internacionales','2024-05-08 03:10:11','2024-05-08 03:10:11'),(848,'MK','miligramo por pulgada cuadrada','2024-05-08 03:10:11','2024-05-08 03:10:11'),(849,'MLD','mil millones','2024-05-08 03:10:11','2024-05-08 03:10:11'),(850,'MLT','mililitro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(851,'MMK','milímetro cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(852,'MMQ','milímetro cúbico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(853,'MMT','milímetro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(854,'LUN','mes','2024-05-08 03:10:11','2024-05-08 03:10:11'),(855,'MPA','megapascal','2024-05-08 03:10:11','2024-05-08 03:10:11'),(856,'MQ','mil metros','2024-05-08 03:10:11','2024-05-08 03:10:11'),(857,'MQH','metro cúbico por hora','2024-05-08 03:10:11','2024-05-08 03:10:11'),(858,'MQS','metro cúbico por segundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(859,'MSK','metro por segundo al cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(860,'MT','estera','2024-05-08 03:10:11','2024-05-08 03:10:11'),(861,'MTK','metro cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(862,'MTQ','Metro cúbico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(863,'MTR','metro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(864,'MTS','metro por segundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(865,'MV','numero de mults','2024-05-08 03:10:11','2024-05-08 03:10:11'),(866,'MVA','megavolt – ampere','2024-05-08 03:10:11','2024-05-08 03:10:11'),(867,'MWH','megavatios hora (1000 kW.h)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(868,'N1','calorías de la pluma','2024-05-08 03:10:11','2024-05-08 03:10:11'),(869,'N2','número de líneas','2024-05-08 03:10:11','2024-05-08 03:10:11'),(870,'N3','punto de impresión','2024-05-08 03:10:11','2024-05-08 03:10:11'),(871,'NA','miligramo por kilogramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(872,'NAR','número de artículos','2024-05-08 03:10:11','2024-05-08 03:10:11'),(873,'NB','barcaza','2024-05-08 03:10:11','2024-05-08 03:10:11'),(874,'NBB','número de bobinas','2024-05-08 03:10:11','2024-05-08 03:10:11'),(875,'NC','coche','2024-05-08 03:10:11','2024-05-08 03:10:11'),(876,'NCL','número de celdas','2024-05-08 03:10:11','2024-05-08 03:10:11'),(877,'ND','barril neto','2024-05-08 03:10:11','2024-05-08 03:10:11'),(878,'NE','litro neto','2024-05-08 03:10:11','2024-05-08 03:10:11'),(879,'NEW','newton','2024-05-08 03:10:11','2024-05-08 03:10:11'),(880,'NF','mensaje','2024-05-08 03:10:11','2024-05-08 03:10:11'),(881,'NG','galón neto (nosotros)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(882,'NH','hora del mensaje','2024-05-08 03:10:11','2024-05-08 03:10:11'),(883,'NI','galón imperial neto','2024-05-08 03:10:11','2024-05-08 03:10:11'),(884,'NIU','número de unidades internacionales','2024-05-08 03:10:11','2024-05-08 03:10:11'),(885,'NJ','número de pantallas','2024-05-08 03:10:11','2024-05-08 03:10:11'),(886,'NL','carga','2024-05-08 03:10:11','2024-05-08 03:10:11'),(887,'MNI','milla nautica','2024-05-08 03:10:11','2024-05-08 03:10:11'),(888,'NMP','número de paquetes','2024-05-08 03:10:11','2024-05-08 03:10:11'),(889,'NN','entrenar','2024-05-08 03:10:11','2024-05-08 03:10:11'),(890,'NPL','número de parcelas','2024-05-08 03:10:11','2024-05-08 03:10:11'),(891,'NPR','numero de pares','2024-05-08 03:10:11','2024-05-08 03:10:11'),(892,'TNP','numero de partes','2024-05-08 03:10:11','2024-05-08 03:10:11'),(893,'NQ','mho','2024-05-08 03:10:11','2024-05-08 03:10:11'),(894,'NR','micromho','2024-05-08 03:10:11','2024-05-08 03:10:11'),(895,'NRL','número de rollos','2024-05-08 03:10:11','2024-05-08 03:10:11'),(896,'NT','tonelada neta','2024-05-08 03:10:11','2024-05-08 03:10:11'),(897,'NTT','registro neto de toneladas','2024-05-08 03:10:11','2024-05-08 03:10:11'),(898,'NU','medidor de newton','2024-05-08 03:10:11','2024-05-08 03:10:11'),(899,'NV','vehículo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(900,'NX','parte por mil','2024-05-08 03:10:11','2024-05-08 03:10:11'),(901,'NY','libra por aire seco tonelada métrica','2024-05-08 03:10:11','2024-05-08 03:10:11'),(902,'OA','panel','2024-05-08 03:10:11','2024-05-08 03:10:11'),(903,'OHM','ohm','2024-05-08 03:10:11','2024-05-08 03:10:11'),(904,'EN','onza por yarda cuadrada','2024-05-08 03:10:11','2024-05-08 03:10:11'),(905,'ONZ','onza','2024-05-08 03:10:11','2024-05-08 03:10:11'),(906,'OP','Dos paquetes','2024-05-08 03:10:11','2024-05-08 03:10:11'),(907,'OT','hora extra','2024-05-08 03:10:11','2024-05-08 03:10:11'),(908,'OZA','onza líquida (US)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(909,'OZI','onza líquida (Reino Unido)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(910,'P0','pagina – electronica','2024-05-08 03:10:11','2024-05-08 03:10:11'),(911,'P1','por ciento','2024-05-08 03:10:11','2024-05-08 03:10:11'),(912,'P2','libra por pie','2024-05-08 03:10:11','2024-05-08 03:10:11'),(913,'P3','paquete de tres','2024-05-08 03:10:11','2024-05-08 03:10:11'),(914,'P4','paquete de cuatro','2024-05-08 03:10:11','2024-05-08 03:10:11'),(915,'P5','paquete de cinco','2024-05-08 03:10:11','2024-05-08 03:10:11'),(916,'P6','paquete de seis','2024-05-08 03:10:11','2024-05-08 03:10:11'),(917,'P7','paquete de siete','2024-05-08 03:10:11','2024-05-08 03:10:11'),(918,'P8','paquete de ocho','2024-05-08 03:10:11','2024-05-08 03:10:11'),(919,'P9','paquete de nueve','2024-05-08 03:10:11','2024-05-08 03:10:11'),(920,'PA','paquete','2024-05-08 03:10:11','2024-05-08 03:10:11'),(921,'PAL','pascal','2024-05-08 03:10:11','2024-05-08 03:10:11'),(922,'PB','par de pulgadas','2024-05-08 03:10:11','2024-05-08 03:10:11'),(923,'PD','almohadilla','2024-05-08 03:10:11','2024-05-08 03:10:11'),(924,'PE','equivalente en libras','2024-05-08 03:10:11','2024-05-08 03:10:11'),(925,'PF','palet (ascensor)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(926,'PG','plato','2024-05-08 03:10:11','2024-05-08 03:10:11'),(927,'PGL','galón de prueba','2024-05-08 03:10:11','2024-05-08 03:10:11'),(928,'Pi','tono','2024-05-08 03:10:11','2024-05-08 03:10:11'),(929,'PK','paquete','2024-05-08 03:10:11','2024-05-08 03:10:11'),(930,'PL','cubo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(931,'PM','porcentaje de libra','2024-05-08 03:10:11','2024-05-08 03:10:11'),(932,'PN','libra neta','2024-05-08 03:10:11','2024-05-08 03:10:11'),(933,'PO','libra por pulgada de longitud','2024-05-08 03:10:11','2024-05-08 03:10:11'),(934,'PQ','página por pulgada','2024-05-08 03:10:11','2024-05-08 03:10:11'),(935,'par','PR','2024-05-08 03:10:11','2024-05-08 03:10:11'),(936,'PT','pinta','2024-05-08 03:10:11','2024-05-08 03:10:11'),(937,'PTD','pinta seca','2024-05-08 03:10:11','2024-05-08 03:10:11'),(938,'PTI','pinta (Reino Unido)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(939,'PTL','pinta liquida (US)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(940,'PU','bandeja / paquete de bandeja','2024-05-08 03:10:11','2024-05-08 03:10:11'),(941,'PV','media pinta (US)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(942,'PW','libra por pulgada de ancho','2024-05-08 03:10:11','2024-05-08 03:10:11'),(943,'PY','Peck Dry (US)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(944,'PZ','Peck Dry (Reino Unido)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(945,'Q3','comida','2024-05-08 03:10:11','2024-05-08 03:10:11'),(946,'QA','página – facsímil','2024-05-08 03:10:11','2024-05-08 03:10:11'),(947,'QAN','cuarto (de un año)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(948,'QB','página – copia impresa','2024-05-08 03:10:11','2024-05-08 03:10:11'),(949,'QD','cuarto de docena','2024-05-08 03:10:11','2024-05-08 03:10:11'),(950,'QH','un cuarto de hora','2024-05-08 03:10:11','2024-05-08 03:10:11'),(951,'QK','cuarto de kilogramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(952,'QR','mano de papel','2024-05-08 03:10:11','2024-05-08 03:10:11'),(953,'QT','cuarto de galón (US)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(954,'QTD','cuarto seco (EE. UU.)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(955,'QTI','cuarto de galón (Reino Unido)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(956,'QTL','cuarto líquido (US)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(957,'QTR','cuarto (UK)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(958,'R1','pica','2024-05-08 03:10:11','2024-05-08 03:10:11'),(959,'R4','caloría','2024-05-08 03:10:11','2024-05-08 03:10:11'),(960,'R9','mil metros cúbicos','2024-05-08 03:10:11','2024-05-08 03:10:11'),(961,'RA','estante','2024-05-08 03:10:11','2024-05-08 03:10:11'),(962,'RD','barra','2024-05-08 03:10:11','2024-05-08 03:10:11'),(963,'RG','anillo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(964,'RH','hora de funcionamiento o de funcionamiento','2024-05-08 03:10:11','2024-05-08 03:10:11'),(965,'RK','medida métrica rollo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(966,'RL','carrete','2024-05-08 03:10:11','2024-05-08 03:10:11'),(967,'RM','resma','2024-05-08 03:10:11','2024-05-08 03:10:11'),(968,'RN','medida métrica de resma','2024-05-08 03:10:11','2024-05-08 03:10:11'),(969,'RO','rodar','2024-05-08 03:10:11','2024-05-08 03:10:11'),(970,'RP','libra por resma','2024-05-08 03:10:11','2024-05-08 03:10:11'),(971,'RPM','revoluciones por minuto','2024-05-08 03:10:11','2024-05-08 03:10:11'),(972,'RPS','revoluciones por segundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(973,'RS','Reiniciar','2024-05-08 03:10:11','2024-05-08 03:10:11'),(974,'RT','ingreso tonelada milla','2024-05-08 03:10:11','2024-05-08 03:10:11'),(975,'RU','correr','2024-05-08 03:10:11','2024-05-08 03:10:11'),(976,'S3','pie cuadrado por segundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(977,'S4','metro cuadrado por segundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(978,'S5','sesenta cuartos de pulgada','2024-05-08 03:10:11','2024-05-08 03:10:11'),(979,'S6','sesión','2024-05-08 03:10:11','2024-05-08 03:10:11'),(980,'S7','unidad de almacenamiento','2024-05-08 03:10:11','2024-05-08 03:10:11'),(981,'S8','unidad de publicidad estándar','2024-05-08 03:10:11','2024-05-08 03:10:11'),(982,'SA','saco','2024-05-08 03:10:11','2024-05-08 03:10:11'),(983,'SAN','medio año (6 meses)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(984,'OCS','Puntuación','2024-05-08 03:10:11','2024-05-08 03:10:11'),(985,'SCR','escrúpulo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(986,'SD','libra solida','2024-05-08 03:10:11','2024-05-08 03:10:11'),(987,'SE','sección','2024-05-08 03:10:11','2024-05-08 03:10:11'),(988,'SEC','segundo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(989,'SET','conjunto','2024-05-08 03:10:11','2024-05-08 03:10:11'),(990,'SG','segmento','2024-05-08 03:10:11','2024-05-08 03:10:11'),(991,'SHT','tonelada de envío','2024-05-08 03:10:11','2024-05-08 03:10:11'),(992,'SIE','siemens','2024-05-08 03:10:11','2024-05-08 03:10:11'),(993,'SK','camión cisterna dividido','2024-05-08 03:10:11','2024-05-08 03:10:11'),(994,'SL','hoja de deslizamiento','2024-05-08 03:10:11','2024-05-08 03:10:11'),(995,'SMI','milla (milla estatutaria)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(996,'SN','varilla cuadrada','2024-05-08 03:10:11','2024-05-08 03:10:11'),(997,'SO','carrete','2024-05-08 03:10:11','2024-05-08 03:10:11'),(998,'SP','paquete de estante','2024-05-08 03:10:11','2024-05-08 03:10:11'),(999,'SQ','cuadrado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1000,'SR','tira','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1001,'SS','hoja métrica medida','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1002,'SST','corto estándar (7200 partidos)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1003,'ST','hoja','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1004,'ITS','piedra (Reino Unido)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1005,'STN','tonelada (US) o tonelada corta (UK / US)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1006,'SV','patinar','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1007,'SX','envío','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1008,'T0','Línea de telecomunicaciones en servicio.','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1009,'T1','mil libras brutas','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1010,'T3','mil piezas','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1011,'T4','bolsa de mil','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1012,'T5','caja de mil','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1013,'T6','mil galones (US)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1014,'T7','mil impresiones','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1015,'T8','mil pulgadas lineales','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1016,'TA','décimo pie cúbico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1017,'TAH','Kiloampere hora (mil amperios hora)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1018,'TC','camion','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1019,'TD','termia','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1020,'TE','totalizador','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1021,'TF','diez metros cuadrados','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1022,'TI','mil pulgadas cuadradas','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1023,'TJ','mil centímetros cuadrados','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1024,'TK','tanque, rectangular','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1025,'TL','mil pies (lineales)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1026,'TN','estaño','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1027,'TNE','tonelada (tonelada métrica)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1028,'TP','paquete de diez','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1029,'TPR','diez pares','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1030,'TQ','mil pies','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1031,'TQD','mil metros cúbicos por día','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1032,'TR','diez pies cuadrados','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1033,'TRL','trillón (EUR)','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1034,'TS','mil pies cuadrados','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1035,'TSD','tonelada de sustancia 90% seca','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1036,'TSH','tonelada de vapor por hora','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1037,'TT','mil metros lineales','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1038,'TU','tubo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1039,'TV','mil kilogramos','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1040,'TW','mil hojas','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1041,'TY','tanque, cilíndrico','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1042,'U1','tratamiento','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1043,'U2','tableta','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1044,'UA','torr','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1045,'UB','Línea de telecomunicaciones en servicio promedio.','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1046,'UC','puerto de telecomunicaciones','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1047,'UD','décimo minuto','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1048,'UE','décima hora','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1049,'UF','uso por línea de telecomunicación promedio','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1050,'UH','diez mil yardas','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1051,'UM','millones de unidades','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1052,'VA','voltio amperio por kilogramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1053,'VI','frasco','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1054,'VLT','voltio','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1055,'VQ','abultar','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1056,'VS','visitar','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1057,'W2','kilo mojado','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1058,'W4','dos semanas','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1059,'WA','vatio por kilogramo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1060,'WB','libra mojada','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1061,'WCD','cable','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1062,'WE','tonelada mojada','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1063,'WEB','weber','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1064,'WEE','semana','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1065,'WG','galon de vino','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1066,'WH','rueda','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1067,'WHR','vatios hora','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1068,'WI','peso por pulgada cuadrada','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1069,'WM','mes de trabajo','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1070,'WR','envolver','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1071,'WSD','estándar Servicios','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1072,'WTT','vatio','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1073,'WW','mililitro de agua','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1074,'X1','cadena','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1075,'YDK','yarda cuadrada','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1076,'YDQ','Yarda cúbica','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1077,'YL','cien yardas lineales','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1078,'YRD','yarda','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1079,'YT','diez yardas','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1080,'Z1','van de elevación','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1081,'Z2','pecho','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1082,'Z3','barril','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1083,'Z4','pipa','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1084,'Z5','arrastrar','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1085,'Z6','punto de conferencia','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1086,'Z8','línea de noticias de ágata','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1087,'ZP','página','2024-05-08 03:10:11','2024-05-08 03:10:11'),(1088,'ZZ','mutuamente definido','2024-05-08 03:10:11','2024-05-08 03:10:11');
/*!40000 ALTER TABLE `measurement_units` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (43,'2014_10_12_000000_create_users_table',1),(44,'2014_10_12_100000_create_password_reset_tokens_table',1),(45,'2014_10_12_100000_create_password_resets_table',1),(46,'2019_08_19_000000_create_failed_jobs_table',1),(47,'2019_12_14_000001_create_personal_access_tokens_table',1),(48,'2024_02_18_193718_category_products',1),(49,'2024_02_19_150608_sub_categories',1),(50,'2024_02_19_193730_brands',1),(51,'2024_02_19_193758_measurement_units',1),(52,'2024_02_19_193821_products',1),(53,'2024_03_04_215331_people',1),(54,'2024_03_05_162129_countries',1),(55,'2024_03_05_172018_departments',1),(56,'2024_03_06_161711_municipalities',1),(57,'2024_03_18_180327_purchase_suppliers',1),(58,'2024_03_19_154150_detail_purchase',1),(59,'2024_03_22_192215_create_sales_table',1),(60,'2024_03_29_123706_debit_note_suppliers',1),(61,'2024_04_03_164934_create_permission_tables',1),(62,'2024_04_04_141619_create_product_sale',1),(63,'2024_04_15_213512_create_credit_note_sales_table',1),(64,'2024_05_01_013003_create_credit_note_sales_product_table',1),(65,'2024_05_08_022734_create_jobs_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `municipalities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `municipalities` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` tinyint NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `departments_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `municipalities_departments_id_foreign` (`departments_id`),
  CONSTRAINT `municipalities_departments_id_foreign` FOREIGN KEY (`departments_id`) REFERENCES `departments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `municipalities` WRITE;
/*!40000 ALTER TABLE `municipalities` DISABLE KEYS */;
/*!40000 ALTER TABLE `municipalities` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `people`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `people` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `rol` enum('Cliente','Proveedor') COLLATE utf8mb4_unicode_ci NOT NULL,
  `identification_type` enum('CC','CE','DIE','TI','RC','TE','NIT','PP','NUIP','NITO','PEP') COLLATE utf8mb4_unicode_ci NOT NULL,
  `identification_number` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `person_type` enum('Persona natural','Persona jurídica') COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comercial_name` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other_name` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `surname` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `second_surname` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `digit_verification` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `people` WRITE;
/*!40000 ALTER TABLE `people` DISABLE KEYS */;
INSERT INTO `people` VALUES (1,'Cliente','CC','19002929','Persona natural',NULL,'GTK','Brayan','Alejandro','Pinilla','Vargas','5','bg@gmail.com','Sog','calle 7','10290033',1,'2024-05-08 03:15:32','2024-05-08 03:15:32'),(2,'Proveedor','NIT','839030030','Persona natural',NULL,'GTK D','Johan','kss','ksks','ksks','3','k@gmail.com','sog','calle 7','1111',1,'2024-05-08 03:16:31','2024-05-08 03:16:31');
/*!40000 ALTER TABLE `people` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'admin.usuarios.index','web','2024-05-08 03:03:05','2024-05-08 03:03:05'),(2,'admin.usuarios.edit','web','2024-05-08 03:03:05','2024-05-08 03:03:05'),(3,'admin.usuarios.update','web','2024-05-08 03:03:05','2024-05-08 03:03:05');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `product_sale`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_sale` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `sale_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `references` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` int NOT NULL,
  `selling_price` decimal(10,2) NOT NULL,
  `discounts` decimal(8,2) NOT NULL,
  `tax` decimal(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_sale_sale_id_foreign` (`sale_id`),
  KEY `product_sale_product_id_foreign` (`product_id`),
  CONSTRAINT `product_sale_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_sale_sale_id_foreign` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `product_sale` WRITE;
/*!40000 ALTER TABLE `product_sale` DISABLE KEYS */;
INSERT INTO `product_sale` VALUES (1,1,1,'QWER',3,90.00,0.00,5.00,'2024-05-08 03:22:40','2024-05-08 03:22:40'),(2,1,2,'11111',5,78.00,10.00,0.00,'2024-05-08 03:22:40','2024-05-08 03:22:40'),(3,2,3,'11111gh',3,10.00,0.00,5.00,'2024-05-08 03:23:01','2024-05-08 03:23:01'),(4,3,1,'QWER',2,90.00,10.00,5.00,'2024-05-08 03:24:06','2024-05-08 03:24:06'),(5,3,3,'11111gh',3,10.00,0.00,5.00,'2024-05-08 03:24:06','2024-05-08 03:24:06');
/*!40000 ALTER TABLE `product_sale` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name_product` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_long` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `factory_reference` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `classification_tax` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `selling_price` decimal(10,2) NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `stock` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `subcategory_product` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_products_id` bigint unsigned NOT NULL,
  `brands_id` bigint unsigned NOT NULL,
  `measurement_units_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `products_category_products_id_foreign` (`category_products_id`),
  KEY `products_brands_id_foreign` (`brands_id`),
  KEY `products_measurement_units_id_foreign` (`measurement_units_id`),
  CONSTRAINT `products_brands_id_foreign` FOREIGN KEY (`brands_id`) REFERENCES `brands` (`id`),
  CONSTRAINT `products_category_products_id_foreign` FOREIGN KEY (`category_products_id`) REFERENCES `category_products` (`id`),
  CONSTRAINT `products_measurement_units_id_foreign` FOREIGN KEY (`measurement_units_id`) REFERENCES `measurement_units` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'Popelle Master','..','QWER','5%',90.00,NULL,1,'5','Pinturas en Aceite',1,2,8,'2024-05-08 03:12:45','2024-05-08 03:12:45'),(2,'Popelle','..','11111','0%',78.00,NULL,1,'2','Pinturas en Aceite',1,2,11,'2024-05-08 03:13:24','2024-05-08 03:13:24'),(3,'Mario Kart','..','11111gh','5%',10.00,NULL,0,'4','Pinturas en Aceite',1,3,58,'2024-05-08 03:14:26','2024-05-08 07:09:30');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `purchase_suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_suppliers` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `invoice_number_purchase` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_invoice_purchase` date NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `users_id` int NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `people_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `purchase_suppliers` WRITE;
/*!40000 ALTER TABLE `purchase_suppliers` DISABLE KEYS */;
INSERT INTO `purchase_suppliers` VALUES (1,'1','2024-05-07','pre',1,1,2,'2024-05-08 03:19:35','2024-05-08 03:19:35');
/*!40000 ALTER TABLE `purchase_suppliers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES (1,1),(2,1),(3,1);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Administrador','web','2024-05-08 03:03:05','2024-05-08 03:03:05'),(2,'Trabajador','web','2024-05-08 03:03:05','2024-05-08 03:03:05');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `dates` date NOT NULL,
  `bill_numbers` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sellers` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payments_methods` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gross_totals` decimal(8,2) NOT NULL,
  `taxes_total` decimal(8,2) NOT NULL,
  `net_total` decimal(8,2) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `clients_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sales_clients_id_foreign` (`clients_id`),
  CONSTRAINT `sales_clients_id_foreign` FOREIGN KEY (`clients_id`) REFERENCES `people` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` VALUES (1,'2024-05-07','Pre-1','Camilo','Efectivo',650.00,13.50,663.50,1,1,'2024-05-08 03:22:40','2024-05-08 03:22:40'),(2,'2024-05-07','Pre-2','Camilo','Efectivo',30.00,1.50,31.50,1,1,'2024-05-08 03:23:01','2024-05-08 03:23:01'),(3,'2024-05-07','Pre-1','Camilo','Efectivo',200.00,10.00,210.00,1,1,'2024-05-08 03:24:06','2024-05-08 03:24:06');
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sub_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sub_categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sub_categories_category_id_foreign` (`category_id`),
  CONSTRAINT `sub_categories_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `category_products` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sub_categories` WRITE;
/*!40000 ALTER TABLE `sub_categories` DISABLE KEYS */;
INSERT INTO `sub_categories` VALUES (1,'Pinturas en Aceite','Pinturas en Aceite',1,'2024-05-08 03:11:44','2024-05-08 03:11:44');
/*!40000 ALTER TABLE `sub_categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `phone_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `document_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `identification_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Brayan Pinilla','B@gmail.com',NULL,'2227288222','CC','1053442698','$2y$12$YVdS0KQaFqXHgVInFKR9JucjflTRsgkinSEpJm/7Qb2DCDI.R2qJa',NULL,'2024-05-08 03:07:36','2024-05-08 03:07:36');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

