
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `brands` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `abbrevation` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `brands_code_unique` (`code`),
  UNIQUE KEY `brands_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `brands` WRITE;
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
INSERT INTO `brands` VALUES (1,'MYST','1','MYST','2024-05-21 15:20:47','2024-05-21 15:20:47'),(2,'TTN','2','TTN','2024-05-21 15:20:47','2024-05-21 15:20:47'),(3,'BTY','3','BTY','2024-05-21 15:20:47','2024-05-21 15:20:47'),(4,'UIO','4','UIO','2024-05-21 15:20:47','2024-05-21 15:20:47'),(5,'RTYR','5','RTYR','2024-05-21 15:20:47','2024-05-21 15:20:47');
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `category_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category_products` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_products_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `category_products` WRITE;
/*!40000 ALTER TABLE `category_products` DISABLE KEYS */;
INSERT INTO `category_products` VALUES (6,'Pinturas','Pinturas','2024-05-21 15:15:38','2024-05-21 15:15:38'),(7,'Madera','Madera','2024-05-21 15:15:38','2024-05-21 15:15:38'),(8,'Ceramica','Ceramica','2024-05-21 15:15:38','2024-05-21 15:15:38'),(9,'Tubos','Tubos','2024-05-21 15:15:04','2024-05-21 15:15:04'),(10,'Tornillos','Tornillos','2024-05-21 15:15:38','2024-05-21 15:15:38'),(16,'Tubos P','Tubos','2024-05-21 15:15:38','2024-05-21 15:15:38');
/*!40000 ALTER TABLE `category_products` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `countries` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` tinyint NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `credit_note_sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `credit_note_sales` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `date_invoice` date NOT NULL,
  `sellers` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payments_methods` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `gross_totals` decimal(8,2) NOT NULL,
  `taxes_total` decimal(8,2) NOT NULL,
  `net_total` decimal(8,2) NOT NULL,
  `date_credit_notes` date NOT NULL,
  `reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `clients_id` bigint unsigned NOT NULL,
  `sale_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `credit_note_sales_clients_id_foreign` (`clients_id`),
  KEY `credit_note_sales_sale_id_foreign` (`sale_id`),
  CONSTRAINT `credit_note_sales_clients_id_foreign` FOREIGN KEY (`clients_id`) REFERENCES `people` (`id`),
  CONSTRAINT `credit_note_sales_sale_id_foreign` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `credit_note_sales` WRITE;
/*!40000 ALTER TABLE `credit_note_sales` DISABLE KEYS */;
/*!40000 ALTER TABLE `credit_note_sales` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `credit_note_sales_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `credit_note_sales_product` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `credit_note_sales_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `references` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` int NOT NULL,
  `selling_price` decimal(10,2) NOT NULL,
  `discounts` decimal(8,2) NOT NULL,
  `tax` decimal(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `credit_note_sales_product_credit_note_sales_id_foreign` (`credit_note_sales_id`),
  KEY `credit_note_sales_product_product_id_foreign` (`product_id`),
  CONSTRAINT `credit_note_sales_product_credit_note_sales_id_foreign` FOREIGN KEY (`credit_note_sales_id`) REFERENCES `credit_note_sales` (`id`) ON DELETE CASCADE,
  CONSTRAINT `credit_note_sales_product_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `credit_note_sales_product` WRITE;
/*!40000 ALTER TABLE `credit_note_sales_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `credit_note_sales_product` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `debit_note_suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `debit_note_suppliers` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `debit_note_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_invoice` date NOT NULL,
  `detail_purchase_id` bigint unsigned NOT NULL,
  `users_id` bigint unsigned NOT NULL,
  `purchase_suppliers_id` int unsigned NOT NULL,
  `quantity` int NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `total` decimal(8,2) NOT NULL,
  `net_total` decimal(20,2) NOT NULL,
  `gross_total` decimal(20,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `debit_note_suppliers_detail_purchase_id_foreign` (`detail_purchase_id`),
  KEY `debit_note_suppliers_users_id_foreign` (`users_id`),
  KEY `debit_note_suppliers_purchase_suppliers_id_foreign` (`purchase_suppliers_id`),
  CONSTRAINT `debit_note_suppliers_detail_purchase_id_foreign` FOREIGN KEY (`detail_purchase_id`) REFERENCES `detail_purchase` (`id`) ON DELETE CASCADE,
  CONSTRAINT `debit_note_suppliers_purchase_suppliers_id_foreign` FOREIGN KEY (`purchase_suppliers_id`) REFERENCES `purchase_suppliers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `debit_note_suppliers_users_id_foreign` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `debit_note_suppliers` WRITE;
/*!40000 ALTER TABLE `debit_note_suppliers` DISABLE KEYS */;
/*!40000 ALTER TABLE `debit_note_suppliers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `departments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` tinyint NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `countries_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `departments_countries_id_foreign` (`countries_id`),
  CONSTRAINT `departments_countries_id_foreign` FOREIGN KEY (`countries_id`) REFERENCES `countries` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `detail_purchase`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detail_purchase` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `note` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price_unit` decimal(20,2) NOT NULL,
  `product_tax` decimal(20,2) NOT NULL,
  `quantity_units` double NOT NULL,
  `date_purchase` date NOT NULL,
  `form_of_payment` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `gross_total` decimal(20,2) NOT NULL,
  `total_tax` decimal(20,2) NOT NULL,
  `net_total` decimal(20,2) NOT NULL,
  `total_value` decimal(20,2) NOT NULL,
  `discount_total` decimal(20,2) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `method_of_payment` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `purchase_suppliers_id` int unsigned NOT NULL,
  `products_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `detail_purchase_purchase_suppliers_id_foreign` (`purchase_suppliers_id`),
  KEY `detail_purchase_products_id_foreign` (`products_id`),
  CONSTRAINT `detail_purchase_products_id_foreign` FOREIGN KEY (`products_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `detail_purchase_purchase_suppliers_id_foreign` FOREIGN KEY (`purchase_suppliers_id`) REFERENCES `purchase_suppliers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `detail_purchase` WRITE;
/*!40000 ALTER TABLE `detail_purchase` DISABLE KEYS */;
/*!40000 ALTER TABLE `detail_purchase` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
INSERT INTO `failed_jobs` VALUES (1,'19b71254-f415-4725-9430-b5da7aebee9f','database','default','{\"uuid\":\"19b71254-f415-4725-9430-b5da7aebee9f\",\"displayName\":\"App\\\\Jobs\\\\BackupProcess\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"App\\\\Jobs\\\\BackupProcess\",\"command\":\"O:22:\\\"App\\\\Jobs\\\\BackupProcess\\\":0:{}\"}}','Illuminate\\Queue\\MaxAttemptsExceededException: App\\Jobs\\BackupProcess has been attempted too many times. in C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\MaxAttemptsExceededException.php:24\nStack trace:\n#0 C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(785): Illuminate\\Queue\\MaxAttemptsExceededException::forJob()\n#1 C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(519): Illuminate\\Queue\\Worker->maxAttemptsExceededException()\n#2 C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(428): Illuminate\\Queue\\Worker->markJobAsFailedIfAlreadyExceedsMaxAttempts()\n#3 C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(389): Illuminate\\Queue\\Worker->process()\n#4 C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(176): Illuminate\\Queue\\Worker->runJob()\n#5 C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Console\\WorkCommand.php(137): Illuminate\\Queue\\Worker->daemon()\n#6 C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Console\\WorkCommand.php(120): Illuminate\\Queue\\Console\\WorkCommand->runWorker()\n#7 C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(36): Illuminate\\Queue\\Console\\WorkCommand->handle()\n#8 C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Util.php(41): Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}()\n#9 C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(93): Illuminate\\Container\\Util::unwrapIfClosure()\n#10 C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod()\n#11 C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Container.php(662): Illuminate\\Container\\BoundMethod::call()\n#12 C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Command.php(211): Illuminate\\Container\\Container->call()\n#13 C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\symfony\\console\\Command\\Command.php(326): Illuminate\\Console\\Command->execute()\n#14 C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Command.php(180): Symfony\\Component\\Console\\Command\\Command->run()\n#15 C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\symfony\\console\\Application.php(1096): Illuminate\\Console\\Command->run()\n#16 C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\symfony\\console\\Application.php(324): Symfony\\Component\\Console\\Application->doRunCommand()\n#17 C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\symfony\\console\\Application.php(175): Symfony\\Component\\Console\\Application->doRun()\n#18 C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Console\\Kernel.php(201): Symfony\\Component\\Console\\Application->run()\n#19 C:\\laragon\\www\\db_hardware\\db_hardware\\artisan(35): Illuminate\\Foundation\\Console\\Kernel->handle()\n#20 {main}','2024-05-21 20:22:34');
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
INSERT INTO `jobs` VALUES (4,'default','{\"uuid\":\"7186eb55-c79b-4737-a313-251ab303be68\",\"displayName\":\"App\\\\Jobs\\\\BackupProcess\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"App\\\\Jobs\\\\BackupProcess\",\"command\":\"O:22:\\\"App\\\\Jobs\\\\BackupProcess\\\":0:{}\"}}',1,1716327403,1716327396,1716327396);
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `measurement_units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `measurement_units` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `measurement_units_code_unique` (`code`),
  UNIQUE KEY `measurement_units_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=1090 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `measurement_units` WRITE;
/*!40000 ALTER TABLE `measurement_units` DISABLE KEYS */;
INSERT INTO `measurement_units` VALUES (1,'10','grupo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(2,'11','equipar','2024-05-21 15:29:22','2024-05-21 15:29:22'),(3,'13','ración','2024-05-21 15:29:22','2024-05-21 15:29:22'),(4,'14','Disparo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(5,'15','palo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(6,'16','tambor de ciento quince kg','2024-05-21 15:29:22','2024-05-21 15:29:22'),(7,'17','tambor de cien libras','2024-05-21 15:29:22','2024-05-21 15:29:22'),(8,'18','tambor de cincuenta y cinco galones (US)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(9,'19','camión cisterna','2024-05-21 15:29:22','2024-05-21 15:29:22'),(10,'20','contenedor de veinte pies','2024-05-21 15:29:22','2024-05-21 15:29:22'),(11,'21','contenedor de cuarenta pies','2024-05-21 15:29:22','2024-05-21 15:29:22'),(12,'22','decilitro por gramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(13,'23','gramo por centímetro cúbico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(14,'24','libra teórica','2024-05-21 15:29:22','2024-05-21 15:29:22'),(15,'25','gramo por centímetro cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(16,'26','tonelada real','2024-05-21 15:29:22','2024-05-21 15:29:22'),(17,'54','tonelada teórica','2024-05-21 15:29:22','2024-05-21 15:29:22'),(18,'28','kilogramo por metro cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(19,'29','libra por mil pies cuadrados','2024-05-21 15:29:22','2024-05-21 15:29:22'),(20,'30','Día de potencia del caballo por tonelada métrica seca al aire.','2024-05-21 15:29:22','2024-05-21 15:29:22'),(21,'31','coger peso','2024-05-21 15:29:22','2024-05-21 15:29:22'),(22,'32','kilogramo por aire seco tonelada métrica','2024-05-21 15:29:22','2024-05-21 15:29:22'),(23,'33','kilopascales metros cuadrados por gramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(24,'34','kilopascales por milímetro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(25,'35','mililitros por centímetro cuadrado segundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(26,'36','pies cúbicos por minuto por pie cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(27,'37','onza por pie cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(28,'38','onzas por pie cuadrado por 0,01 pulgadas','2024-05-21 15:29:22','2024-05-21 15:29:22'),(29,'40','mililitro por segundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(30,'41','mililitro por minuto','2024-05-21 15:29:22','2024-05-21 15:29:22'),(31,'43','bolsa súper a granel','2024-05-21 15:29:22','2024-05-21 15:29:22'),(32,'44','bolsa a granel de quinientos kg','2024-05-21 15:29:22','2024-05-21 15:29:22'),(33,'45','bolsa a granel de trescientos kg','2024-05-21 15:29:22','2024-05-21 15:29:22'),(34,'46','bolsa a granel de cincuenta libras','2024-05-21 15:29:22','2024-05-21 15:29:22'),(35,'47','bolsa de cincuenta libras','2024-05-21 15:29:22','2024-05-21 15:29:22'),(36,'48','carga de automóviles a granel','2024-05-21 15:29:22','2024-05-21 15:29:22'),(37,'53','kilogramos teóricos','2024-05-21 15:29:22','2024-05-21 15:29:22'),(38,'56','sitas','2024-05-21 15:29:22','2024-05-21 15:29:22'),(39,'57','malla','2024-05-21 15:29:22','2024-05-21 15:29:22'),(40,'58','kilogramo neto','2024-05-21 15:29:22','2024-05-21 15:29:22'),(41,'59','parte por millón','2024-05-21 15:29:22','2024-05-21 15:29:22'),(42,'60','porcentaje de peso','2024-05-21 15:29:22','2024-05-21 15:29:22'),(43,'61','parte por billón (US)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(44,'62','porcentaje por 1000 horas','2024-05-21 15:29:22','2024-05-21 15:29:22'),(45,'63','tasa de fracaso en el tiempo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(46,'64','libra por pulgada cuadrada, calibre','2024-05-21 15:29:22','2024-05-21 15:29:22'),(47,'66','Oersted','2024-05-21 15:29:22','2024-05-21 15:29:22'),(48,'69','prueba de escala específica','2024-05-21 15:29:22','2024-05-21 15:29:22'),(49,'71','voltio amperio por libra','2024-05-21 15:29:22','2024-05-21 15:29:22'),(50,'72','vatio por libra','2024-05-21 15:29:22','2024-05-21 15:29:22'),(51,'73','amperio tum por centímetro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(52,'74','milipascal','2024-05-21 15:29:22','2024-05-21 15:29:22'),(53,'76','gauss','2024-05-21 15:29:22','2024-05-21 15:29:22'),(54,'77','mili pulgadas','2024-05-21 15:29:22','2024-05-21 15:29:22'),(55,'78','kilogauss','2024-05-21 15:29:22','2024-05-21 15:29:22'),(56,'80','libras por pulgada cuadrada absoluta','2024-05-21 15:29:22','2024-05-21 15:29:22'),(57,'81','Enrique','2024-05-21 15:29:22','2024-05-21 15:29:22'),(58,'84','kilopound por pulgada cuadrada','2024-05-21 15:29:22','2024-05-21 15:29:22'),(59,'85','fuerza libra pie','2024-05-21 15:29:22','2024-05-21 15:29:22'),(60,'87','libra por pie cúbico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(61,'89','equilibrio','2024-05-21 15:29:22','2024-05-21 15:29:22'),(62,'90','Saybold segundo universal','2024-05-21 15:29:22','2024-05-21 15:29:22'),(63,'91','alimenta','2024-05-21 15:29:22','2024-05-21 15:29:22'),(64,'92','calorías por centímetro cúbico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(65,'93','calorías por gramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(66,'94','unidad','2024-05-21 15:29:22','2024-05-21 15:29:22'),(67,'95','veinte mil galones (US) de carros','2024-05-21 15:29:22','2024-05-21 15:29:22'),(68,'96','diez mil galones (US) de carros','2024-05-21 15:29:22','2024-05-21 15:29:22'),(69,'97','tambor de diez kg','2024-05-21 15:29:22','2024-05-21 15:29:22'),(70,'98','tambor de quince kg','2024-05-21 15:29:22','2024-05-21 15:29:22'),(71,'04','spray pequeños','2024-05-21 15:29:22','2024-05-21 15:29:22'),(72,'05','levantar','2024-05-21 15:29:22','2024-05-21 15:29:22'),(73,'08','Lote calor','2024-05-21 15:29:22','2024-05-21 15:29:22'),(74,'1A','milla de coche','2024-05-21 15:29:22','2024-05-21 15:29:22'),(75,'1B','recuento de coches','2024-05-21 15:29:22','2024-05-21 15:29:22'),(76,'1C','recuento de locomotoras','2024-05-21 15:29:22','2024-05-21 15:29:22'),(77,'1D','recuento de cabos','2024-05-21 15:29:22','2024-05-21 15:29:22'),(78,'1E','carro vacio','2024-05-21 15:29:22','2024-05-21 15:29:22'),(79,'1F','millas de tren','2024-05-21 15:29:22','2024-05-21 15:29:22'),(80,'1G','uso de combustible galón (US)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(81,'1H','milla del caboose','2024-05-21 15:29:22','2024-05-21 15:29:22'),(82,'1I','tipo de interés fijo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(83,'1J','tonelada milla','2024-05-21 15:29:22','2024-05-21 15:29:22'),(84,'1K','milla locomotora','2024-05-21 15:29:22','2024-05-21 15:29:22'),(85,'1L','recuento total de coches','2024-05-21 15:29:22','2024-05-21 15:29:22'),(86,'1M','milla de coche total','2024-05-21 15:29:22','2024-05-21 15:29:22'),(87,'1X','cuarto de milla','2024-05-21 15:29:22','2024-05-21 15:29:22'),(88,'2A','radianes por segundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(89,'2B','radianes por segundo al cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(90,'2C','Röntgen','2024-05-21 15:29:22','2024-05-21 15:29:22'),(91,'2I','Unidad térmica británica por hora.','2024-05-21 15:29:22','2024-05-21 15:29:22'),(92,'2J','centímetro cúbico por segundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(93,'2K','pie cúbico por hora','2024-05-21 15:29:22','2024-05-21 15:29:22'),(94,'2L','pie cúbico por minuto','2024-05-21 15:29:22','2024-05-21 15:29:22'),(95,'2M','centímetro por segundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(96,'2N','decibel','2024-05-21 15:29:22','2024-05-21 15:29:22'),(97,'2P','kilobyte','2024-05-21 15:29:22','2024-05-21 15:29:22'),(98,'2Q','kilobecquerel','2024-05-21 15:29:22','2024-05-21 15:29:22'),(99,'2R','kilocurie','2024-05-21 15:29:22','2024-05-21 15:29:22'),(100,'2U','megagramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(101,'2V','megagramo por hora','2024-05-21 15:29:22','2024-05-21 15:29:22'),(102,'2W','compartimiento','2024-05-21 15:29:22','2024-05-21 15:29:22'),(103,'2X','metro por minuto','2024-05-21 15:29:22','2024-05-21 15:29:22'),(104,'2Y','milliröntgen','2024-05-21 15:29:22','2024-05-21 15:29:22'),(105,'2Z','milivoltios','2024-05-21 15:29:22','2024-05-21 15:29:22'),(106,'3B','megajulio','2024-05-21 15:29:22','2024-05-21 15:29:22'),(107,'3C','manmonth','2024-05-21 15:29:22','2024-05-21 15:29:22'),(108,'3E','libra por libra de producto','2024-05-21 15:29:22','2024-05-21 15:29:22'),(109,'3G','libra por pieza de producto','2024-05-21 15:29:22','2024-05-21 15:29:22'),(110,'3H','kilogramo por kilogramo de producto','2024-05-21 15:29:22','2024-05-21 15:29:22'),(111,'3I','kilogramo por pieza de producto','2024-05-21 15:29:22','2024-05-21 15:29:22'),(112,'CL','bobina','2024-05-21 15:29:22','2024-05-21 15:29:22'),(113,'4B','gorra','2024-05-21 15:29:22','2024-05-21 15:29:22'),(114,'4C','centistokes','2024-05-21 15:29:22','2024-05-21 15:29:22'),(115,'4E','paquete de veinte','2024-05-21 15:29:22','2024-05-21 15:29:22'),(116,'4G','microlitro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(117,'4H','micrometro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(118,'4K','miliamperio','2024-05-21 15:29:22','2024-05-21 15:29:22'),(119,'4L','megabyte','2024-05-21 15:29:22','2024-05-21 15:29:22'),(120,'4M','miligramo por hora','2024-05-21 15:29:22','2024-05-21 15:29:22'),(121,'4N','megabecquerel','2024-05-21 15:29:22','2024-05-21 15:29:22'),(122,'4O','microfarad','2024-05-21 15:29:22','2024-05-21 15:29:22'),(123,'4P','newton por metro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(124,'4Q','onza pulgada','2024-05-21 15:29:22','2024-05-21 15:29:22'),(125,'4R','pie onza','2024-05-21 15:29:22','2024-05-21 15:29:22'),(126,'4T','picofarad','2024-05-21 15:29:22','2024-05-21 15:29:22'),(127,'4U','libra por hora','2024-05-21 15:29:22','2024-05-21 15:29:22'),(128,'4W','tonelada (US) por hora','2024-05-21 15:29:22','2024-05-21 15:29:22'),(129,'4X','kilolitro por hora','2024-05-21 15:29:22','2024-05-21 15:29:22'),(130,'BTU','Unidad Térmica Británica','2024-05-21 15:29:22','2024-05-21 15:29:22'),(131,'BUA','bushel (EE. UU.)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(132,'BUI','bushel (Reino Unido)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(133,'BW','peso base','2024-05-21 15:29:22','2024-05-21 15:29:22'),(134,'CR','caja','2024-05-21 15:29:22','2024-05-21 15:29:22'),(135,'BZ','millones de BTUs','2024-05-21 15:29:22','2024-05-21 15:29:22'),(136,'C0','llamada','2024-05-21 15:29:22','2024-05-21 15:29:22'),(137,'C1','producto compuesto libra (peso total)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(138,'C10','millifarad','2024-05-21 15:29:22','2024-05-21 15:29:22'),(139,'C11','miligal','2024-05-21 15:29:22','2024-05-21 15:29:22'),(140,'C12','miligramo por metro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(141,'C13','miligray','2024-05-21 15:29:22','2024-05-21 15:29:22'),(142,'C14','milihenry','2024-05-21 15:29:22','2024-05-21 15:29:22'),(143,'C15','milijoule','2024-05-21 15:29:22','2024-05-21 15:29:22'),(144,'C16','milímetro por segundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(145,'C17','milímetro cuadrado por segundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(146,'C18','milimol','2024-05-21 15:29:22','2024-05-21 15:29:22'),(147,'C19','mol por kilogramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(148,'C2','carset','2024-05-21 15:29:22','2024-05-21 15:29:22'),(149,'C20','millinewton','2024-05-21 15:29:22','2024-05-21 15:29:22'),(150,'C22','millinewton por metro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(151,'C23','medidor de miliohm','2024-05-21 15:29:22','2024-05-21 15:29:22'),(152,'C24','segundo milipascal','2024-05-21 15:29:22','2024-05-21 15:29:22'),(153,'C25','miliradian','2024-05-21 15:29:22','2024-05-21 15:29:22'),(154,'C26','milisegundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(155,'C27','milisiemens','2024-05-21 15:29:22','2024-05-21 15:29:22'),(156,'C28','milisievert','2024-05-21 15:29:22','2024-05-21 15:29:22'),(157,'C29','millitesla','2024-05-21 15:29:22','2024-05-21 15:29:22'),(158,'C3','microvoltios por metro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(159,'INK','pulgada cuadrada','2024-05-21 15:29:22','2024-05-21 15:29:22'),(160,'INQ','pulgada en cubos','2024-05-21 15:29:22','2024-05-21 15:29:22'),(161,'IP','póliza de seguros','2024-05-21 15:29:22','2024-05-21 15:29:22'),(162,'IT','conteo por centímetro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(163,'IU','pulgada por segundo (velocidad lineal)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(164,'IV','pulgada por segundo al cuadrado (aceleración)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(165,'J2','julios por kilogramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(166,'JB','jumbo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(167,'JE','joule por kelvin','2024-05-21 15:29:22','2024-05-21 15:29:22'),(168,'JG','jarra','2024-05-21 15:29:22','2024-05-21 15:29:22'),(169,'JK','megajulio por kilogramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(170,'JM','megajulio por metro cúbico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(171,'JO','articulación','2024-05-21 15:29:22','2024-05-21 15:29:22'),(172,'JOU','joule','2024-05-21 15:29:22','2024-05-21 15:29:22'),(173,'JR','tarro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(174,'K1','demanda de kilovatios','2024-05-21 15:29:22','2024-05-21 15:29:22'),(175,'K2','kilovoltios amperios reactivos de demanda','2024-05-21 15:29:22','2024-05-21 15:29:22'),(176,'K3','kilovoltio amperio hora reactiva','2024-05-21 15:29:22','2024-05-21 15:29:22'),(177,'K5','amperios kilovoltios (reactivos)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(178,'K6','kilolitro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(179,'KA','pastel','2024-05-21 15:29:22','2024-05-21 15:29:22'),(180,'KB','kilocharacter','2024-05-21 15:29:22','2024-05-21 15:29:22'),(181,'KBA','kilobar','2024-05-21 15:29:22','2024-05-21 15:29:22'),(182,'KD','kilogramo decimal','2024-05-21 15:29:22','2024-05-21 15:29:22'),(183,'KEL','kelvin','2024-05-21 15:29:22','2024-05-21 15:29:22'),(184,'KF','kilopacket','2024-05-21 15:29:22','2024-05-21 15:29:22'),(185,'KG','barrilete','2024-05-21 15:29:22','2024-05-21 15:29:22'),(186,'KGM','kilogramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(187,'KGS','kilogramo por segundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(188,'KHZ','kilohercio','2024-05-21 15:29:22','2024-05-21 15:29:22'),(189,'5A','barril por minuto','2024-05-21 15:29:22','2024-05-21 15:29:22'),(190,'5B','lote','2024-05-21 15:29:22','2024-05-21 15:29:22'),(191,'5C','galón (US) por mil','2024-05-21 15:29:22','2024-05-21 15:29:22'),(192,'5E','MMSCF / día','2024-05-21 15:29:22','2024-05-21 15:29:22'),(193,'5F','libras por mil','2024-05-21 15:29:22','2024-05-21 15:29:22'),(194,'5G','bomba','2024-05-21 15:29:22','2024-05-21 15:29:22'),(195,'5H','escenario','2024-05-21 15:29:22','2024-05-21 15:29:22'),(196,'5I','pie cúbico estándar','2024-05-21 15:29:22','2024-05-21 15:29:22'),(197,'5J','potencia hidráulica de caballos','2024-05-21 15:29:22','2024-05-21 15:29:22'),(198,'5K','contar por minuto','2024-05-21 15:29:22','2024-05-21 15:29:22'),(199,'5P','nivel sismico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(200,'5Q','260nfor sismica','2024-05-21 15:29:22','2024-05-21 15:29:22'),(201,'A1','15 calorías C','2024-05-21 15:29:22','2024-05-21 15:29:22'),(202,'A10','amperio metro cuadrado por joule segundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(203,'A11','Ã ¥ ngström','2024-05-21 15:29:22','2024-05-21 15:29:22'),(204,'A12','unidad astronómica','2024-05-21 15:29:22','2024-05-21 15:29:22'),(205,'A13','attojoule','2024-05-21 15:29:22','2024-05-21 15:29:22'),(206,'A14','granero','2024-05-21 15:29:22','2024-05-21 15:29:22'),(207,'A15','granero por electrón voltio','2024-05-21 15:29:22','2024-05-21 15:29:22'),(208,'A16','granero por voltio de electrones esteradiano,','2024-05-21 15:29:22','2024-05-21 15:29:22'),(209,'A17','granero por sterdian','2024-05-21 15:29:22','2024-05-21 15:29:22'),(210,'A18','becquerel por kilogramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(211,'A19','becquerel por metro cúbico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(212,'A2','amperio por centímetro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(213,'A20','Unidad térmica británica por segundo pie cuadrado grado Rankin','2024-05-21 15:29:22','2024-05-21 15:29:22'),(214,'A21','Unidad térmica británica por libra grado Rankin','2024-05-21 15:29:22','2024-05-21 15:29:22'),(215,'A22','Unidad térmica británica por segundo pie grado Rankin','2024-05-21 15:29:22','2024-05-21 15:29:22'),(216,'A23','Unidad térmica británica por hora pie cuadrado grado Rankin','2024-05-21 15:29:22','2024-05-21 15:29:22'),(217,'A24','candela por metro cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(218,'A25','cheval vapeur','2024-05-21 15:29:22','2024-05-21 15:29:22'),(219,'A26','medidor de culombio','2024-05-21 15:29:22','2024-05-21 15:29:22'),(220,'A27','medidor de culombio al cuadrado por voltio','2024-05-21 15:29:22','2024-05-21 15:29:22'),(221,'A28','Coulomb por centímetro cúbico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(222,'A29','Coulomb por metro cúbico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(223,'A3','amperio por milímetro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(224,'A30','Coulomb por milímetro cúbico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(225,'A31','Coulomb por kilogramo segundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(226,'A32','Coulomb por mol','2024-05-21 15:29:22','2024-05-21 15:29:22'),(227,'A33','Coulomb por centímetro cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(228,'A34','Coulomb por metro cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(229,'A35','Coulomb por milímetro cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(230,'A36','centímetro cúbico por mol','2024-05-21 15:29:22','2024-05-21 15:29:22'),(231,'A37','261nformaci cúbico por mol','2024-05-21 15:29:22','2024-05-21 15:29:22'),(232,'A38','metro cúbico por coulomb','2024-05-21 15:29:22','2024-05-21 15:29:22'),(233,'A39','metro cúbico por kilogramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(234,'A4','amperio por centímetro cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(235,'A40','metro cúbico por mol','2024-05-21 15:29:22','2024-05-21 15:29:22'),(236,'A41','amperio por metro cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(237,'A42','curie por kilogramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(238,'A43','tonelaje de peso muerto','2024-05-21 15:29:22','2024-05-21 15:29:22'),(239,'A44','decalitro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(240,'A45','decámetro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(241,'A47','decitex','2024-05-21 15:29:22','2024-05-21 15:29:22'),(242,'A48','grado Rankin','2024-05-21 15:29:22','2024-05-21 15:29:22'),(243,'A49','negador','2024-05-21 15:29:22','2024-05-21 15:29:22'),(244,'A5','amperio metro cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(245,'A50','dyn segundo por centímetro cúbico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(246,'A51','dina segundo por centímetro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(247,'A52','dina segundo por centímetro al quinto','2024-05-21 15:29:22','2024-05-21 15:29:22'),(248,'A53','electronvolt','2024-05-21 15:29:22','2024-05-21 15:29:22'),(249,'A54','electronvoltio por metro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(250,'A55','metro electronvolt cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(251,'A56','electronvoltio de metro cuadrado por kilogramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(252,'A57','ergio','2024-05-21 15:29:22','2024-05-21 15:29:22'),(253,'A58','erg por centímetro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(254,'A6','amperio por metro cuadrado kelvin al cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(255,'A60','erg por centímetro cúbico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(256,'A61','erg por gramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(257,'A62','erg por gramo de segundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(258,'A63','erg por segundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(259,'A64','erg por segundo centímetro cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(260,'A65','erg por centímetro cuadrado segundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(261,'A66','erg centímetro cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(262,'A67','ergímetro cuadrado por gramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(263,'A68','exajulio','2024-05-21 15:29:22','2024-05-21 15:29:22'),(264,'A69','faradio por metro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(265,'A7','amperio por milímetro cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(266,'A70','femtojoule','2024-05-21 15:29:22','2024-05-21 15:29:22'),(267,'A71','femtometro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(268,'A73','pie por segundo al cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(269,'A74','pie-fuerza de la libra por segundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(270,'A75','tonelada de carga','2024-05-21 15:29:22','2024-05-21 15:29:22'),(271,'GLL','galón','2024-05-21 15:29:22','2024-05-21 15:29:22'),(272,'A77','Unidad de desplazamiento CGS gaussiana','2024-05-21 15:29:22','2024-05-21 15:29:22'),(273,'A78','Unidad gaussiana CGS de corriente eléctrica.','2024-05-21 15:29:22','2024-05-21 15:29:22'),(274,'A79','Unidad Gaussian CGS de carga eléctrica.','2024-05-21 15:29:22','2024-05-21 15:29:22'),(275,'A8','amperio segundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(276,'A80','Unidad Gaussian CGS de intensidad de campo eléctrico.','2024-05-21 15:29:22','2024-05-21 15:29:22'),(277,'A81','Unidad Gaussian CGS de polarización eléctrica.','2024-05-21 15:29:22','2024-05-21 15:29:22'),(278,'A82','Unidad Gaussian CGS de potencial eléctrico.','2024-05-21 15:29:22','2024-05-21 15:29:22'),(279,'A83','Unidad Gaussiana CGS de magnetización.','2024-05-21 15:29:22','2024-05-21 15:29:22'),(280,'A84','gigacoulomb por metro cúbico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(281,'A85','Gigaelectronvolt','2024-05-21 15:29:22','2024-05-21 15:29:22'),(282,'A86','gigahercios','2024-05-21 15:29:22','2024-05-21 15:29:22'),(283,'A87','gigaohm','2024-05-21 15:29:22','2024-05-21 15:29:22'),(284,'A88','medidor de gigaohm','2024-05-21 15:29:22','2024-05-21 15:29:22'),(285,'A89','gigapascal','2024-05-21 15:29:22','2024-05-21 15:29:22'),(286,'A9','tarifa','2024-05-21 15:29:22','2024-05-21 15:29:22'),(287,'A90','gigavatios','2024-05-21 15:29:22','2024-05-21 15:29:22'),(288,'A91','gon','2024-05-21 15:29:22','2024-05-21 15:29:22'),(289,'A93','gramo por metro cúbico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(290,'A94','gramo por mol','2024-05-21 15:29:22','2024-05-21 15:29:22'),(291,'gris','A95','2024-05-21 15:29:22','2024-05-21 15:29:22'),(292,'A96','gris por segundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(293,'A97','hectopascal','2024-05-21 15:29:22','2024-05-21 15:29:22'),(294,'A98','Henry por metro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(295,'AA','bola','2024-05-21 15:29:22','2024-05-21 15:29:22'),(296,'AB','paquete a granel','2024-05-21 15:29:22','2024-05-21 15:29:22'),(297,'ACR','acre','2024-05-21 15:29:22','2024-05-21 15:29:22'),(298,'AD','byte','2024-05-21 15:29:22','2024-05-21 15:29:22'),(299,'AE','amperio por metro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(300,'AH','minuto adicional','2024-05-21 15:29:22','2024-05-21 15:29:22'),(301,'AI','minuto promedio por llamada','2024-05-21 15:29:22','2024-05-21 15:29:22'),(302,'AJ','policía','2024-05-21 15:29:22','2024-05-21 15:29:22'),(303,'AK','braza','2024-05-21 15:29:22','2024-05-21 15:29:22'),(304,'AL','263nfor de acceso','2024-05-21 15:29:22','2024-05-21 15:29:22'),(305,'AM','ampolla','2024-05-21 15:29:22','2024-05-21 15:29:22'),(306,'AMH','hora amperio','2024-05-21 15:29:22','2024-05-21 15:29:22'),(307,'AMP','amperio','2024-05-21 15:29:22','2024-05-21 15:29:22'),(308,'ANA','año','2024-05-21 15:29:22','2024-05-21 15:29:22'),(309,'AP','solo libra de aluminio','2024-05-21 15:29:22','2024-05-21 15:29:22'),(310,'APZ','onza troy o onza de boticarios','2024-05-21 15:29:22','2024-05-21 15:29:22'),(311,'AQ','Unidad de factor antihemofílico (AHF)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(312,'AR','supositorio','2024-05-21 15:29:22','2024-05-21 15:29:22'),(313,'SON','son','2024-05-21 15:29:22','2024-05-21 15:29:22'),(314,'COMO','surtido','2024-05-21 15:29:22','2024-05-21 15:29:22'),(315,'ASM','fuerza alcohólica en masa','2024-05-21 15:29:22','2024-05-21 15:29:22'),(316,'ASU','fuerza alcohólica por volumen','2024-05-21 15:29:22','2024-05-21 15:29:22'),(317,'ATM','ambiente estándar','2024-05-21 15:29:22','2024-05-21 15:29:22'),(318,'ATT','ambiente técnico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(319,'AV','cápsula','2024-05-21 15:29:22','2024-05-21 15:29:22'),(320,'AW','vial lleno de polvo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(321,'SÍ','montaje','2024-05-21 15:29:22','2024-05-21 15:29:22'),(322,'AZ','Unidad térmica británica por libra','2024-05-21 15:29:22','2024-05-21 15:29:22'),(323,'B0','Btu por pie cúbico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(324,'B1','barril (US) por día','2024-05-21 15:29:22','2024-05-21 15:29:22'),(325,'B11','julios por kilogramo kelvin','2024-05-21 15:29:22','2024-05-21 15:29:22'),(326,'B12','julios por metro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(327,'B13','julios por metro cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(328,'B14','julios por metro a la cuarta potencia','2024-05-21 15:29:22','2024-05-21 15:29:22'),(329,'B15','julios por mol','2024-05-21 15:29:22','2024-05-21 15:29:22'),(330,'B16','julios por mol kelvin','2024-05-21 15:29:22','2024-05-21 15:29:22'),(331,'B18','joule segundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(332,'B2','litera','2024-05-21 15:29:22','2024-05-21 15:29:22'),(333,'B20','joule metro cuadrado por kilogramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(334,'B21','kelvin por vatio','2024-05-21 15:29:22','2024-05-21 15:29:22'),(335,'B22','Kiloampere','2024-05-21 15:29:22','2024-05-21 15:29:22'),(336,'B23','kiloampere por metro cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(337,'B24','kiloampere por metro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(338,'B25','kilobecquerel por kilogramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(339,'B26','kilocoulomb','2024-05-21 15:29:22','2024-05-21 15:29:22'),(340,'B27','kilocoulomb por metro cúbico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(341,'B28','kilocoulomb por metro cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(342,'B29','kiloelectronvolt','2024-05-21 15:29:22','2024-05-21 15:29:22'),(343,'B3','libra de bateo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(344,'B31','kilogramo metro por segundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(345,'B32','kilogramo metro cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(346,'B33','kilogramo metro cuadrado por segundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(347,'B34','kilogramo por decímetro cúbico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(348,'B35','kilogramo por litro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(349,'B36','caloría termoquímica por gramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(350,'B37','kilogramo de fuerza','2024-05-21 15:29:22','2024-05-21 15:29:22'),(351,'B38','metro de fuerza de kilogramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(352,'B39','metro de fuerza de kilogramo por segundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(353,'B4','barril, imperial','2024-05-21 15:29:22','2024-05-21 15:29:22'),(354,'B40','kilogramo de fuerza por metro cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(355,'B41','kilojoule per kelvin','2024-05-21 15:29:22','2024-05-21 15:29:22'),(356,'B42','kilojoule por kilogramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(357,'B43','kilojoule por kilogramo kelvin','2024-05-21 15:29:22','2024-05-21 15:29:22'),(358,'B44','kilojoule por mol','2024-05-21 15:29:22','2024-05-21 15:29:22'),(359,'B45','kilomol','2024-05-21 15:29:22','2024-05-21 15:29:22'),(360,'B46','kilomol por metro cúbico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(361,'B47','Kilonewton','2024-05-21 15:29:22','2024-05-21 15:29:22'),(362,'B48','medidor de kilonewton','2024-05-21 15:29:22','2024-05-21 15:29:22'),(363,'B49','kiloohm','2024-05-21 15:29:22','2024-05-21 15:29:22'),(364,'B5','palanquilla','2024-05-21 15:29:22','2024-05-21 15:29:22'),(365,'B50','medidor de kiloohm','2024-05-21 15:29:22','2024-05-21 15:29:22'),(366,'B51','kilopond','2024-05-21 15:29:22','2024-05-21 15:29:22'),(367,'B52','kilosegundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(368,'B53','kilosiemens','2024-05-21 15:29:22','2024-05-21 15:29:22'),(369,'B54','kilosiemens por metro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(370,'B55','kilovoltios por metro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(371,'B56','kiloveber por metro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(372,'B57','año luz','2024-05-21 15:29:22','2024-05-21 15:29:22'),(373,'B58','litro por mol','2024-05-21 15:29:22','2024-05-21 15:29:22'),(374,'B59','hora lumen','2024-05-21 15:29:22','2024-05-21 15:29:22'),(375,'B6','bollo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(376,'B60','lumen por metro cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(377,'B61','lumen por vatio','2024-05-21 15:29:22','2024-05-21 15:29:22'),(378,'B62','lumen segundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(379,'B63','hora de lux','2024-05-21 15:29:22','2024-05-21 15:29:22'),(380,'B64','lux segundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(381,'B65','Maxwell','2024-05-21 15:29:22','2024-05-21 15:29:22'),(382,'B66','megaamperios por metro cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(383,'B67','megabecquerel por kilogramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(384,'B69','megacoulomb por metro cúbico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(385,'B7','ciclo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(386,'B70','megacoulomb por metro cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(387,'B71','megaelectronvolt','2024-05-21 15:29:22','2024-05-21 15:29:22'),(388,'B72','megagramo por metro cúbico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(389,'B73','meganewton','2024-05-21 15:29:22','2024-05-21 15:29:22'),(390,'B74','medidor de meganewton','2024-05-21 15:29:22','2024-05-21 15:29:22'),(391,'B75','megaohm','2024-05-21 15:29:22','2024-05-21 15:29:22'),(392,'B76','metro megaohm','2024-05-21 15:29:22','2024-05-21 15:29:22'),(393,'B77','megasiemens por metro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(394,'B78','megavoltio','2024-05-21 15:29:22','2024-05-21 15:29:22'),(395,'B79','megavolt por metro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(396,'B8','julios por metro cúbico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(397,'B81','metro recíproco cuadrado recíproco segundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(398,'B83','metro a la cuarta potencia','2024-05-21 15:29:22','2024-05-21 15:29:22'),(399,'B84','microamperios','2024-05-21 15:29:22','2024-05-21 15:29:22'),(400,'B85','microbar','2024-05-21 15:29:22','2024-05-21 15:29:22'),(401,'B86','microcoulomb','2024-05-21 15:29:22','2024-05-21 15:29:22'),(402,'B87','microcoulomb por metro cúbico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(403,'B88','microcoulomb por metro cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(404,'B89','microfarada por metro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(405,'B9','batt','2024-05-21 15:29:22','2024-05-21 15:29:22'),(406,'B90','microhenry','2024-05-21 15:29:22','2024-05-21 15:29:22'),(407,'B91','microhenry por metro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(408,'B92','micronewton','2024-05-21 15:29:22','2024-05-21 15:29:22'),(409,'B93','medidor de micronewton','2024-05-21 15:29:22','2024-05-21 15:29:22'),(410,'B94','microohm','2024-05-21 15:29:22','2024-05-21 15:29:22'),(411,'B95','medidor de microohmios','2024-05-21 15:29:22','2024-05-21 15:29:22'),(412,'B96','micropascal','2024-05-21 15:29:22','2024-05-21 15:29:22'),(413,'B97','microradiano','2024-05-21 15:29:22','2024-05-21 15:29:22'),(414,'B98','microsegundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(415,'B99','microsiemens','2024-05-21 15:29:22','2024-05-21 15:29:22'),(416,'BR','bar','2024-05-21 15:29:22','2024-05-21 15:29:22'),(417,'BB','caja base','2024-05-21 15:29:22','2024-05-21 15:29:22'),(418,'BD','tablero','2024-05-21 15:29:22','2024-05-21 15:29:22'),(419,'haz','SER','2024-05-21 15:29:22','2024-05-21 15:29:22'),(420,'BFT','pie de tabla','2024-05-21 15:29:22','2024-05-21 15:29:22'),(421,'BG','bolso','2024-05-21 15:29:22','2024-05-21 15:29:22'),(422,'BH','cepillo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(423,'BHP','potencia al freno','2024-05-21 15:29:22','2024-05-21 15:29:22'),(424,'BIL','trillón de dólares','2024-05-21 15:29:22','2024-05-21 15:29:22'),(425,'BJ','cangilón','2024-05-21 15:29:22','2024-05-21 15:29:22'),(426,'BK','cesta','2024-05-21 15:29:22','2024-05-21 15:29:22'),(427,'BL','bala','2024-05-21 15:29:22','2024-05-21 15:29:22'),(428,'BLD','barril seco','2024-05-21 15:29:22','2024-05-21 15:29:22'),(429,'BLL','barril (EE. UU.) (petróleo, etc.)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(430,'BO','botella','2024-05-21 15:29:22','2024-05-21 15:29:22'),(431,'BP','cien pies de tabla','2024-05-21 15:29:22','2024-05-21 15:29:22'),(432,'BQL','becquerel','2024-05-21 15:29:22','2024-05-21 15:29:22'),(433,'BT','tornillo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(434,'C30','milivoltios por metro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(435,'C31','milivatios','2024-05-21 15:29:22','2024-05-21 15:29:22'),(436,'C32','milivatios por metro cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(437,'C33','milliweber','2024-05-21 15:29:22','2024-05-21 15:29:22'),(438,'C34','Topo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(439,'C35','mol por decímetro cúbico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(440,'C36','mol por metro cúbico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(441,'C38','mol por litro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(442,'C39','Nanoampere','2024-05-21 15:29:22','2024-05-21 15:29:22'),(443,'C4','partido de carga','2024-05-21 15:29:22','2024-05-21 15:29:22'),(444,'C40','nanocoulomb','2024-05-21 15:29:22','2024-05-21 15:29:22'),(445,'C41','nanofarad','2024-05-21 15:29:22','2024-05-21 15:29:22'),(446,'C42','nanofarad por metro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(447,'C43','nanohenry','2024-05-21 15:29:22','2024-05-21 15:29:22'),(448,'C44','nanohenry por metro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(449,'C45','nanometro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(450,'C46','medidor de nanoohm','2024-05-21 15:29:22','2024-05-21 15:29:22'),(451,'C47','nanosegundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(452,'C48','nanotesla','2024-05-21 15:29:22','2024-05-21 15:29:22'),(453,'C49','nanovatio','2024-05-21 15:29:22','2024-05-21 15:29:22'),(454,'C5','costo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(455,'C50','neper','2024-05-21 15:29:22','2024-05-21 15:29:22'),(456,'C51','neper por segundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(457,'C52','picometro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(458,'C53','metro de newton segundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(459,'C54','newton metro cuadrado kilogramo cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(460,'C55','newton por metro cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(461,'C56','newton por milímetro cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(462,'C57','newton segundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(463,'C58','newton segundo por metro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(464,'C59','octava','2024-05-21 15:29:22','2024-05-21 15:29:22'),(465,'C6','célula','2024-05-21 15:29:22','2024-05-21 15:29:22'),(466,'C60','ohm centímetro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(467,'C61','ohm metro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(468,'C62','uno','2024-05-21 15:29:22','2024-05-21 15:29:22'),(469,'C63','parsec','2024-05-21 15:29:22','2024-05-21 15:29:22'),(470,'C64','pascal por kelvin','2024-05-21 15:29:22','2024-05-21 15:29:22'),(471,'C65','segundo pascal','2024-05-21 15:29:22','2024-05-21 15:29:22'),(472,'C66','segundo pascal por metro cúbico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(473,'C67','segundo pascal por metro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(474,'C68','petajoule','2024-05-21 15:29:22','2024-05-21 15:29:22'),(475,'C69','telefono','2024-05-21 15:29:22','2024-05-21 15:29:22'),(476,'C7','centipoise','2024-05-21 15:29:22','2024-05-21 15:29:22'),(477,'C70','picoampere','2024-05-21 15:29:22','2024-05-21 15:29:22'),(478,'C71','picocoulomb','2024-05-21 15:29:22','2024-05-21 15:29:22'),(479,'C72','picofarad por metro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(480,'C73','picohenry','2024-05-21 15:29:22','2024-05-21 15:29:22'),(481,'C75','picowatt','2024-05-21 15:29:22','2024-05-21 15:29:22'),(482,'C76','picowatt por metro cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(483,'C77','medidor de libras','2024-05-21 15:29:22','2024-05-21 15:29:22'),(484,'C78','fuerza de libra','2024-05-21 15:29:22','2024-05-21 15:29:22'),(485,'C8','Millicoulomb por kilogramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(486,'C80','rad','2024-05-21 15:29:22','2024-05-21 15:29:22'),(487,'C81','radián','2024-05-21 15:29:22','2024-05-21 15:29:22'),(488,'C82','medidor de radianes al cuadrado por mol','2024-05-21 15:29:22','2024-05-21 15:29:22'),(489,'C83','medidor de radianes al cuadrado por kilogramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(490,'C84','radian por metro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(491,'C85','â € ngstr recíproco “m','2024-05-21 15:29:22','2024-05-21 15:29:22'),(492,'C86','metro cúbico recíproco','2024-05-21 15:29:22','2024-05-21 15:29:22'),(493,'C87','metro cúbico recíproco por segundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(494,'C88','voltios de electrones recíprocos por metro cúbico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(495,'C89','Henry Recíproco','2024-05-21 15:29:22','2024-05-21 15:29:22'),(496,'C9','grupo de bobina','2024-05-21 15:29:22','2024-05-21 15:29:22'),(497,'C90','Joule recíproco por metro cúbico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(498,'C91','kelvin recíproco o kelvin al poder menos uno','2024-05-21 15:29:22','2024-05-21 15:29:22'),(499,'C92','medidor recíproco','2024-05-21 15:29:22','2024-05-21 15:29:22'),(500,'C93','metro cuadrado recíproco','2024-05-21 15:29:22','2024-05-21 15:29:22'),(501,'C94','minuto recíproco','2024-05-21 15:29:22','2024-05-21 15:29:22'),(502,'C95','mole recíproco','2024-05-21 15:29:22','2024-05-21 15:29:22'),(503,'C96','Pascal recíproco o pascal a la potencia menos uno.','2024-05-21 15:29:22','2024-05-21 15:29:22'),(504,'C97','segundo recíproco','2024-05-21 15:29:22','2024-05-21 15:29:22'),(505,'C98','segundo recíproco por metro cúbico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(506,'C99','segundo recíproco por metro cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(507,'CCT','Capacidad de carga en toneladas métricas.','2024-05-21 15:29:22','2024-05-21 15:29:22'),(508,'CDL','candela','2024-05-21 15:29:22','2024-05-21 15:29:22'),(509,'CEL','grado Celsius','2024-05-21 15:29:22','2024-05-21 15:29:22'),(510,'CEN','cien','2024-05-21 15:29:22','2024-05-21 15:29:22'),(511,'CG','tarjeta','2024-05-21 15:29:22','2024-05-21 15:29:22'),(512,'CGM','centigramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(513,'CH','envase','2024-05-21 15:29:22','2024-05-21 15:29:22'),(514,'CJ','cono','2024-05-21 15:29:22','2024-05-21 15:29:22'),(515,'CK','conector','2024-05-21 15:29:22','2024-05-21 15:29:22'),(516,'CKG','Coulomb por kilogramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(517,'CLF','cientos de licencia','2024-05-21 15:29:22','2024-05-21 15:29:22'),(518,'CLT','centilitro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(519,'CMK','centímetro cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(520,'CMQ','centímetro cúbico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(521,'CMT','centímetro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(522,'CNP','paquete de cien','2024-05-21 15:29:22','2024-05-21 15:29:22'),(523,'CNT','Cental (Reino Unido)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(524,'CO','garrafón','2024-05-21 15:29:22','2024-05-21 15:29:22'),(525,'COU','culombio','2024-05-21 15:29:22','2024-05-21 15:29:22'),(526,'CQ','cartucho','2024-05-21 15:29:22','2024-05-21 15:29:22'),(527,'CS','caso','2024-05-21 15:29:22','2024-05-21 15:29:22'),(528,'CT','caja de cartón','2024-05-21 15:29:22','2024-05-21 15:29:22'),(529,'CTM','quilate métrico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(530,'CU','vaso','2024-05-21 15:29:22','2024-05-21 15:29:22'),(531,'CUR','curie','2024-05-21 15:29:22','2024-05-21 15:29:22'),(532,'CV','cubrir','2024-05-21 15:29:22','2024-05-21 15:29:22'),(533,'CWA','cien libras (quintales) / cien pesos (US)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(534,'CWI','cien pesos (Reino Unido)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(535,'CY','cilindro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(536,'CZ','combo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(537,'D1','segundo recíproco por esteradiano','2024-05-21 15:29:22','2024-05-21 15:29:22'),(538,'D10','siemens por metro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(539,'D12','siemens metro cuadrado por mol','2024-05-21 15:29:22','2024-05-21 15:29:22'),(540,'D13','sievert','2024-05-21 15:29:22','2024-05-21 15:29:22'),(541,'D14','mil yardas lineales','2024-05-21 15:29:22','2024-05-21 15:29:22'),(542,'D15','sone','2024-05-21 15:29:22','2024-05-21 15:29:22'),(543,'D16','centímetro cuadrado por ergio','2024-05-21 15:29:22','2024-05-21 15:29:22'),(544,'D17','centímetro cuadrado por erg esterlina','2024-05-21 15:29:22','2024-05-21 15:29:22'),(545,'D18','metro kelvin','2024-05-21 15:29:22','2024-05-21 15:29:22'),(546,'D19','kelvin metro cuadrado por vatio','2024-05-21 15:29:22','2024-05-21 15:29:22'),(547,'D2','segundo recíproco por metros cuadrados esteradianos','2024-05-21 15:29:22','2024-05-21 15:29:22'),(548,'D20','metro cuadrado por julio','2024-05-21 15:29:22','2024-05-21 15:29:22'),(549,'D21','metro cuadrado por kilogramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(550,'D22','metro cuadrado por mol','2024-05-21 15:29:22','2024-05-21 15:29:22'),(551,'D23','pluma gramo (proteína)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(552,'D24','metro cuadrado por esterilizador','2024-05-21 15:29:22','2024-05-21 15:29:22'),(553,'D25','metro cuadrado por julios esteradianos','2024-05-21 15:29:22','2024-05-21 15:29:22'),(554,'D26','metro cuadrado por voltio segundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(555,'D27','esteradiano','2024-05-21 15:29:22','2024-05-21 15:29:22'),(556,'D28','sifón','2024-05-21 15:29:22','2024-05-21 15:29:22'),(557,'D29','terahercios','2024-05-21 15:29:22','2024-05-21 15:29:22'),(558,'D30','terajulio','2024-05-21 15:29:22','2024-05-21 15:29:22'),(559,'D31','teravatio','2024-05-21 15:29:22','2024-05-21 15:29:22'),(560,'D32','hora de teravatio','2024-05-21 15:29:22','2024-05-21 15:29:22'),(561,'D33','tesla','2024-05-21 15:29:22','2024-05-21 15:29:22'),(562,'D34','Texas','2024-05-21 15:29:22','2024-05-21 15:29:22'),(563,'D35','caloría termoquímica','2024-05-21 15:29:22','2024-05-21 15:29:22'),(564,'D37','caloría termoquímica por gramo kelvin','2024-05-21 15:29:22','2024-05-21 15:29:22'),(565,'D38','calorías termoquímicas por segundo centímetro kelvin','2024-05-21 15:29:22','2024-05-21 15:29:22'),(566,'D39','calorías termoquímicas por segundo centímetro cuadrado kelvin','2024-05-21 15:29:22','2024-05-21 15:29:22'),(567,'D40','mil litros','2024-05-21 15:29:22','2024-05-21 15:29:22'),(568,'D41','tonelada por metro cúbico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(569,'D42','año tropical','2024-05-21 15:29:22','2024-05-21 15:29:22'),(570,'D43','unidad de masa atómica unificada','2024-05-21 15:29:22','2024-05-21 15:29:22'),(571,'D44','var','2024-05-21 15:29:22','2024-05-21 15:29:22'),(572,'D45','voltios al cuadrado por kelvin al cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(573,'D46','voltio – amperio','2024-05-21 15:29:22','2024-05-21 15:29:22'),(574,'D47','voltio por centímetro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(575,'D48','voltio por kelvin','2024-05-21 15:29:22','2024-05-21 15:29:22'),(576,'D49','milivoltios por kelvin','2024-05-21 15:29:22','2024-05-21 15:29:22'),(577,'D5','kilogramo por centímetro cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(578,'D50','voltios por metro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(579,'D51','voltios por milímetro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(580,'D52','vatios por kelvin','2024-05-21 15:29:22','2024-05-21 15:29:22'),(581,'D53','vatios por metro kelvin','2024-05-21 15:29:22','2024-05-21 15:29:22'),(582,'D54','vatios por metro cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(583,'D55','vatios por metro cuadrado kelvin','2024-05-21 15:29:22','2024-05-21 15:29:22'),(584,'D56','vatios por metro cuadrado de kelvin a la cuarta potencia','2024-05-21 15:29:22','2024-05-21 15:29:22'),(585,'D57','vatios por steradian','2024-05-21 15:29:22','2024-05-21 15:29:22'),(586,'D58','vatios por metro cuadrado esterlino','2024-05-21 15:29:22','2024-05-21 15:29:22'),(587,'D59','weber por metro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(588,'D6','röntgen por segundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(589,'D60','weber por milímetro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(590,'MIN','minuto','2024-05-21 15:29:22','2024-05-21 15:29:22'),(591,'SEC','segundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(592,'D63','libro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(593,'D64','bloquear','2024-05-21 15:29:22','2024-05-21 15:29:22'),(594,'D65','redondo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(595,'D66','casete','2024-05-21 15:29:22','2024-05-21 15:29:22'),(596,'D67','dólar por hora','2024-05-21 15:29:22','2024-05-21 15:29:22'),(597,'D69','pulgada a la cuarta potencia','2024-05-21 15:29:22','2024-05-21 15:29:22'),(598,'D7','Sandwich','2024-05-21 15:29:22','2024-05-21 15:29:22'),(599,'D70','Tabla Internacional (IT) caloría','2024-05-21 15:29:22','2024-05-21 15:29:22'),(600,'D71','Tabla Internacional (IT) calorías por segundo centímetro kelvin','2024-05-21 15:29:22','2024-05-21 15:29:22'),(601,'D72','Tabla Internacional (IT) calorías por segundo centímetro cuadrado kelvin','2024-05-21 15:29:22','2024-05-21 15:29:22'),(602,'D73','joule metro cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(603,'D74','kilogramo por mol','2024-05-21 15:29:22','2024-05-21 15:29:22'),(604,'D75','Tabla Internacional (IT) calorías por gramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(605,'D76','Tabla Internacional (IT) calorías por gramo kelvin','2024-05-21 15:29:22','2024-05-21 15:29:22'),(606,'D77','megacoulomb','2024-05-21 15:29:22','2024-05-21 15:29:22'),(607,'D79','haz','2024-05-21 15:29:22','2024-05-21 15:29:22'),(608,'D8','puntaje de drenaje','2024-05-21 15:29:22','2024-05-21 15:29:22'),(609,'D80','microwatt','2024-05-21 15:29:22','2024-05-21 15:29:22'),(610,'D81','microtesla','2024-05-21 15:29:22','2024-05-21 15:29:22'),(611,'D82','microvoltio','2024-05-21 15:29:22','2024-05-21 15:29:22'),(612,'D83','medidor de millinewton','2024-05-21 15:29:22','2024-05-21 15:29:22'),(613,'D85','microwatt por metro cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(614,'D86','Millicoulomb','2024-05-21 15:29:22','2024-05-21 15:29:22'),(615,'D87','milimol por kilogramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(616,'D88','millicoulomb por metro cúbico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(617,'D89','millicoulomb por metro cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(618,'D9','dina por centímetro cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(619,'D90','metro cúbico (neto)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(620,'D91','movimiento rápido del ojo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(621,'D92','banda','2024-05-21 15:29:22','2024-05-21 15:29:22'),(622,'D93','segundo por metro cúbico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(623,'D94','segundo por metro cúbico radianes','2024-05-21 15:29:22','2024-05-21 15:29:22'),(624,'D95','julios por gramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(625,'D96','libra bruta','2024-05-21 15:29:22','2024-05-21 15:29:22'),(626,'D97','carga de palet / unidad','2024-05-21 15:29:22','2024-05-21 15:29:22'),(627,'D98','libra de masa','2024-05-21 15:29:22','2024-05-21 15:29:22'),(628,'D99','manga','2024-05-21 15:29:22','2024-05-21 15:29:22'),(629,'DAA','despreciar','2024-05-21 15:29:22','2024-05-21 15:29:22'),(630,'DAD','diez dias','2024-05-21 15:29:22','2024-05-21 15:29:22'),(631,'día','DAY','2024-05-21 15:29:22','2024-05-21 15:29:22'),(632,'DB','libra seca','2024-05-21 15:29:22','2024-05-21 15:29:22'),(633,'DC','disco','2024-05-21 15:29:22','2024-05-21 15:29:22'),(634,'DD','la licenciatura','2024-05-21 15:29:22','2024-05-21 15:29:22'),(635,'DE','acuerdo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(636,'DEC','década','2024-05-21 15:29:22','2024-05-21 15:29:22'),(637,'DG','decigramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(638,'DI','dispensador','2024-05-21 15:29:22','2024-05-21 15:29:22'),(639,'DJ','decagramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(640,'DLT','decilitro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(641,'DMK','263nformaci cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(642,'DMQ','decímetro cúbico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(643,'DMT','decímetro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(644,'DN','medidor de decinewton','2024-05-21 15:29:22','2024-05-21 15:29:22'),(645,'DPC','docena pieza','2024-05-21 15:29:22','2024-05-21 15:29:22'),(646,'DPR','docena par','2024-05-21 15:29:22','2024-05-21 15:29:22'),(647,'DPT','tonelaje de desplazamiento','2024-05-21 15:29:22','2024-05-21 15:29:22'),(648,'DQ','registro de datos','2024-05-21 15:29:22','2024-05-21 15:29:22'),(649,'DR','tambor','2024-05-21 15:29:22','2024-05-21 15:29:22'),(650,'DRA','dram (US)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(651,'DRI','dram (Reino Unido)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(652,'DRL','docena rollo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(653,'DRM','dracma (Reino Unido)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(654,'DS','monitor','2024-05-21 15:29:22','2024-05-21 15:29:22'),(655,'DT','tonelada seca','2024-05-21 15:29:22','2024-05-21 15:29:22'),(656,'DTN','Decitonne','2024-05-21 15:29:22','2024-05-21 15:29:22'),(657,'DU','dina','2024-05-21 15:29:22','2024-05-21 15:29:22'),(658,'DWT','pennyweight','2024-05-21 15:29:22','2024-05-21 15:29:22'),(659,'DX','dina por centímetro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(660,'DY','libro de directorio','2024-05-21 15:29:22','2024-05-21 15:29:22'),(661,'DZN','docena','2024-05-21 15:29:22','2024-05-21 15:29:22'),(662,'DZP','paquete de doce','2024-05-21 15:29:22','2024-05-21 15:29:22'),(663,'E2','cinturón','2024-05-21 15:29:22','2024-05-21 15:29:22'),(664,'E3','remolque','2024-05-21 15:29:22','2024-05-21 15:29:22'),(665,'E4','kilogramo bruto','2024-05-21 15:29:22','2024-05-21 15:29:22'),(666,'E5','tonelada métrica larga','2024-05-21 15:29:22','2024-05-21 15:29:22'),(667,'EA','cada','2024-05-21 15:29:22','2024-05-21 15:29:22'),(668,'EB','casilla de correo electrónico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(669,'CE','cada uno por mes','2024-05-21 15:29:22','2024-05-21 15:29:22'),(670,'EP','paquete de once','2024-05-21 15:29:22','2024-05-21 15:29:22'),(671,'EQ','galón equivalente','2024-05-21 15:29:22','2024-05-21 15:29:22'),(672,'EV','sobre','2024-05-21 15:29:22','2024-05-21 15:29:22'),(673,'F1','mil pies cúbicos por día','2024-05-21 15:29:22','2024-05-21 15:29:22'),(674,'F9','Fibra por centímetro cúbico de aire','2024-05-21 15:29:22','2024-05-21 15:29:22'),(675,'FAH','grado Fahrenheit','2024-05-21 15:29:22','2024-05-21 15:29:22'),(676,'FAR','faradio','2024-05-21 15:29:22','2024-05-21 15:29:22'),(677,'FB','campo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(678,'FC','mil pies cúbicos','2024-05-21 15:29:22','2024-05-21 15:29:22'),(679,'FD','millón de partículas por pie cúbico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(680,'FE','pie de pista','2024-05-21 15:29:22','2024-05-21 15:29:22'),(681,'FF','cien metros cúbicos','2024-05-21 15:29:22','2024-05-21 15:29:22'),(682,'FG','parche transdérmico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(683,'FH','micromol','2024-05-21 15:29:22','2024-05-21 15:29:22'),(684,'FL','tonelada en escamas','2024-05-21 15:29:22','2024-05-21 15:29:22'),(685,'FM','millones de pies cúbicos','2024-05-21 15:29:22','2024-05-21 15:29:22'),(686,'pie','FOT','2024-05-21 15:29:22','2024-05-21 15:29:22'),(687,'FP','libra por pie cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(688,'FR','pie por minuto','2024-05-21 15:29:22','2024-05-21 15:29:22'),(689,'FS','pie por segundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(690,'FTK','pie cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(691,'FTQ','pie cubico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(692,'G2','US galones por minuto','2024-05-21 15:29:22','2024-05-21 15:29:22'),(693,'G3','Galon imperial por minuto','2024-05-21 15:29:22','2024-05-21 15:29:22'),(694,'G7','hoja de microficha','2024-05-21 15:29:22','2024-05-21 15:29:22'),(695,'GB','galón (US) por día','2024-05-21 15:29:22','2024-05-21 15:29:22'),(696,'GBQ','gigabecquerel','2024-05-21 15:29:22','2024-05-21 15:29:22'),(697,'GC','gramo por 100 gramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(698,'GD','barril bruto','2024-05-21 15:29:22','2024-05-21 15:29:22'),(699,'GE','libra por galón (US)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(700,'GF','gramo por metro (gramo por 100 centímetros)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(701,'GFI','gramo de isótopo fisionable','2024-05-21 15:29:22','2024-05-21 15:29:22'),(702,'GRM','gramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(703,'GH','medio galón (EE. UU.)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(704,'GIA','branquias','2024-05-21 15:29:22','2024-05-21 15:29:22'),(705,'GII','Gill (Reino Unido)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(706,'GJ','gramo por mililitro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(707,'GL','gramo por litro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(708,'GLD','galón seco (EE. UU.)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(709,'GLI','galón (Reino Unido)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(710,'GM','gramo por metro cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(711,'GN','galón bruto','2024-05-21 15:29:22','2024-05-21 15:29:22'),(712,'GO','miligramos por metro cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(713,'GP','miligramo por metro cúbico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(714,'GQ','microgramos por metro cúbico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(715,'GRN','grano','2024-05-21 15:29:22','2024-05-21 15:29:22'),(716,'GRO','bruto','2024-05-21 15:29:22','2024-05-21 15:29:22'),(717,'GRT','tonelada de registro bruto','2024-05-21 15:29:22','2024-05-21 15:29:22'),(718,'GT','tonelada bruta','2024-05-21 15:29:22','2024-05-21 15:29:22'),(719,'GV','gigajoule','2024-05-21 15:29:22','2024-05-21 15:29:22'),(720,'GW','galón por mil pies cúbicos','2024-05-21 15:29:22','2024-05-21 15:29:22'),(721,'GWH','hora de gigavatios','2024-05-21 15:29:22','2024-05-21 15:29:22'),(722,'GY','patio bruto','2024-05-21 15:29:22','2024-05-21 15:29:22'),(723,'GZ','sistema de medición','2024-05-21 15:29:22','2024-05-21 15:29:22'),(724,'H1','media página – electrónica','2024-05-21 15:29:22','2024-05-21 15:29:22'),(725,'H2','medio litro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(726,'HA','madeja','2024-05-21 15:29:22','2024-05-21 15:29:22'),(727,'HAR','hectárea','2024-05-21 15:29:22','2024-05-21 15:29:22'),(728,'HBA','hectobar','2024-05-21 15:29:22','2024-05-21 15:29:22'),(729,'HBX','cien cajas','2024-05-21 15:29:22','2024-05-21 15:29:22'),(730,'HC','cien cuentas','2024-05-21 15:29:22','2024-05-21 15:29:22'),(731,'HD','media docena','2024-05-21 15:29:22','2024-05-21 15:29:22'),(732,'ÉL','centésima de quilate','2024-05-21 15:29:22','2024-05-21 15:29:22'),(733,'HF','cien pies','2024-05-21 15:29:22','2024-05-21 15:29:22'),(734,'HGM','hectogramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(735,'HH','cien pies cúbicos','2024-05-21 15:29:22','2024-05-21 15:29:22'),(736,'HI','cien hojas','2024-05-21 15:29:22','2024-05-21 15:29:22'),(737,'HIU','cien unidades internacionales','2024-05-21 15:29:22','2024-05-21 15:29:22'),(738,'HJ','caballo métrico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(739,'HK','cien kilogramos','2024-05-21 15:29:22','2024-05-21 15:29:22'),(740,'HL','cien pies (lineales)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(741,'HLT','hectolitro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(742,'HM','milla por hora','2024-05-21 15:29:22','2024-05-21 15:29:22'),(743,'HMQ','millones de metros cúbicos','2024-05-21 15:29:22','2024-05-21 15:29:22'),(744,'HMT','hectómetro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(745,'HN','milímetro convencional de mercurio','2024-05-21 15:29:22','2024-05-21 15:29:22'),(746,'HO','cien onzas troy','2024-05-21 15:29:22','2024-05-21 15:29:22'),(747,'HP','milímetro convencional de agua','2024-05-21 15:29:22','2024-05-21 15:29:22'),(748,'HPA','hectolitro de alcohol puro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(749,'HS','cien pies cuadrados','2024-05-21 15:29:22','2024-05-21 15:29:22'),(750,'HT','media hora','2024-05-21 15:29:22','2024-05-21 15:29:22'),(751,'HTZ','hertz','2024-05-21 15:29:22','2024-05-21 15:29:22'),(752,'HUR','hora','2024-05-21 15:29:22','2024-05-21 15:29:22'),(753,'HY','cien yardas','2024-05-21 15:29:22','2024-05-21 15:29:22'),(754,'IA','pulgada libra','2024-05-21 15:29:22','2024-05-21 15:29:22'),(755,'IC','contar por pulgada','2024-05-21 15:29:22','2024-05-21 15:29:22'),(756,'IE','persona','2024-05-21 15:29:22','2024-05-21 15:29:22'),(757,'IF','pulgadas de agua','2024-05-21 15:29:22','2024-05-21 15:29:22'),(758,'II','columna pulgada','2024-05-21 15:29:22','2024-05-21 15:29:22'),(759,'IL','pulgada por minuto','2024-05-21 15:29:22','2024-05-21 15:29:22'),(760,'IM','impresión','2024-05-21 15:29:22','2024-05-21 15:29:22'),(761,'INH','pulgada','2024-05-21 15:29:22','2024-05-21 15:29:22'),(762,'KI','Kilogramo por milímetro de ancho','2024-05-21 15:29:22','2024-05-21 15:29:22'),(763,'KJ','kilosegmento','2024-05-21 15:29:22','2024-05-21 15:29:22'),(764,'KJO','kilojoule','2024-05-21 15:29:22','2024-05-21 15:29:22'),(765,'KL','kilogramo por metro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(766,'KMH','kilómetro por hora','2024-05-21 15:29:22','2024-05-21 15:29:22'),(767,'KMK','kilometro cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(768,'KMQ','kilogramo por metro cúbico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(769,'KNI','kilogramo de nitrógeno','2024-05-21 15:29:22','2024-05-21 15:29:22'),(770,'KNS','kilogramo de sustancia nombrada','2024-05-21 15:29:22','2024-05-21 15:29:22'),(771,'nudo','KNT','2024-05-21 15:29:22','2024-05-21 15:29:22'),(772,'KO','Milliequivalencia de potasa cáustica por gramo de producto.','2024-05-21 15:29:22','2024-05-21 15:29:22'),(773,'KPA','kilopascal','2024-05-21 15:29:22','2024-05-21 15:29:22'),(774,'KPH','kilogramo de hidróxido de potasio (potasa cáustica)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(775,'KPO','kilogramo de óxido de potasio','2024-05-21 15:29:22','2024-05-21 15:29:22'),(776,'KPP','kilogramo de pentóxido de fósforo (anhídrido fosfórico)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(777,'KR','KilorÃ¶ntgen','2024-05-21 15:29:22','2024-05-21 15:29:22'),(778,'KS','mil libras por pulgada cuadrada','2024-05-21 15:29:22','2024-05-21 15:29:22'),(779,'KSD','kilogramo de sustancia 90% seca','2024-05-21 15:29:22','2024-05-21 15:29:22'),(780,'KSH','kilogramo de hidróxido de sodio (soda cáustica)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(781,'KT','equipo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(782,'KTM','kilómetro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(783,'KTN','kilotonne','2024-05-21 15:29:22','2024-05-21 15:29:22'),(784,'KUR','kilogramo de uranio','2024-05-21 15:29:22','2024-05-21 15:29:22'),(785,'KVA','kilovoltio – ampere','2024-05-21 15:29:22','2024-05-21 15:29:22'),(786,'KVR','kilovar','2024-05-21 15:29:22','2024-05-21 15:29:22'),(787,'KVT','kilovoltio','2024-05-21 15:29:22','2024-05-21 15:29:22'),(788,'KW','kilogramos por milímetro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(789,'KWH','kilovatios hora','2024-05-21 15:29:22','2024-05-21 15:29:22'),(790,'KWT','kilovatio','2024-05-21 15:29:22','2024-05-21 15:29:22'),(791,'KX','mililitro por kilogramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(792,'L2','litro por minuto','2024-05-21 15:29:22','2024-05-21 15:29:22'),(793,'LA','libra por pulgada cúbica','2024-05-21 15:29:22','2024-05-21 15:29:22'),(794,'LBR','libra','2024-05-21 15:29:22','2024-05-21 15:29:22'),(795,'LBT','libra troy','2024-05-21 15:29:22','2024-05-21 15:29:22'),(796,'LC','centímetro lineal','2024-05-21 15:29:22','2024-05-21 15:29:22'),(797,'LD','litro por día','2024-05-21 15:29:22','2024-05-21 15:29:22'),(798,'LE','lite','2024-05-21 15:29:22','2024-05-21 15:29:22'),(799,'ST','hoja','2024-05-21 15:29:22','2024-05-21 15:29:22'),(800,'LF','pie lineal','2024-05-21 15:29:22','2024-05-21 15:29:22'),(801,'LH','hora de trabajo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(802,'LI','pulgada lineal','2024-05-21 15:29:22','2024-05-21 15:29:22'),(803,'LJ','spray grande','2024-05-21 15:29:22','2024-05-21 15:29:22'),(804,'LK','enlazar','2024-05-21 15:29:22','2024-05-21 15:29:22'),(805,'LM','metro lineal','2024-05-21 15:29:22','2024-05-21 15:29:22'),(806,'LN','longitud','2024-05-21 15:29:22','2024-05-21 15:29:22'),(807,'LO','mucho','2024-05-21 15:29:22','2024-05-21 15:29:22'),(808,'LP','libra liquida','2024-05-21 15:29:22','2024-05-21 15:29:22'),(809,'LPA','litro de alcohol puro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(810,'LR','capa','2024-05-21 15:29:22','2024-05-21 15:29:22'),(811,'LS','Suma global','2024-05-21 15:29:22','2024-05-21 15:29:22'),(812,'LTN','ton (Reino Unido) o longton (EE. UU.)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(813,'LTR','litro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(814,'LUM','lumen','2024-05-21 15:29:22','2024-05-21 15:29:22'),(815,'lux','LUX','2024-05-21 15:29:22','2024-05-21 15:29:22'),(816,'LX','yarda lineal por libra','2024-05-21 15:29:22','2024-05-21 15:29:22'),(817,'LY','yarda lineal','2024-05-21 15:29:22','2024-05-21 15:29:22'),(818,'M0','cinta magnética','2024-05-21 15:29:22','2024-05-21 15:29:22'),(819,'M1','miligramos por litro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(820,'M4','valor monetario','2024-05-21 15:29:22','2024-05-21 15:29:22'),(821,'M5','microcurie','2024-05-21 15:29:22','2024-05-21 15:29:22'),(822,'M7','micropulgada','2024-05-21 15:29:22','2024-05-21 15:29:22'),(823,'M9','millones de Btu por 1000 pies cúbicos','2024-05-21 15:29:22','2024-05-21 15:29:22'),(824,'MA','máquina por unidad','2024-05-21 15:29:22','2024-05-21 15:29:22'),(825,'MAL','mega litro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(826,'MAM','megametro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(827,'MAW','megavatio','2024-05-21 15:29:22','2024-05-21 15:29:22'),(828,'MBE','mil equivalentes de ladrillo estándar','2024-05-21 15:29:22','2024-05-21 15:29:22'),(829,'MBF','mil pies de tabla','2024-05-21 15:29:22','2024-05-21 15:29:22'),(830,'MBR','milibar','2024-05-21 15:29:22','2024-05-21 15:29:22'),(831,'MC','microgramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(832,'MCU','milicurie','2024-05-21 15:29:22','2024-05-21 15:29:22'),(833,'MD','aire seco tonelada métrica','2024-05-21 15:29:22','2024-05-21 15:29:22'),(834,'MF','miligramo por pie cuadrado por lado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(835,'MGM','miligramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(836,'MIK','milla cuadrada','2024-05-21 15:29:22','2024-05-21 15:29:22'),(837,'mil','MIL','2024-05-21 15:29:22','2024-05-21 15:29:22'),(838,'MIO','millón','2024-05-21 15:29:22','2024-05-21 15:29:22'),(839,'MIU','millones de unidades internacionales','2024-05-21 15:29:22','2024-05-21 15:29:22'),(840,'MK','miligramo por pulgada cuadrada','2024-05-21 15:29:22','2024-05-21 15:29:22'),(841,'MLD','mil millones','2024-05-21 15:29:22','2024-05-21 15:29:22'),(842,'MLT','mililitro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(843,'MMK','milímetro cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(844,'MMQ','milímetro cúbico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(845,'MMT','milímetro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(846,'LUN','mes','2024-05-21 15:29:22','2024-05-21 15:29:22'),(847,'MPA','megapascal','2024-05-21 15:29:22','2024-05-21 15:29:22'),(848,'MQ','mil metros','2024-05-21 15:29:22','2024-05-21 15:29:22'),(849,'MQH','metro cúbico por hora','2024-05-21 15:29:22','2024-05-21 15:29:22'),(850,'MQS','metro cúbico por segundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(851,'MSK','metro por segundo al cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(852,'MT','estera','2024-05-21 15:29:22','2024-05-21 15:29:22'),(853,'MTK','metro cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(854,'MTQ','Metro cúbico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(855,'MTR','metro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(856,'MTS','metro por segundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(857,'MV','numero de mults','2024-05-21 15:29:22','2024-05-21 15:29:22'),(858,'MVA','megavolt – ampere','2024-05-21 15:29:22','2024-05-21 15:29:22'),(859,'MWH','megavatios hora (1000 kW.h)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(860,'N1','calorías de la pluma','2024-05-21 15:29:22','2024-05-21 15:29:22'),(861,'N2','número de líneas','2024-05-21 15:29:22','2024-05-21 15:29:22'),(862,'N3','punto de impresión','2024-05-21 15:29:22','2024-05-21 15:29:22'),(863,'NA','miligramo por kilogramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(864,'NAR','número de artículos','2024-05-21 15:29:22','2024-05-21 15:29:22'),(865,'NB','barcaza','2024-05-21 15:29:22','2024-05-21 15:29:22'),(866,'NBB','número de bobinas','2024-05-21 15:29:22','2024-05-21 15:29:22'),(867,'NC','coche','2024-05-21 15:29:22','2024-05-21 15:29:22'),(868,'NCL','número de celdas','2024-05-21 15:29:22','2024-05-21 15:29:22'),(869,'ND','barril neto','2024-05-21 15:29:22','2024-05-21 15:29:22'),(870,'NE','litro neto','2024-05-21 15:29:22','2024-05-21 15:29:22'),(871,'NEW','newton','2024-05-21 15:29:22','2024-05-21 15:29:22'),(872,'NF','mensaje','2024-05-21 15:29:22','2024-05-21 15:29:22'),(873,'NG','galón neto (nosotros)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(874,'NH','hora del mensaje','2024-05-21 15:29:22','2024-05-21 15:29:22'),(875,'NI','galón imperial neto','2024-05-21 15:29:22','2024-05-21 15:29:22'),(876,'NIU','número de unidades internacionales','2024-05-21 15:29:22','2024-05-21 15:29:22'),(877,'NJ','número de pantallas','2024-05-21 15:29:22','2024-05-21 15:29:22'),(878,'NL','carga','2024-05-21 15:29:22','2024-05-21 15:29:22'),(879,'MNI','milla nautica','2024-05-21 15:29:22','2024-05-21 15:29:22'),(880,'NMP','número de paquetes','2024-05-21 15:29:22','2024-05-21 15:29:22'),(881,'NN','entrenar','2024-05-21 15:29:22','2024-05-21 15:29:22'),(882,'NPL','número de parcelas','2024-05-21 15:29:22','2024-05-21 15:29:22'),(883,'NPR','numero de pares','2024-05-21 15:29:22','2024-05-21 15:29:22'),(884,'TNP','numero de partes','2024-05-21 15:29:22','2024-05-21 15:29:22'),(885,'NQ','mho','2024-05-21 15:29:22','2024-05-21 15:29:22'),(886,'NR','micromho','2024-05-21 15:29:22','2024-05-21 15:29:22'),(887,'NRL','número de rollos','2024-05-21 15:29:22','2024-05-21 15:29:22'),(888,'NT','tonelada neta','2024-05-21 15:29:22','2024-05-21 15:29:22'),(889,'NTT','registro neto de toneladas','2024-05-21 15:29:22','2024-05-21 15:29:22'),(890,'NU','medidor de newton','2024-05-21 15:29:22','2024-05-21 15:29:22'),(891,'NV','vehículo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(892,'NX','parte por mil','2024-05-21 15:29:22','2024-05-21 15:29:22'),(893,'NY','libra por aire seco tonelada métrica','2024-05-21 15:29:22','2024-05-21 15:29:22'),(894,'OA','panel','2024-05-21 15:29:22','2024-05-21 15:29:22'),(895,'OHM','ohm','2024-05-21 15:29:22','2024-05-21 15:29:22'),(896,'EN','onza por yarda cuadrada','2024-05-21 15:29:22','2024-05-21 15:29:22'),(897,'ONZ','onza','2024-05-21 15:29:22','2024-05-21 15:29:22'),(898,'OP','Dos paquetes','2024-05-21 15:29:22','2024-05-21 15:29:22'),(899,'OT','hora extra','2024-05-21 15:29:22','2024-05-21 15:29:22'),(900,'OZA','onza líquida (US)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(901,'OZI','onza líquida (Reino Unido)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(902,'P0','pagina – electronica','2024-05-21 15:29:22','2024-05-21 15:29:22'),(903,'P1','por ciento','2024-05-21 15:29:22','2024-05-21 15:29:22'),(904,'P2','libra por pie','2024-05-21 15:29:22','2024-05-21 15:29:22'),(905,'P3','paquete de tres','2024-05-21 15:29:22','2024-05-21 15:29:22'),(906,'P4','paquete de cuatro','2024-05-21 15:29:22','2024-05-21 15:29:22'),(907,'P5','paquete de cinco','2024-05-21 15:29:22','2024-05-21 15:29:22'),(908,'P6','paquete de seis','2024-05-21 15:29:22','2024-05-21 15:29:22'),(909,'P7','paquete de siete','2024-05-21 15:29:22','2024-05-21 15:29:22'),(910,'P8','paquete de ocho','2024-05-21 15:29:22','2024-05-21 15:29:22'),(911,'P9','paquete de nueve','2024-05-21 15:29:22','2024-05-21 15:29:22'),(912,'PK','paquete','2024-05-21 15:29:22','2024-05-21 15:29:22'),(913,'PAL','pascal','2024-05-21 15:29:22','2024-05-21 15:29:22'),(914,'PB','par de pulgadas','2024-05-21 15:29:22','2024-05-21 15:29:22'),(915,'PD','almohadilla','2024-05-21 15:29:22','2024-05-21 15:29:22'),(916,'PE','equivalente en libras','2024-05-21 15:29:22','2024-05-21 15:29:22'),(917,'PF','palet (ascensor)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(918,'PG','plato','2024-05-21 15:29:22','2024-05-21 15:29:22'),(919,'PGL','galón de prueba','2024-05-21 15:29:22','2024-05-21 15:29:22'),(920,'Pi','tono','2024-05-21 15:29:22','2024-05-21 15:29:22'),(921,'PL','cubo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(922,'PM','porcentaje de libra','2024-05-21 15:29:22','2024-05-21 15:29:22'),(923,'PN','libra neta','2024-05-21 15:29:22','2024-05-21 15:29:22'),(924,'PO','libra por pulgada de longitud','2024-05-21 15:29:22','2024-05-21 15:29:22'),(925,'PQ','página por pulgada','2024-05-21 15:29:22','2024-05-21 15:29:22'),(926,'par','PR','2024-05-21 15:29:22','2024-05-21 15:29:22'),(927,'PT','pinta','2024-05-21 15:29:22','2024-05-21 15:29:22'),(928,'PTD','pinta seca','2024-05-21 15:29:22','2024-05-21 15:29:22'),(929,'PTI','pinta (Reino Unido)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(930,'PTL','pinta liquida (US)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(931,'PU','bandeja / paquete de bandeja','2024-05-21 15:29:22','2024-05-21 15:29:22'),(932,'PV','media pinta (US)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(933,'PW','libra por pulgada de ancho','2024-05-21 15:29:22','2024-05-21 15:29:22'),(934,'PY','Peck Dry (US)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(935,'PZ','Peck Dry (Reino Unido)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(936,'Q3','comida','2024-05-21 15:29:22','2024-05-21 15:29:22'),(937,'QA','página – facsímil','2024-05-21 15:29:22','2024-05-21 15:29:22'),(938,'QAN','cuarto (de un año)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(939,'QB','página – copia impresa','2024-05-21 15:29:22','2024-05-21 15:29:22'),(940,'QD','cuarto de docena','2024-05-21 15:29:22','2024-05-21 15:29:22'),(941,'QH','un cuarto de hora','2024-05-21 15:29:22','2024-05-21 15:29:22'),(942,'QK','cuarto de kilogramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(943,'QR','mano de papel','2024-05-21 15:29:22','2024-05-21 15:29:22'),(944,'QT','cuarto de galón (US)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(945,'QTD','cuarto seco (EE. UU.)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(946,'QTI','cuarto de galón (Reino Unido)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(947,'QTL','cuarto líquido (US)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(948,'QTR','cuarto (UK)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(949,'R1','pica','2024-05-21 15:29:22','2024-05-21 15:29:22'),(950,'R4','caloría','2024-05-21 15:29:22','2024-05-21 15:29:22'),(951,'R9','mil metros cúbicos','2024-05-21 15:29:22','2024-05-21 15:29:22'),(952,'RA','estante','2024-05-21 15:29:22','2024-05-21 15:29:22'),(953,'RD','barra','2024-05-21 15:29:22','2024-05-21 15:29:22'),(954,'RG','anillo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(955,'RH','hora de funcionamiento o de funcionamiento','2024-05-21 15:29:22','2024-05-21 15:29:22'),(956,'RK','medida métrica rollo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(957,'SO','carrete','2024-05-21 15:29:22','2024-05-21 15:29:22'),(958,'RM','resma','2024-05-21 15:29:22','2024-05-21 15:29:22'),(959,'RN','medida métrica de resma','2024-05-21 15:29:22','2024-05-21 15:29:22'),(960,'RO','rodar','2024-05-21 15:29:22','2024-05-21 15:29:22'),(961,'RP','libra por resma','2024-05-21 15:29:22','2024-05-21 15:29:22'),(962,'RPM','revoluciones por minuto','2024-05-21 15:29:22','2024-05-21 15:29:22'),(963,'RPS','revoluciones por segundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(964,'RS','Reiniciar','2024-05-21 15:29:22','2024-05-21 15:29:22'),(965,'RT','ingreso tonelada milla','2024-05-21 15:29:22','2024-05-21 15:29:22'),(966,'RU','correr','2024-05-21 15:29:22','2024-05-21 15:29:22'),(967,'S3','pie cuadrado por segundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(968,'S4','metro cuadrado por segundo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(969,'S5','sesenta cuartos de pulgada','2024-05-21 15:29:22','2024-05-21 15:29:22'),(970,'S6','sesión','2024-05-21 15:29:22','2024-05-21 15:29:22'),(971,'S7','unidad de almacenamiento','2024-05-21 15:29:22','2024-05-21 15:29:22'),(972,'S8','unidad de publicidad estándar','2024-05-21 15:29:22','2024-05-21 15:29:22'),(973,'SA','saco','2024-05-21 15:29:22','2024-05-21 15:29:22'),(974,'SAN','medio año (6 meses)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(975,'OCS','Puntuación','2024-05-21 15:29:22','2024-05-21 15:29:22'),(976,'SCR','escrúpulo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(977,'SD','libra solida','2024-05-21 15:29:22','2024-05-21 15:29:22'),(978,'SE','sección','2024-05-21 15:29:22','2024-05-21 15:29:22'),(979,'SET','conjunto','2024-05-21 15:29:22','2024-05-21 15:29:22'),(980,'SG','segmento','2024-05-21 15:29:22','2024-05-21 15:29:22'),(981,'SHT','tonelada de envío','2024-05-21 15:29:22','2024-05-21 15:29:22'),(982,'SIE','siemens','2024-05-21 15:29:22','2024-05-21 15:29:22'),(983,'SK','camión cisterna dividido','2024-05-21 15:29:22','2024-05-21 15:29:22'),(984,'SL','hoja de deslizamiento','2024-05-21 15:29:22','2024-05-21 15:29:22'),(985,'SMI','milla (milla estatutaria)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(986,'SN','varilla cuadrada','2024-05-21 15:29:22','2024-05-21 15:29:22'),(987,'SP','paquete de estante','2024-05-21 15:29:22','2024-05-21 15:29:22'),(988,'SQ','cuadrado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(989,'SR','tira','2024-05-21 15:29:22','2024-05-21 15:29:22'),(990,'SS','hoja métrica medida','2024-05-21 15:29:22','2024-05-21 15:29:22'),(991,'SST','corto estándar (7200 partidos)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(992,'ITS','piedra (Reino Unido)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(993,'STN','tonelada (US) o tonelada corta (UK / US)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(994,'SV','patinar','2024-05-21 15:29:22','2024-05-21 15:29:22'),(995,'SX','envío','2024-05-21 15:29:22','2024-05-21 15:29:22'),(996,'T0','Línea de telecomunicaciones en servicio.','2024-05-21 15:29:22','2024-05-21 15:29:22'),(997,'T1','mil libras brutas','2024-05-21 15:29:22','2024-05-21 15:29:22'),(998,'T3','mil piezas','2024-05-21 15:29:22','2024-05-21 15:29:22'),(999,'T4','bolsa de mil','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1000,'T5','caja de mil','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1001,'T6','mil galones (US)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1002,'T7','mil impresiones','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1003,'T8','mil pulgadas lineales','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1004,'TA','décimo pie cúbico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1005,'TAH','Kiloampere hora (mil amperios hora)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1006,'TC','camion','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1007,'TD','termia','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1008,'TE','totalizador','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1009,'TF','diez metros cuadrados','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1010,'TI','mil pulgadas cuadradas','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1011,'TJ','mil centímetros cuadrados','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1012,'TK','tanque, rectangular','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1013,'TL','mil pies (lineales)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1014,'TN','estaño','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1015,'TNE','tonelada (tonelada métrica)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1016,'TP','paquete de diez','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1017,'TPR','diez pares','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1018,'TQ','mil pies','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1019,'TQD','mil metros cúbicos por día','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1020,'TR','diez pies cuadrados','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1021,'TRL','trillón (EUR)','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1022,'TS','mil pies cuadrados','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1023,'TSD','tonelada de sustancia 90% seca','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1024,'TSH','tonelada de vapor por hora','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1025,'TT','mil metros lineales','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1026,'TU','tubo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1027,'TV','mil kilogramos','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1028,'TW','mil hojas','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1029,'TY','tanque, cilíndrico','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1030,'U1','tratamiento','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1031,'U2','tableta','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1032,'UA','torr','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1033,'UB','Línea de telecomunicaciones en servicio promedio.','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1034,'UC','puerto de telecomunicaciones','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1035,'UD','décimo minuto','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1036,'UE','décima hora','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1037,'UF','uso por línea de telecomunicación promedio','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1038,'UH','diez mil yardas','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1039,'UM','millones de unidades','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1040,'VA','voltio amperio por kilogramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1041,'VI','frasco','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1042,'VLT','voltio','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1043,'VQ','abultar','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1044,'VS','visitar','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1045,'W2','kilo mojado','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1046,'W4','dos semanas','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1047,'WA','vatio por kilogramo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1048,'WB','libra mojada','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1049,'WCD','cable','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1050,'WE','tonelada mojada','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1051,'WEB','weber','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1052,'WEE','semana','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1053,'WG','galon de vino','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1054,'WH','rueda','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1055,'WHR','vatios hora','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1056,'WI','peso por pulgada cuadrada','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1057,'WM','mes de trabajo','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1058,'WR','envolver','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1059,'WSD','estándar Servicios','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1060,'WTT','vatio','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1061,'WW','mililitro de agua','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1062,'X1','cadena','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1063,'YDK','yarda cuadrada','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1064,'YDQ','Yarda cúbica','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1065,'YL','cien yardas lineales','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1066,'YRD','yarda','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1067,'YT','diez yardas','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1068,'Z1','van de elevación','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1069,'Z2','pecho','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1070,'Z3','barril','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1071,'Z4','pipa','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1072,'Z5','arrastrar','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1073,'Z6','punto de conferencia','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1074,'Z8','línea de noticias de ágata','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1075,'ZP','página','2024-05-21 15:29:22','2024-05-21 15:29:22'),(1076,'ZZ','mutuamente definido','2024-05-21 15:29:22','2024-05-21 15:29:22');
/*!40000 ALTER TABLE `measurement_units` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=181 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (158,'2014_10_12_000000_create_users_table',1),(159,'2014_10_12_100000_create_password_reset_tokens_table',1),(160,'2014_10_12_100000_create_password_resets_table',1),(161,'2019_08_19_000000_create_failed_jobs_table',1),(162,'2019_12_14_000001_create_personal_access_tokens_table',1),(163,'2024_02_18_193718_category_products',1),(164,'2024_02_19_150608_sub_categories',1),(165,'2024_02_19_193730_brands',1),(166,'2024_02_19_193758_measurement_units',1),(167,'2024_02_19_193821_products',1),(168,'2024_03_04_215331_people',1),(169,'2024_03_05_162129_countries',1),(170,'2024_03_05_172018_departments',1),(171,'2024_03_06_161711_municipalities',1),(172,'2024_03_18_180327_purchase_suppliers',1),(173,'2024_03_19_154150_detail_purchase',1),(174,'2024_03_22_192215_create_sales_table',1),(175,'2024_03_29_123706_debit_note_suppliers',1),(176,'2024_04_03_164934_create_permission_tables',1),(177,'2024_04_04_141619_create_product_sale',1),(178,'2024_04_15_213512_create_credit_note_sales_table',1),(179,'2024_05_01_013003_create_credit_note_sales_product_table',1),(180,'2024_05_08_022734_create_jobs_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (1,'App\\Models\\User',1);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `municipalities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `municipalities` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` tinyint NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `departments_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `municipalities_departments_id_foreign` (`departments_id`),
  CONSTRAINT `municipalities_departments_id_foreign` FOREIGN KEY (`departments_id`) REFERENCES `departments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `municipalities` WRITE;
/*!40000 ALTER TABLE `municipalities` DISABLE KEYS */;
/*!40000 ALTER TABLE `municipalities` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `people`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `people` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `rol` enum('Cliente','Proveedor') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `identification_type` enum('CC','CE','DIE','TI','RC','TE','NIT','PP','NUIP','NITO','PEP') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `identification_number` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `person_type` enum('Persona natural','Persona jurídica') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comercial_name` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other_name` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `surname` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `second_surname` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `digit_verification` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `people` WRITE;
/*!40000 ALTER TABLE `people` DISABLE KEYS */;
INSERT INTO `people` VALUES (1,'Proveedor','CC','17383993','Persona natural',NULL,'GTK','Brayan','Alejandro','Pinilla','Vargas','3','bg@gmail.com','Sogamoso','calle 17','223333',1,'2024-05-21 19:05:49','2024-05-21 19:05:49'),(2,'Proveedor','CC','193903003','Persona jurídica','HKKS',NULL,NULL,NULL,NULL,NULL,'9','bg@gmail.com','Sogamoso','calle 7','111111',1,'2024-05-21 19:06:20','2024-05-21 19:06:20');
/*!40000 ALTER TABLE `people` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'admin.usuarios.index','web','2024-05-21 15:04:07','2024-05-21 15:04:07'),(2,'admin.usuarios.edit','web','2024-05-21 15:04:07','2024-05-21 15:04:07'),(3,'admin.usuarios.update','web','2024-05-21 15:04:07','2024-05-21 15:04:07'),(4,'','web','2024-05-21 15:04:07','2024-05-21 15:04:07'),(5,'home','web','2024-05-21 15:04:07','2024-05-21 15:04:07'),(6,'products','web','2024-05-21 15:04:07','2024-05-21 15:04:07'),(7,'category','web','2024-05-21 15:04:07','2024-05-21 15:04:07'),(8,'brand','web','2024-05-21 15:04:07','2024-05-21 15:04:07'),(9,'units','web','2024-05-21 15:04:07','2024-05-21 15:04:07'),(10,'categorySub','web','2024-05-21 15:04:07','2024-05-21 15:04:07'),(11,'sales','web','2024-05-21 15:04:07','2024-05-21 15:04:07'),(12,'credit-note-sales','web','2024-05-21 15:04:07','2024-05-21 15:04:07'),(13,'person','web','2024-05-21 15:04:07','2024-05-21 15:04:07'),(14,'customer','web','2024-05-21 15:04:07','2024-05-21 15:04:07'),(15,'supplier','web','2024-05-21 15:04:07','2024-05-21 15:04:07'),(16,'indexAll','web','2024-05-21 15:04:07','2024-05-21 15:04:07'),(17,'purchase_supplier','web','2024-05-21 15:04:07','2024-05-21 15:04:07'),(18,'detail-purchases','web','2024-05-21 15:04:07','2024-05-21 15:04:07'),(19,'debit-note-supplier','web','2024-05-21 15:04:07','2024-05-21 15:04:07'),(20,'report','web','2024-05-21 15:04:07','2024-05-21 15:04:07');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `product_sale`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_sale` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `sale_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `references` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` int NOT NULL,
  `selling_price` decimal(10,2) NOT NULL,
  `discounts` decimal(8,2) NOT NULL,
  `tax` decimal(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_sale_sale_id_foreign` (`sale_id`),
  KEY `product_sale_product_id_foreign` (`product_id`),
  CONSTRAINT `product_sale_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_sale_sale_id_foreign` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `product_sale` WRITE;
/*!40000 ALTER TABLE `product_sale` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_sale` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name_product` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_long` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `factory_reference` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `classification_tax` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `selling_price` decimal(10,2) NOT NULL,
  `purchase_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `photo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `stock` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `subcategory_product` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_products_id` bigint unsigned NOT NULL,
  `brands_id` bigint unsigned NOT NULL,
  `measurement_units_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `products_name_product_unique` (`name_product`),
  UNIQUE KEY `products_factory_reference_unique` (`factory_reference`),
  KEY `products_category_products_id_foreign` (`category_products_id`),
  KEY `products_brands_id_foreign` (`brands_id`),
  KEY `products_measurement_units_id_foreign` (`measurement_units_id`),
  CONSTRAINT `products_brands_id_foreign` FOREIGN KEY (`brands_id`) REFERENCES `brands` (`id`),
  CONSTRAINT `products_category_products_id_foreign` FOREIGN KEY (`category_products_id`) REFERENCES `category_products` (`id`),
  CONSTRAINT `products_measurement_units_id_foreign` FOREIGN KEY (`measurement_units_id`) REFERENCES `measurement_units` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'Ceramica HY',NULL,'QWER','5%',10000.00,0.00,NULL,1,'0','Ceramica LP',8,3,202,'2024-05-21 16:02:43','2024-05-21 16:03:30');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `purchase_suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_suppliers` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `invoice_number_purchase` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_invoice_purchase` date NOT NULL,
  `code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `users_id` int NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `people_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `purchase_suppliers` WRITE;
/*!40000 ALTER TABLE `purchase_suppliers` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchase_suppliers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES (1,1),(2,1),(3,1),(4,1),(5,1),(6,1),(7,1),(8,1),(9,1),(10,1),(11,1),(12,1),(13,1),(14,1),(15,1),(16,1),(17,1),(18,1),(19,1),(20,1),(5,2),(6,2),(7,2),(8,2),(9,2),(10,2),(11,2),(12,2),(13,2),(14,2),(15,2),(16,2),(17,2),(18,2),(19,2),(20,2);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Administrador','web','2024-05-21 15:04:07','2024-05-21 15:04:07'),(2,'Trabajador','web','2024-05-21 15:04:07','2024-05-21 15:04:07');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `dates` date NOT NULL,
  `bill_numbers` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sellers` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payments_methods` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `gross_totals` decimal(8,2) NOT NULL,
  `taxes_total` decimal(8,2) NOT NULL,
  `net_total` decimal(8,2) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `clients_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sales_clients_id_foreign` (`clients_id`),
  CONSTRAINT `sales_clients_id_foreign` FOREIGN KEY (`clients_id`) REFERENCES `people` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sub_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sub_categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sub_categories_name_unique` (`name`),
  KEY `sub_categories_category_id_foreign` (`category_id`),
  CONSTRAINT `sub_categories_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `category_products` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sub_categories` WRITE;
/*!40000 ALTER TABLE `sub_categories` DISABLE KEYS */;
INSERT INTO `sub_categories` VALUES (1,'Ceramica Suave','Ceramica Suave',8,'2024-05-21 16:02:07','2024-05-21 16:02:07'),(2,'Ceramica LP','Ceramica LP',8,'2024-05-21 16:03:17','2024-05-21 16:03:17');
/*!40000 ALTER TABLE `sub_categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `phone_number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `document_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `identification_number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Brayan Pinilla','B@gmail.com',NULL,'1111111111','CC','1053442698','$2y$12$gCeShoofxQnF9OSlD01MeOJqV/MMMCwss3eaYP1GBczYOO16lFDSu',NULL,'2024-05-21 15:04:31','2024-05-21 15:04:31');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

