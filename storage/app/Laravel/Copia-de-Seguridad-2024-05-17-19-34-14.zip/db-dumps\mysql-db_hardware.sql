
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `brands` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `abbrevation` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `brands` WRITE;
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
INSERT INTO `brands` VALUES (1,'MYS','1','MYS','2024-05-17 16:24:23','2024-05-17 16:24:23'),(2,'TTN','2','TTN','2024-05-17 16:24:23','2024-05-17 16:24:23'),(3,'BTY','3','BTY','2024-05-17 16:24:23','2024-05-17 16:24:23'),(4,'UIO','4','UIO','2024-05-17 16:24:23','2024-05-17 16:24:23'),(5,'RTYR','5','RTYR','2024-05-17 16:24:23','2024-05-17 16:24:23');
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `category_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category_products` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `category_products` WRITE;
/*!40000 ALTER TABLE `category_products` DISABLE KEYS */;
INSERT INTO `category_products` VALUES (1,'Pinturas','Pinturas','2024-05-17 16:25:08','2024-05-17 16:25:08'),(2,'Madera','Madera','2024-05-17 16:25:08','2024-05-17 16:25:08'),(3,'Ceramica','Ceramica','2024-05-17 16:25:08','2024-05-17 16:25:08'),(4,'Tubos','Tubos','2024-05-17 16:25:08','2024-05-17 16:25:08'),(5,'Tornillos','Tornillos','2024-05-17 16:25:08','2024-05-17 16:25:08'),(6,'Martillos','Martillos','2024-05-17 22:48:16','2024-05-17 22:48:16');
/*!40000 ALTER TABLE `category_products` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `countries` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` tinyint NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `credit_note_sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `credit_note_sales` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `date_invoice` date NOT NULL,
  `sellers` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payments_methods` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gross_totals` decimal(8,2) NOT NULL,
  `taxes_total` decimal(8,2) NOT NULL,
  `net_total` decimal(8,2) NOT NULL,
  `date_credit_notes` date NOT NULL,
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `clients_id` bigint unsigned NOT NULL,
  `sale_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `credit_note_sales_clients_id_foreign` (`clients_id`),
  KEY `credit_note_sales_sale_id_foreign` (`sale_id`),
  CONSTRAINT `credit_note_sales_clients_id_foreign` FOREIGN KEY (`clients_id`) REFERENCES `people` (`id`),
  CONSTRAINT `credit_note_sales_sale_id_foreign` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `credit_note_sales` WRITE;
/*!40000 ALTER TABLE `credit_note_sales` DISABLE KEYS */;
/*!40000 ALTER TABLE `credit_note_sales` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `credit_note_sales_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `credit_note_sales_product` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `credit_note_sales_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `references` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` int NOT NULL,
  `selling_price` decimal(10,2) NOT NULL,
  `discounts` decimal(8,2) NOT NULL,
  `tax` decimal(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `credit_note_sales_product_credit_note_sales_id_foreign` (`credit_note_sales_id`),
  KEY `credit_note_sales_product_product_id_foreign` (`product_id`),
  CONSTRAINT `credit_note_sales_product_credit_note_sales_id_foreign` FOREIGN KEY (`credit_note_sales_id`) REFERENCES `credit_note_sales` (`id`) ON DELETE CASCADE,
  CONSTRAINT `credit_note_sales_product_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `credit_note_sales_product` WRITE;
/*!40000 ALTER TABLE `credit_note_sales_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `credit_note_sales_product` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `debit_note_suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `debit_note_suppliers` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `debit_note_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_invoice` date NOT NULL,
  `detail_purchase_id` bigint unsigned NOT NULL,
  `users_id` bigint unsigned NOT NULL,
  `purchase_suppliers_id` int unsigned NOT NULL,
  `quantity` int NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total` decimal(8,2) NOT NULL,
  `net_total` decimal(20,2) NOT NULL,
  `gross_total` decimal(20,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `debit_note_suppliers_detail_purchase_id_foreign` (`detail_purchase_id`),
  KEY `debit_note_suppliers_users_id_foreign` (`users_id`),
  KEY `debit_note_suppliers_purchase_suppliers_id_foreign` (`purchase_suppliers_id`),
  CONSTRAINT `debit_note_suppliers_detail_purchase_id_foreign` FOREIGN KEY (`detail_purchase_id`) REFERENCES `detail_purchase` (`id`) ON DELETE CASCADE,
  CONSTRAINT `debit_note_suppliers_purchase_suppliers_id_foreign` FOREIGN KEY (`purchase_suppliers_id`) REFERENCES `purchase_suppliers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `debit_note_suppliers_users_id_foreign` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `debit_note_suppliers` WRITE;
/*!40000 ALTER TABLE `debit_note_suppliers` DISABLE KEYS */;
/*!40000 ALTER TABLE `debit_note_suppliers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `departments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` tinyint NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `countries_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `departments_countries_id_foreign` (`countries_id`),
  CONSTRAINT `departments_countries_id_foreign` FOREIGN KEY (`countries_id`) REFERENCES `countries` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `detail_purchase`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detail_purchase` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `note` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price_unit` decimal(20,2) NOT NULL,
  `product_tax` decimal(20,2) NOT NULL,
  `quantity_units` double NOT NULL,
  `date_purchase` date NOT NULL,
  `form_of_payment` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gross_total` decimal(20,2) NOT NULL,
  `total_tax` decimal(20,2) NOT NULL,
  `net_total` decimal(20,2) NOT NULL,
  `total_value` decimal(20,2) NOT NULL,
  `discount_total` decimal(20,2) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `method_of_payment` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `purchase_suppliers_id` int unsigned NOT NULL,
  `products_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `detail_purchase_purchase_suppliers_id_foreign` (`purchase_suppliers_id`),
  KEY `detail_purchase_products_id_foreign` (`products_id`),
  CONSTRAINT `detail_purchase_products_id_foreign` FOREIGN KEY (`products_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `detail_purchase_purchase_suppliers_id_foreign` FOREIGN KEY (`purchase_suppliers_id`) REFERENCES `purchase_suppliers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `detail_purchase` WRITE;
/*!40000 ALTER TABLE `detail_purchase` DISABLE KEYS */;
INSERT INTO `detail_purchase` VALUES (1,NULL,',',8000.00,0.00,10,'2024-05-17','tarjeta',80000.00,10.00,79990.00,80000.00,10.00,1,'cuotas',1,1,'2024-05-17 16:28:02','2024-05-17 16:28:02'),(2,NULL,'.',2000.00,19.00,20,'2024-05-17','tarjeta',40000.00,0.00,40000.00,47600.00,0.00,1,'cuotas',2,2,'2024-05-17 17:25:17','2024-05-17 17:25:17');
/*!40000 ALTER TABLE `detail_purchase` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
INSERT INTO `failed_jobs` VALUES (1,'5c9143ce-e269-4a43-84b4-178a506695e4','database','default','{\"uuid\":\"5c9143ce-e269-4a43-84b4-178a506695e4\",\"displayName\":\"App\\\\Jobs\\\\BackupProcess\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"App\\\\Jobs\\\\BackupProcess\",\"command\":\"O:22:\\\"App\\\\Jobs\\\\BackupProcess\\\":0:{}\"}}','Illuminate\\Queue\\MaxAttemptsExceededException: App\\Jobs\\BackupProcess has been attempted too many times. in C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\MaxAttemptsExceededException.php:24\nStack trace:\n#0 C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(785): Illuminate\\Queue\\MaxAttemptsExceededException::forJob()\n#1 C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(519): Illuminate\\Queue\\Worker->maxAttemptsExceededException()\n#2 C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(428): Illuminate\\Queue\\Worker->markJobAsFailedIfAlreadyExceedsMaxAttempts()\n#3 C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(389): Illuminate\\Queue\\Worker->process()\n#4 C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(176): Illuminate\\Queue\\Worker->runJob()\n#5 C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Console\\WorkCommand.php(137): Illuminate\\Queue\\Worker->daemon()\n#6 C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Console\\WorkCommand.php(120): Illuminate\\Queue\\Console\\WorkCommand->runWorker()\n#7 C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(36): Illuminate\\Queue\\Console\\WorkCommand->handle()\n#8 C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Util.php(41): Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}()\n#9 C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(93): Illuminate\\Container\\Util::unwrapIfClosure()\n#10 C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod()\n#11 C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Container.php(662): Illuminate\\Container\\BoundMethod::call()\n#12 C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Command.php(211): Illuminate\\Container\\Container->call()\n#13 C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\symfony\\console\\Command\\Command.php(326): Illuminate\\Console\\Command->execute()\n#14 C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Command.php(180): Symfony\\Component\\Console\\Command\\Command->run()\n#15 C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\symfony\\console\\Application.php(1096): Illuminate\\Console\\Command->run()\n#16 C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\symfony\\console\\Application.php(324): Symfony\\Component\\Console\\Application->doRunCommand()\n#17 C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\symfony\\console\\Application.php(175): Symfony\\Component\\Console\\Application->doRun()\n#18 C:\\laragon\\www\\db_hardware\\db_hardware\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Console\\Kernel.php(201): Symfony\\Component\\Console\\Application->run()\n#19 C:\\laragon\\www\\db_hardware\\db_hardware\\artisan(35): Illuminate\\Foundation\\Console\\Kernel->handle()\n#20 {main}','2024-05-18 00:34:00');
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
INSERT INTO `jobs` VALUES (2,'default','{\"uuid\":\"095fdad7-eb96-4a5b-8448-b3468320d710\",\"displayName\":\"App\\\\Jobs\\\\BackupProcess\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"App\\\\Jobs\\\\BackupProcess\",\"command\":\"O:22:\\\"App\\\\Jobs\\\\BackupProcess\\\":0:{}\"}}',1,1715992453,1715992451,1715992451);
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `measurement_units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `measurement_units` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1089 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `measurement_units` WRITE;
/*!40000 ALTER TABLE `measurement_units` DISABLE KEYS */;
INSERT INTO `measurement_units` VALUES (1,'10','grupo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(2,'11','equipar','2024-05-17 16:24:09','2024-05-17 16:24:09'),(3,'13','ración','2024-05-17 16:24:09','2024-05-17 16:24:09'),(4,'14','Disparo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(5,'15','palo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(6,'16','tambor de ciento quince kg','2024-05-17 16:24:09','2024-05-17 16:24:09'),(7,'17','tambor de cien libras','2024-05-17 16:24:09','2024-05-17 16:24:09'),(8,'18','tambor de cincuenta y cinco galones (US)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(9,'19','camión cisterna','2024-05-17 16:24:09','2024-05-17 16:24:09'),(10,'20','contenedor de veinte pies','2024-05-17 16:24:09','2024-05-17 16:24:09'),(11,'21','contenedor de cuarenta pies','2024-05-17 16:24:09','2024-05-17 16:24:09'),(12,'22','decilitro por gramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(13,'23','gramo por centímetro cúbico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(14,'24','libra teórica','2024-05-17 16:24:09','2024-05-17 16:24:09'),(15,'25','gramo por centímetro cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(16,'26','tonelada real','2024-05-17 16:24:09','2024-05-17 16:24:09'),(17,'27','tonelada teórica','2024-05-17 16:24:09','2024-05-17 16:24:09'),(18,'28','kilogramo por metro cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(19,'29','libra por mil pies cuadrados','2024-05-17 16:24:09','2024-05-17 16:24:09'),(20,'30','Día de potencia del caballo por tonelada métrica seca al aire.','2024-05-17 16:24:09','2024-05-17 16:24:09'),(21,'31','coger peso','2024-05-17 16:24:09','2024-05-17 16:24:09'),(22,'32','kilogramo por aire seco tonelada métrica','2024-05-17 16:24:09','2024-05-17 16:24:09'),(23,'33','kilopascales metros cuadrados por gramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(24,'34','kilopascales por milímetro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(25,'35','mililitros por centímetro cuadrado segundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(26,'36','pies cúbicos por minuto por pie cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(27,'37','onza por pie cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(28,'38','onzas por pie cuadrado por 0,01 pulgadas','2024-05-17 16:24:09','2024-05-17 16:24:09'),(29,'40','mililitro por segundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(30,'41','mililitro por minuto','2024-05-17 16:24:09','2024-05-17 16:24:09'),(31,'43','bolsa súper a granel','2024-05-17 16:24:09','2024-05-17 16:24:09'),(32,'44','bolsa a granel de quinientos kg','2024-05-17 16:24:09','2024-05-17 16:24:09'),(33,'45','bolsa a granel de trescientos kg','2024-05-17 16:24:09','2024-05-17 16:24:09'),(34,'46','bolsa a granel de cincuenta libras','2024-05-17 16:24:09','2024-05-17 16:24:09'),(35,'47','bolsa de cincuenta libras','2024-05-17 16:24:09','2024-05-17 16:24:09'),(36,'48','carga de automóviles a granel','2024-05-17 16:24:09','2024-05-17 16:24:09'),(37,'53','kilogramos teóricos','2024-05-17 16:24:09','2024-05-17 16:24:09'),(38,'54','tonelada teórica','2024-05-17 16:24:09','2024-05-17 16:24:09'),(39,'56','sitas','2024-05-17 16:24:09','2024-05-17 16:24:09'),(40,'57','malla','2024-05-17 16:24:09','2024-05-17 16:24:09'),(41,'58','kilogramo neto','2024-05-17 16:24:09','2024-05-17 16:24:09'),(42,'59','parte por millón','2024-05-17 16:24:09','2024-05-17 16:24:09'),(43,'60','porcentaje de peso','2024-05-17 16:24:09','2024-05-17 16:24:09'),(44,'61','parte por billón (US)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(45,'62','porcentaje por 1000 horas','2024-05-17 16:24:09','2024-05-17 16:24:09'),(46,'63','tasa de fracaso en el tiempo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(47,'64','libra por pulgada cuadrada, calibre','2024-05-17 16:24:09','2024-05-17 16:24:09'),(48,'66','Oersted','2024-05-17 16:24:09','2024-05-17 16:24:09'),(49,'69','prueba de escala específica','2024-05-17 16:24:09','2024-05-17 16:24:09'),(50,'71','voltio amperio por libra','2024-05-17 16:24:09','2024-05-17 16:24:09'),(51,'72','vatio por libra','2024-05-17 16:24:09','2024-05-17 16:24:09'),(52,'73','amperio tum por centímetro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(53,'74','milipascal','2024-05-17 16:24:09','2024-05-17 16:24:09'),(54,'76','gauss','2024-05-17 16:24:09','2024-05-17 16:24:09'),(55,'77','mili pulgadas','2024-05-17 16:24:09','2024-05-17 16:24:09'),(56,'78','kilogauss','2024-05-17 16:24:09','2024-05-17 16:24:09'),(57,'80','libras por pulgada cuadrada absoluta','2024-05-17 16:24:09','2024-05-17 16:24:09'),(58,'81','Enrique','2024-05-17 16:24:09','2024-05-17 16:24:09'),(59,'84','kilopound por pulgada cuadrada','2024-05-17 16:24:09','2024-05-17 16:24:09'),(60,'85','fuerza libra pie','2024-05-17 16:24:09','2024-05-17 16:24:09'),(61,'87','libra por pie cúbico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(62,'89','equilibrio','2024-05-17 16:24:09','2024-05-17 16:24:09'),(63,'90','Saybold segundo universal','2024-05-17 16:24:09','2024-05-17 16:24:09'),(64,'91','alimenta','2024-05-17 16:24:09','2024-05-17 16:24:09'),(65,'92','calorías por centímetro cúbico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(66,'93','calorías por gramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(67,'94','unidad','2024-05-17 16:24:09','2024-05-17 16:24:09'),(68,'95','veinte mil galones (US) de carros','2024-05-17 16:24:09','2024-05-17 16:24:09'),(69,'96','diez mil galones (US) de carros','2024-05-17 16:24:09','2024-05-17 16:24:09'),(70,'97','tambor de diez kg','2024-05-17 16:24:09','2024-05-17 16:24:09'),(71,'98','tambor de quince kg','2024-05-17 16:24:09','2024-05-17 16:24:09'),(72,'04','spray pequeño','2024-05-17 16:24:09','2024-05-17 16:24:09'),(73,'05','levantar','2024-05-17 16:24:09','2024-05-17 16:24:09'),(74,'08','Lote calor','2024-05-17 16:24:09','2024-05-17 16:24:09'),(75,'1A','milla de coche','2024-05-17 16:24:09','2024-05-17 16:24:09'),(76,'1B','recuento de coches','2024-05-17 16:24:09','2024-05-17 16:24:09'),(77,'1C','recuento de locomotoras','2024-05-17 16:24:09','2024-05-17 16:24:09'),(78,'1D','recuento de cabos','2024-05-17 16:24:09','2024-05-17 16:24:09'),(79,'1E','carro vacio','2024-05-17 16:24:09','2024-05-17 16:24:09'),(80,'1F','millas de tren','2024-05-17 16:24:09','2024-05-17 16:24:09'),(81,'1G','uso de combustible galón (US)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(82,'1H','milla del caboose','2024-05-17 16:24:09','2024-05-17 16:24:09'),(83,'1I','tipo de interés fijo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(84,'1J','tonelada milla','2024-05-17 16:24:09','2024-05-17 16:24:09'),(85,'1K','milla locomotora','2024-05-17 16:24:09','2024-05-17 16:24:09'),(86,'1L','recuento total de coches','2024-05-17 16:24:09','2024-05-17 16:24:09'),(87,'1M','milla de coche total','2024-05-17 16:24:09','2024-05-17 16:24:09'),(88,'1X','cuarto de milla','2024-05-17 16:24:09','2024-05-17 16:24:09'),(89,'2A','radianes por segundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(90,'2B','radianes por segundo al cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(91,'2C','Röntgen','2024-05-17 16:24:09','2024-05-17 16:24:09'),(92,'2I','Unidad térmica británica por hora.','2024-05-17 16:24:09','2024-05-17 16:24:09'),(93,'2J','centímetro cúbico por segundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(94,'2K','pie cúbico por hora','2024-05-17 16:24:09','2024-05-17 16:24:09'),(95,'2L','pie cúbico por minuto','2024-05-17 16:24:09','2024-05-17 16:24:09'),(96,'2M','centímetro por segundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(97,'2N','decibel','2024-05-17 16:24:09','2024-05-17 16:24:09'),(98,'2P','kilobyte','2024-05-17 16:24:09','2024-05-17 16:24:09'),(99,'2Q','kilobecquerel','2024-05-17 16:24:09','2024-05-17 16:24:09'),(100,'2R','kilocurie','2024-05-17 16:24:09','2024-05-17 16:24:09'),(101,'2U','megagramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(102,'2V','megagramo por hora','2024-05-17 16:24:09','2024-05-17 16:24:09'),(103,'2W','compartimiento','2024-05-17 16:24:09','2024-05-17 16:24:09'),(104,'2X','metro por minuto','2024-05-17 16:24:09','2024-05-17 16:24:09'),(105,'2Y','milliröntgen','2024-05-17 16:24:09','2024-05-17 16:24:09'),(106,'2Z','milivoltios','2024-05-17 16:24:09','2024-05-17 16:24:09'),(107,'3B','megajulio','2024-05-17 16:24:09','2024-05-17 16:24:09'),(108,'3C','manmonth','2024-05-17 16:24:09','2024-05-17 16:24:09'),(109,'3E','libra por libra de producto','2024-05-17 16:24:09','2024-05-17 16:24:09'),(110,'3G','libra por pieza de producto','2024-05-17 16:24:09','2024-05-17 16:24:09'),(111,'3H','kilogramo por kilogramo de producto','2024-05-17 16:24:09','2024-05-17 16:24:09'),(112,'3I','kilogramo por pieza de producto','2024-05-17 16:24:09','2024-05-17 16:24:09'),(113,'4A','bobina','2024-05-17 16:24:09','2024-05-17 16:24:09'),(114,'4B','gorra','2024-05-17 16:24:09','2024-05-17 16:24:09'),(115,'4C','centistokes','2024-05-17 16:24:09','2024-05-17 16:24:09'),(116,'4E','paquete de veinte','2024-05-17 16:24:09','2024-05-17 16:24:09'),(117,'4G','microlitro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(118,'4H','micrometro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(119,'4K','miliamperio','2024-05-17 16:24:09','2024-05-17 16:24:09'),(120,'4L','megabyte','2024-05-17 16:24:09','2024-05-17 16:24:09'),(121,'4M','miligramo por hora','2024-05-17 16:24:09','2024-05-17 16:24:09'),(122,'4N','megabecquerel','2024-05-17 16:24:09','2024-05-17 16:24:09'),(123,'4O','microfarad','2024-05-17 16:24:09','2024-05-17 16:24:09'),(124,'4P','newton por metro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(125,'4Q','onza pulgada','2024-05-17 16:24:09','2024-05-17 16:24:09'),(126,'4R','pie onza','2024-05-17 16:24:09','2024-05-17 16:24:09'),(127,'4T','picofarad','2024-05-17 16:24:09','2024-05-17 16:24:09'),(128,'4U','libra por hora','2024-05-17 16:24:09','2024-05-17 16:24:09'),(129,'4W','tonelada (US) por hora','2024-05-17 16:24:09','2024-05-17 16:24:09'),(130,'4X','kilolitro por hora','2024-05-17 16:24:09','2024-05-17 16:24:09'),(131,'BTU','Unidad Térmica Británica','2024-05-17 16:24:09','2024-05-17 16:24:09'),(132,'BUA','bushel (EE. UU.)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(133,'BUI','bushel (Reino Unido)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(134,'BW','peso base','2024-05-17 16:24:09','2024-05-17 16:24:09'),(135,'BX','caja','2024-05-17 16:24:09','2024-05-17 16:24:09'),(136,'BZ','millones de BTUs','2024-05-17 16:24:09','2024-05-17 16:24:09'),(137,'C0','llamada','2024-05-17 16:24:09','2024-05-17 16:24:09'),(138,'C1','producto compuesto libra (peso total)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(139,'C10','millifarad','2024-05-17 16:24:09','2024-05-17 16:24:09'),(140,'C11','miligal','2024-05-17 16:24:09','2024-05-17 16:24:09'),(141,'C12','miligramo por metro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(142,'C13','miligray','2024-05-17 16:24:09','2024-05-17 16:24:09'),(143,'C14','milihenry','2024-05-17 16:24:09','2024-05-17 16:24:09'),(144,'C15','milijoule','2024-05-17 16:24:09','2024-05-17 16:24:09'),(145,'C16','milímetro por segundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(146,'C17','milímetro cuadrado por segundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(147,'C18','milimol','2024-05-17 16:24:09','2024-05-17 16:24:09'),(148,'C19','mol por kilogramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(149,'C2','carset','2024-05-17 16:24:09','2024-05-17 16:24:09'),(150,'C20','millinewton','2024-05-17 16:24:09','2024-05-17 16:24:09'),(151,'C22','millinewton por metro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(152,'C23','medidor de miliohm','2024-05-17 16:24:09','2024-05-17 16:24:09'),(153,'C24','segundo milipascal','2024-05-17 16:24:09','2024-05-17 16:24:09'),(154,'C25','miliradian','2024-05-17 16:24:09','2024-05-17 16:24:09'),(155,'C26','milisegundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(156,'C27','milisiemens','2024-05-17 16:24:09','2024-05-17 16:24:09'),(157,'C28','milisievert','2024-05-17 16:24:09','2024-05-17 16:24:09'),(158,'C29','millitesla','2024-05-17 16:24:09','2024-05-17 16:24:09'),(159,'C3','microvoltios por metro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(160,'INK','pulgada cuadrada','2024-05-17 16:24:09','2024-05-17 16:24:09'),(161,'INQ','pulgada en cubos','2024-05-17 16:24:09','2024-05-17 16:24:09'),(162,'IP','póliza de seguros','2024-05-17 16:24:09','2024-05-17 16:24:09'),(163,'IT','conteo por centímetro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(164,'IU','pulgada por segundo (velocidad lineal)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(165,'IV','pulgada por segundo al cuadrado (aceleración)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(166,'J2','julios por kilogramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(167,'JB','jumbo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(168,'JE','joule por kelvin','2024-05-17 16:24:09','2024-05-17 16:24:09'),(169,'JG','jarra','2024-05-17 16:24:09','2024-05-17 16:24:09'),(170,'JK','megajulio por kilogramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(171,'JM','megajulio por metro cúbico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(172,'JO','articulación','2024-05-17 16:24:09','2024-05-17 16:24:09'),(173,'JOU','joule','2024-05-17 16:24:09','2024-05-17 16:24:09'),(174,'JR','tarro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(175,'K1','demanda de kilovatios','2024-05-17 16:24:09','2024-05-17 16:24:09'),(176,'K2','kilovoltios amperios reactivos de demanda','2024-05-17 16:24:09','2024-05-17 16:24:09'),(177,'K3','kilovoltio amperio hora reactiva','2024-05-17 16:24:09','2024-05-17 16:24:09'),(178,'K5','amperios kilovoltios (reactivos)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(179,'K6','kilolitro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(180,'KA','pastel','2024-05-17 16:24:09','2024-05-17 16:24:09'),(181,'KB','kilocharacter','2024-05-17 16:24:09','2024-05-17 16:24:09'),(182,'KBA','kilobar','2024-05-17 16:24:09','2024-05-17 16:24:09'),(183,'KD','kilogramo decimal','2024-05-17 16:24:09','2024-05-17 16:24:09'),(184,'KEL','kelvin','2024-05-17 16:24:09','2024-05-17 16:24:09'),(185,'KF','kilopacket','2024-05-17 16:24:09','2024-05-17 16:24:09'),(186,'KG','barrilete','2024-05-17 16:24:09','2024-05-17 16:24:09'),(187,'KGM','kilogramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(188,'KGS','kilogramo por segundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(189,'KHZ','kilohercio','2024-05-17 16:24:09','2024-05-17 16:24:09'),(190,'5A','barril por minuto','2024-05-17 16:24:09','2024-05-17 16:24:09'),(191,'5B','lote','2024-05-17 16:24:09','2024-05-17 16:24:09'),(192,'5C','galón (US) por mil','2024-05-17 16:24:09','2024-05-17 16:24:09'),(193,'5E','MMSCF / día','2024-05-17 16:24:09','2024-05-17 16:24:09'),(194,'5F','libras por mil','2024-05-17 16:24:09','2024-05-17 16:24:09'),(195,'5G','bomba','2024-05-17 16:24:09','2024-05-17 16:24:09'),(196,'5H','escenario','2024-05-17 16:24:09','2024-05-17 16:24:09'),(197,'5I','pie cúbico estándar','2024-05-17 16:24:09','2024-05-17 16:24:09'),(198,'5J','potencia hidráulica de caballos','2024-05-17 16:24:09','2024-05-17 16:24:09'),(199,'5K','contar por minuto','2024-05-17 16:24:09','2024-05-17 16:24:09'),(200,'5P','nivel sismico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(201,'5Q','260nfor sismica','2024-05-17 16:24:09','2024-05-17 16:24:09'),(202,'A1','15 calorías C','2024-05-17 16:24:09','2024-05-17 16:24:09'),(203,'A10','amperio metro cuadrado por joule segundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(204,'A11','Ã ¥ ngström','2024-05-17 16:24:09','2024-05-17 16:24:09'),(205,'A12','unidad astronómica','2024-05-17 16:24:09','2024-05-17 16:24:09'),(206,'A13','attojoule','2024-05-17 16:24:09','2024-05-17 16:24:09'),(207,'A14','granero','2024-05-17 16:24:09','2024-05-17 16:24:09'),(208,'A15','granero por electrón voltio','2024-05-17 16:24:09','2024-05-17 16:24:09'),(209,'A16','granero por voltio de electrones esteradiano,','2024-05-17 16:24:09','2024-05-17 16:24:09'),(210,'A17','granero por sterdian','2024-05-17 16:24:09','2024-05-17 16:24:09'),(211,'A18','becquerel por kilogramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(212,'A19','becquerel por metro cúbico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(213,'A2','amperio por centímetro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(214,'A20','Unidad térmica británica por segundo pie cuadrado grado Rankin','2024-05-17 16:24:09','2024-05-17 16:24:09'),(215,'A21','Unidad térmica británica por libra grado Rankin','2024-05-17 16:24:09','2024-05-17 16:24:09'),(216,'A22','Unidad térmica británica por segundo pie grado Rankin','2024-05-17 16:24:09','2024-05-17 16:24:09'),(217,'A23','Unidad térmica británica por hora pie cuadrado grado Rankin','2024-05-17 16:24:09','2024-05-17 16:24:09'),(218,'A24','candela por metro cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(219,'A25','cheval vapeur','2024-05-17 16:24:09','2024-05-17 16:24:09'),(220,'A26','medidor de culombio','2024-05-17 16:24:09','2024-05-17 16:24:09'),(221,'A27','medidor de culombio al cuadrado por voltio','2024-05-17 16:24:09','2024-05-17 16:24:09'),(222,'A28','Coulomb por centímetro cúbico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(223,'A29','Coulomb por metro cúbico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(224,'A3','amperio por milímetro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(225,'A30','Coulomb por milímetro cúbico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(226,'A31','Coulomb por kilogramo segundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(227,'A32','Coulomb por mol','2024-05-17 16:24:09','2024-05-17 16:24:09'),(228,'A33','Coulomb por centímetro cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(229,'A34','Coulomb por metro cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(230,'A35','Coulomb por milímetro cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(231,'A36','centímetro cúbico por mol','2024-05-17 16:24:09','2024-05-17 16:24:09'),(232,'A37','261nformaci cúbico por mol','2024-05-17 16:24:09','2024-05-17 16:24:09'),(233,'A38','metro cúbico por coulomb','2024-05-17 16:24:09','2024-05-17 16:24:09'),(234,'A39','metro cúbico por kilogramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(235,'A4','amperio por centímetro cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(236,'A40','metro cúbico por mol','2024-05-17 16:24:09','2024-05-17 16:24:09'),(237,'A41','amperio por metro cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(238,'A42','curie por kilogramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(239,'A43','tonelaje de peso muerto','2024-05-17 16:24:09','2024-05-17 16:24:09'),(240,'A44','decalitro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(241,'A45','decámetro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(242,'A47','decitex','2024-05-17 16:24:09','2024-05-17 16:24:09'),(243,'A48','grado Rankin','2024-05-17 16:24:09','2024-05-17 16:24:09'),(244,'A49','negador','2024-05-17 16:24:09','2024-05-17 16:24:09'),(245,'A5','amperio metro cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(246,'A50','dyn segundo por centímetro cúbico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(247,'A51','dina segundo por centímetro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(248,'A52','dina segundo por centímetro al quinto','2024-05-17 16:24:09','2024-05-17 16:24:09'),(249,'A53','electronvolt','2024-05-17 16:24:09','2024-05-17 16:24:09'),(250,'A54','electronvoltio por metro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(251,'A55','metro electronvolt cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(252,'A56','electronvoltio de metro cuadrado por kilogramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(253,'A57','ergio','2024-05-17 16:24:09','2024-05-17 16:24:09'),(254,'A58','erg por centímetro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(255,'A6','amperio por metro cuadrado kelvin al cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(256,'A60','erg por centímetro cúbico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(257,'A61','erg por gramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(258,'A62','erg por gramo de segundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(259,'A63','erg por segundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(260,'A64','erg por segundo centímetro cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(261,'A65','erg por centímetro cuadrado segundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(262,'A66','erg centímetro cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(263,'A67','ergímetro cuadrado por gramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(264,'A68','exajulio','2024-05-17 16:24:09','2024-05-17 16:24:09'),(265,'A69','faradio por metro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(266,'A7','amperio por milímetro cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(267,'A70','femtojoule','2024-05-17 16:24:09','2024-05-17 16:24:09'),(268,'A71','femtometro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(269,'A73','pie por segundo al cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(270,'A74','pie-fuerza de la libra por segundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(271,'A75','tonelada de carga','2024-05-17 16:24:09','2024-05-17 16:24:09'),(272,'A76','galón','2024-05-17 16:24:09','2024-05-17 16:24:09'),(273,'A77','Unidad de desplazamiento CGS gaussiana','2024-05-17 16:24:09','2024-05-17 16:24:09'),(274,'A78','Unidad gaussiana CGS de corriente eléctrica.','2024-05-17 16:24:09','2024-05-17 16:24:09'),(275,'A79','Unidad Gaussian CGS de carga eléctrica.','2024-05-17 16:24:09','2024-05-17 16:24:09'),(276,'A8','amperio segundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(277,'A80','Unidad Gaussian CGS de intensidad de campo eléctrico.','2024-05-17 16:24:09','2024-05-17 16:24:09'),(278,'A81','Unidad Gaussian CGS de polarización eléctrica.','2024-05-17 16:24:09','2024-05-17 16:24:09'),(279,'A82','Unidad Gaussian CGS de potencial eléctrico.','2024-05-17 16:24:09','2024-05-17 16:24:09'),(280,'A83','Unidad Gaussiana CGS de magnetización.','2024-05-17 16:24:09','2024-05-17 16:24:09'),(281,'A84','gigacoulomb por metro cúbico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(282,'A85','Gigaelectronvolt','2024-05-17 16:24:09','2024-05-17 16:24:09'),(283,'A86','gigahercios','2024-05-17 16:24:09','2024-05-17 16:24:09'),(284,'A87','gigaohm','2024-05-17 16:24:09','2024-05-17 16:24:09'),(285,'A88','medidor de gigaohm','2024-05-17 16:24:09','2024-05-17 16:24:09'),(286,'A89','gigapascal','2024-05-17 16:24:09','2024-05-17 16:24:09'),(287,'A9','tarifa','2024-05-17 16:24:09','2024-05-17 16:24:09'),(288,'A90','gigavatios','2024-05-17 16:24:09','2024-05-17 16:24:09'),(289,'A91','gon','2024-05-17 16:24:09','2024-05-17 16:24:09'),(290,'A93','gramo por metro cúbico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(291,'A94','gramo por mol','2024-05-17 16:24:09','2024-05-17 16:24:09'),(292,'gris','A95','2024-05-17 16:24:09','2024-05-17 16:24:09'),(293,'A96','gris por segundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(294,'A97','hectopascal','2024-05-17 16:24:09','2024-05-17 16:24:09'),(295,'A98','Henry por metro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(296,'AA','bola','2024-05-17 16:24:09','2024-05-17 16:24:09'),(297,'AB','paquete a granel','2024-05-17 16:24:09','2024-05-17 16:24:09'),(298,'ACR','acre','2024-05-17 16:24:09','2024-05-17 16:24:09'),(299,'AD','byte','2024-05-17 16:24:09','2024-05-17 16:24:09'),(300,'AE','amperio por metro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(301,'AH','minuto adicional','2024-05-17 16:24:09','2024-05-17 16:24:09'),(302,'AI','minuto promedio por llamada','2024-05-17 16:24:09','2024-05-17 16:24:09'),(303,'AJ','policía','2024-05-17 16:24:09','2024-05-17 16:24:09'),(304,'AK','braza','2024-05-17 16:24:09','2024-05-17 16:24:09'),(305,'AL','263nfor de acceso','2024-05-17 16:24:09','2024-05-17 16:24:09'),(306,'AM','ampolla','2024-05-17 16:24:09','2024-05-17 16:24:09'),(307,'AMH','hora amperio','2024-05-17 16:24:09','2024-05-17 16:24:09'),(308,'AMP','amperio','2024-05-17 16:24:09','2024-05-17 16:24:09'),(309,'ANA','año','2024-05-17 16:24:09','2024-05-17 16:24:09'),(310,'AP','solo libra de aluminio','2024-05-17 16:24:09','2024-05-17 16:24:09'),(311,'APZ','onza troy o onza de boticarios','2024-05-17 16:24:09','2024-05-17 16:24:09'),(312,'AQ','Unidad de factor antihemofílico (AHF)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(313,'AR','supositorio','2024-05-17 16:24:09','2024-05-17 16:24:09'),(314,'SON','son','2024-05-17 16:24:09','2024-05-17 16:24:09'),(315,'COMO','surtido','2024-05-17 16:24:09','2024-05-17 16:24:09'),(316,'ASM','fuerza alcohólica en masa','2024-05-17 16:24:09','2024-05-17 16:24:09'),(317,'ASU','fuerza alcohólica por volumen','2024-05-17 16:24:09','2024-05-17 16:24:09'),(318,'ATM','ambiente estándar','2024-05-17 16:24:09','2024-05-17 16:24:09'),(319,'ATT','ambiente técnico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(320,'AV','cápsula','2024-05-17 16:24:09','2024-05-17 16:24:09'),(321,'AW','vial lleno de polvo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(322,'SÍ','montaje','2024-05-17 16:24:09','2024-05-17 16:24:09'),(323,'AZ','Unidad térmica británica por libra','2024-05-17 16:24:09','2024-05-17 16:24:09'),(324,'B0','Btu por pie cúbico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(325,'B1','barril (US) por día','2024-05-17 16:24:09','2024-05-17 16:24:09'),(326,'B11','julios por kilogramo kelvin','2024-05-17 16:24:09','2024-05-17 16:24:09'),(327,'B12','julios por metro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(328,'B13','julios por metro cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(329,'B14','julios por metro a la cuarta potencia','2024-05-17 16:24:09','2024-05-17 16:24:09'),(330,'B15','julios por mol','2024-05-17 16:24:09','2024-05-17 16:24:09'),(331,'B16','julios por mol kelvin','2024-05-17 16:24:09','2024-05-17 16:24:09'),(332,'B18','joule segundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(333,'B2','litera','2024-05-17 16:24:09','2024-05-17 16:24:09'),(334,'B20','joule metro cuadrado por kilogramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(335,'B21','kelvin por vatio','2024-05-17 16:24:09','2024-05-17 16:24:09'),(336,'B22','Kiloampere','2024-05-17 16:24:09','2024-05-17 16:24:09'),(337,'B23','kiloampere por metro cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(338,'B24','kiloampere por metro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(339,'B25','kilobecquerel por kilogramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(340,'B26','kilocoulomb','2024-05-17 16:24:09','2024-05-17 16:24:09'),(341,'B27','kilocoulomb por metro cúbico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(342,'B28','kilocoulomb por metro cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(343,'B29','kiloelectronvolt','2024-05-17 16:24:09','2024-05-17 16:24:09'),(344,'B3','libra de bateo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(345,'B31','kilogramo metro por segundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(346,'B32','kilogramo metro cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(347,'B33','kilogramo metro cuadrado por segundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(348,'B34','kilogramo por decímetro cúbico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(349,'B35','kilogramo por litro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(350,'B36','caloría termoquímica por gramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(351,'B37','kilogramo de fuerza','2024-05-17 16:24:09','2024-05-17 16:24:09'),(352,'B38','metro de fuerza de kilogramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(353,'B39','metro de fuerza de kilogramo por segundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(354,'B4','barril, imperial','2024-05-17 16:24:09','2024-05-17 16:24:09'),(355,'B40','kilogramo de fuerza por metro cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(356,'B41','kilojoule per kelvin','2024-05-17 16:24:09','2024-05-17 16:24:09'),(357,'B42','kilojoule por kilogramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(358,'B43','kilojoule por kilogramo kelvin','2024-05-17 16:24:09','2024-05-17 16:24:09'),(359,'B44','kilojoule por mol','2024-05-17 16:24:09','2024-05-17 16:24:09'),(360,'B45','kilomol','2024-05-17 16:24:09','2024-05-17 16:24:09'),(361,'B46','kilomol por metro cúbico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(362,'B47','Kilonewton','2024-05-17 16:24:09','2024-05-17 16:24:09'),(363,'B48','medidor de kilonewton','2024-05-17 16:24:09','2024-05-17 16:24:09'),(364,'B49','kiloohm','2024-05-17 16:24:09','2024-05-17 16:24:09'),(365,'B5','palanquilla','2024-05-17 16:24:09','2024-05-17 16:24:09'),(366,'B50','medidor de kiloohm','2024-05-17 16:24:09','2024-05-17 16:24:09'),(367,'B51','kilopond','2024-05-17 16:24:09','2024-05-17 16:24:09'),(368,'B52','kilosegundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(369,'B53','kilosiemens','2024-05-17 16:24:09','2024-05-17 16:24:09'),(370,'B54','kilosiemens por metro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(371,'B55','kilovoltios por metro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(372,'B56','kiloveber por metro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(373,'B57','año luz','2024-05-17 16:24:09','2024-05-17 16:24:09'),(374,'B58','litro por mol','2024-05-17 16:24:09','2024-05-17 16:24:09'),(375,'B59','hora lumen','2024-05-17 16:24:09','2024-05-17 16:24:09'),(376,'B6','bollo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(377,'B60','lumen por metro cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(378,'B61','lumen por vatio','2024-05-17 16:24:09','2024-05-17 16:24:09'),(379,'B62','lumen segundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(380,'B63','hora de lux','2024-05-17 16:24:09','2024-05-17 16:24:09'),(381,'B64','lux segundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(382,'B65','Maxwell','2024-05-17 16:24:09','2024-05-17 16:24:09'),(383,'B66','megaamperios por metro cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(384,'B67','megabecquerel por kilogramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(385,'B69','megacoulomb por metro cúbico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(386,'B7','ciclo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(387,'B70','megacoulomb por metro cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(388,'B71','megaelectronvolt','2024-05-17 16:24:09','2024-05-17 16:24:09'),(389,'B72','megagramo por metro cúbico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(390,'B73','meganewton','2024-05-17 16:24:09','2024-05-17 16:24:09'),(391,'B74','medidor de meganewton','2024-05-17 16:24:09','2024-05-17 16:24:09'),(392,'B75','megaohm','2024-05-17 16:24:09','2024-05-17 16:24:09'),(393,'B76','metro megaohm','2024-05-17 16:24:09','2024-05-17 16:24:09'),(394,'B77','megasiemens por metro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(395,'B78','megavoltio','2024-05-17 16:24:09','2024-05-17 16:24:09'),(396,'B79','megavolt por metro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(397,'B8','julios por metro cúbico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(398,'B81','metro recíproco cuadrado recíproco segundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(399,'B83','metro a la cuarta potencia','2024-05-17 16:24:09','2024-05-17 16:24:09'),(400,'B84','microamperios','2024-05-17 16:24:09','2024-05-17 16:24:09'),(401,'B85','microbar','2024-05-17 16:24:09','2024-05-17 16:24:09'),(402,'B86','microcoulomb','2024-05-17 16:24:09','2024-05-17 16:24:09'),(403,'B87','microcoulomb por metro cúbico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(404,'B88','microcoulomb por metro cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(405,'B89','microfarada por metro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(406,'B9','batt','2024-05-17 16:24:09','2024-05-17 16:24:09'),(407,'B90','microhenry','2024-05-17 16:24:09','2024-05-17 16:24:09'),(408,'B91','microhenry por metro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(409,'B92','micronewton','2024-05-17 16:24:09','2024-05-17 16:24:09'),(410,'B93','medidor de micronewton','2024-05-17 16:24:09','2024-05-17 16:24:09'),(411,'B94','microohm','2024-05-17 16:24:09','2024-05-17 16:24:09'),(412,'B95','medidor de microohmios','2024-05-17 16:24:09','2024-05-17 16:24:09'),(413,'B96','micropascal','2024-05-17 16:24:09','2024-05-17 16:24:09'),(414,'B97','microradiano','2024-05-17 16:24:09','2024-05-17 16:24:09'),(415,'B98','microsegundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(416,'B99','microsiemens','2024-05-17 16:24:09','2024-05-17 16:24:09'),(417,'BAR','bar','2024-05-17 16:24:09','2024-05-17 16:24:09'),(418,'BB','caja base','2024-05-17 16:24:09','2024-05-17 16:24:09'),(419,'BD','tablero','2024-05-17 16:24:09','2024-05-17 16:24:09'),(420,'haz','SER','2024-05-17 16:24:09','2024-05-17 16:24:09'),(421,'BFT','pie de tabla','2024-05-17 16:24:09','2024-05-17 16:24:09'),(422,'BG','bolso','2024-05-17 16:24:09','2024-05-17 16:24:09'),(423,'BH','cepillo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(424,'BHP','potencia al freno','2024-05-17 16:24:09','2024-05-17 16:24:09'),(425,'BIL','trillón de dólares','2024-05-17 16:24:09','2024-05-17 16:24:09'),(426,'BJ','cangilón','2024-05-17 16:24:09','2024-05-17 16:24:09'),(427,'BK','cesta','2024-05-17 16:24:09','2024-05-17 16:24:09'),(428,'BL','bala','2024-05-17 16:24:09','2024-05-17 16:24:09'),(429,'BLD','barril seco','2024-05-17 16:24:09','2024-05-17 16:24:09'),(430,'BLL','barril (EE. UU.) (petróleo, etc.)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(431,'BO','botella','2024-05-17 16:24:09','2024-05-17 16:24:09'),(432,'BP','cien pies de tabla','2024-05-17 16:24:09','2024-05-17 16:24:09'),(433,'BQL','becquerel','2024-05-17 16:24:09','2024-05-17 16:24:09'),(434,'BR','bar','2024-05-17 16:24:09','2024-05-17 16:24:09'),(435,'BT','tornillo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(436,'C30','milivoltios por metro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(437,'C31','milivatios','2024-05-17 16:24:09','2024-05-17 16:24:09'),(438,'C32','milivatios por metro cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(439,'C33','milliweber','2024-05-17 16:24:09','2024-05-17 16:24:09'),(440,'C34','Topo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(441,'C35','mol por decímetro cúbico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(442,'C36','mol por metro cúbico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(443,'C38','mol por litro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(444,'C39','Nanoampere','2024-05-17 16:24:09','2024-05-17 16:24:09'),(445,'C4','partido de carga','2024-05-17 16:24:09','2024-05-17 16:24:09'),(446,'C40','nanocoulomb','2024-05-17 16:24:09','2024-05-17 16:24:09'),(447,'C41','nanofarad','2024-05-17 16:24:09','2024-05-17 16:24:09'),(448,'C42','nanofarad por metro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(449,'C43','nanohenry','2024-05-17 16:24:09','2024-05-17 16:24:09'),(450,'C44','nanohenry por metro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(451,'C45','nanometro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(452,'C46','medidor de nanoohm','2024-05-17 16:24:09','2024-05-17 16:24:09'),(453,'C47','nanosegundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(454,'C48','nanotesla','2024-05-17 16:24:09','2024-05-17 16:24:09'),(455,'C49','nanovatio','2024-05-17 16:24:09','2024-05-17 16:24:09'),(456,'C5','costo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(457,'C50','neper','2024-05-17 16:24:09','2024-05-17 16:24:09'),(458,'C51','neper por segundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(459,'C52','picometro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(460,'C53','metro de newton segundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(461,'C54','newton metro cuadrado kilogramo cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(462,'C55','newton por metro cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(463,'C56','newton por milímetro cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(464,'C57','newton segundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(465,'C58','newton segundo por metro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(466,'C59','octava','2024-05-17 16:24:09','2024-05-17 16:24:09'),(467,'C6','célula','2024-05-17 16:24:09','2024-05-17 16:24:09'),(468,'C60','ohm centímetro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(469,'C61','ohm metro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(470,'C62','uno','2024-05-17 16:24:09','2024-05-17 16:24:09'),(471,'C63','parsec','2024-05-17 16:24:09','2024-05-17 16:24:09'),(472,'C64','pascal por kelvin','2024-05-17 16:24:09','2024-05-17 16:24:09'),(473,'C65','segundo pascal','2024-05-17 16:24:09','2024-05-17 16:24:09'),(474,'C66','segundo pascal por metro cúbico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(475,'C67','segundo pascal por metro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(476,'C68','petajoule','2024-05-17 16:24:09','2024-05-17 16:24:09'),(477,'C69','telefono','2024-05-17 16:24:09','2024-05-17 16:24:09'),(478,'C7','centipoise','2024-05-17 16:24:09','2024-05-17 16:24:09'),(479,'C70','picoampere','2024-05-17 16:24:09','2024-05-17 16:24:09'),(480,'C71','picocoulomb','2024-05-17 16:24:09','2024-05-17 16:24:09'),(481,'C72','picofarad por metro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(482,'C73','picohenry','2024-05-17 16:24:09','2024-05-17 16:24:09'),(483,'C75','picowatt','2024-05-17 16:24:09','2024-05-17 16:24:09'),(484,'C76','picowatt por metro cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(485,'C77','medidor de libras','2024-05-17 16:24:09','2024-05-17 16:24:09'),(486,'C78','fuerza de libra','2024-05-17 16:24:09','2024-05-17 16:24:09'),(487,'C8','Millicoulomb por kilogramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(488,'C80','rad','2024-05-17 16:24:09','2024-05-17 16:24:09'),(489,'C81','radián','2024-05-17 16:24:09','2024-05-17 16:24:09'),(490,'C82','medidor de radianes al cuadrado por mol','2024-05-17 16:24:09','2024-05-17 16:24:09'),(491,'C83','medidor de radianes al cuadrado por kilogramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(492,'C84','radian por metro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(493,'C85','â € ngstr recíproco “m','2024-05-17 16:24:09','2024-05-17 16:24:09'),(494,'C86','metro cúbico recíproco','2024-05-17 16:24:09','2024-05-17 16:24:09'),(495,'C87','metro cúbico recíproco por segundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(496,'C88','voltios de electrones recíprocos por metro cúbico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(497,'C89','Henry Recíproco','2024-05-17 16:24:09','2024-05-17 16:24:09'),(498,'C9','grupo de bobina','2024-05-17 16:24:09','2024-05-17 16:24:09'),(499,'C90','Joule recíproco por metro cúbico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(500,'C91','kelvin recíproco o kelvin al poder menos uno','2024-05-17 16:24:09','2024-05-17 16:24:09'),(501,'C92','medidor recíproco','2024-05-17 16:24:09','2024-05-17 16:24:09'),(502,'C93','metro cuadrado recíproco','2024-05-17 16:24:09','2024-05-17 16:24:09'),(503,'C94','minuto recíproco','2024-05-17 16:24:09','2024-05-17 16:24:09'),(504,'C95','mole recíproco','2024-05-17 16:24:09','2024-05-17 16:24:09'),(505,'C96','Pascal recíproco o pascal a la potencia menos uno.','2024-05-17 16:24:09','2024-05-17 16:24:09'),(506,'C97','segundo recíproco','2024-05-17 16:24:09','2024-05-17 16:24:09'),(507,'C98','segundo recíproco por metro cúbico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(508,'C99','segundo recíproco por metro cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(509,'CA','Caja','2024-05-17 16:24:09','2024-05-17 16:24:09'),(510,'CCT','Capacidad de carga en toneladas métricas.','2024-05-17 16:24:09','2024-05-17 16:24:09'),(511,'CDL','candela','2024-05-17 16:24:09','2024-05-17 16:24:09'),(512,'CEL','grado Celsius','2024-05-17 16:24:09','2024-05-17 16:24:09'),(513,'CEN','cien','2024-05-17 16:24:09','2024-05-17 16:24:09'),(514,'CG','tarjeta','2024-05-17 16:24:09','2024-05-17 16:24:09'),(515,'CGM','centigramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(516,'CH','envase','2024-05-17 16:24:09','2024-05-17 16:24:09'),(517,'CJ','cono','2024-05-17 16:24:09','2024-05-17 16:24:09'),(518,'CK','conector','2024-05-17 16:24:09','2024-05-17 16:24:09'),(519,'CKG','Coulomb por kilogramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(520,'CL','bobina','2024-05-17 16:24:09','2024-05-17 16:24:09'),(521,'CLF','cientos de licencia','2024-05-17 16:24:09','2024-05-17 16:24:09'),(522,'CLT','centilitro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(523,'CMK','centímetro cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(524,'CMQ','centímetro cúbico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(525,'CMT','centímetro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(526,'CNP','paquete de cien','2024-05-17 16:24:09','2024-05-17 16:24:09'),(527,'CNT','Cental (Reino Unido)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(528,'CO','garrafón','2024-05-17 16:24:09','2024-05-17 16:24:09'),(529,'COU','culombio','2024-05-17 16:24:09','2024-05-17 16:24:09'),(530,'CQ','cartucho','2024-05-17 16:24:09','2024-05-17 16:24:09'),(531,'CR','caja','2024-05-17 16:24:09','2024-05-17 16:24:09'),(532,'CS','caso','2024-05-17 16:24:09','2024-05-17 16:24:09'),(533,'CT','caja de cartón','2024-05-17 16:24:09','2024-05-17 16:24:09'),(534,'CTM','quilate métrico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(535,'CU','vaso','2024-05-17 16:24:09','2024-05-17 16:24:09'),(536,'CUR','curie','2024-05-17 16:24:09','2024-05-17 16:24:09'),(537,'CV','cubrir','2024-05-17 16:24:09','2024-05-17 16:24:09'),(538,'CWA','cien libras (quintales) / cien pesos (US)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(539,'CWI','cien pesos (Reino Unido)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(540,'CY','cilindro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(541,'CZ','combo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(542,'D1','segundo recíproco por esteradiano','2024-05-17 16:24:09','2024-05-17 16:24:09'),(543,'D10','siemens por metro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(544,'D12','siemens metro cuadrado por mol','2024-05-17 16:24:09','2024-05-17 16:24:09'),(545,'D13','sievert','2024-05-17 16:24:09','2024-05-17 16:24:09'),(546,'D14','mil yardas lineales','2024-05-17 16:24:09','2024-05-17 16:24:09'),(547,'D15','sone','2024-05-17 16:24:09','2024-05-17 16:24:09'),(548,'D16','centímetro cuadrado por ergio','2024-05-17 16:24:09','2024-05-17 16:24:09'),(549,'D17','centímetro cuadrado por erg esterlina','2024-05-17 16:24:09','2024-05-17 16:24:09'),(550,'D18','metro kelvin','2024-05-17 16:24:09','2024-05-17 16:24:09'),(551,'D19','kelvin metro cuadrado por vatio','2024-05-17 16:24:09','2024-05-17 16:24:09'),(552,'D2','segundo recíproco por metros cuadrados esteradianos','2024-05-17 16:24:09','2024-05-17 16:24:09'),(553,'D20','metro cuadrado por julio','2024-05-17 16:24:09','2024-05-17 16:24:09'),(554,'D21','metro cuadrado por kilogramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(555,'D22','metro cuadrado por mol','2024-05-17 16:24:09','2024-05-17 16:24:09'),(556,'D23','pluma gramo (proteína)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(557,'D24','metro cuadrado por esterilizador','2024-05-17 16:24:09','2024-05-17 16:24:09'),(558,'D25','metro cuadrado por julios esteradianos','2024-05-17 16:24:09','2024-05-17 16:24:09'),(559,'D26','metro cuadrado por voltio segundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(560,'D27','esteradiano','2024-05-17 16:24:09','2024-05-17 16:24:09'),(561,'D28','sifón','2024-05-17 16:24:09','2024-05-17 16:24:09'),(562,'D29','terahercios','2024-05-17 16:24:09','2024-05-17 16:24:09'),(563,'D30','terajulio','2024-05-17 16:24:09','2024-05-17 16:24:09'),(564,'D31','teravatio','2024-05-17 16:24:09','2024-05-17 16:24:09'),(565,'D32','hora de teravatio','2024-05-17 16:24:09','2024-05-17 16:24:09'),(566,'D33','tesla','2024-05-17 16:24:09','2024-05-17 16:24:09'),(567,'D34','Texas','2024-05-17 16:24:09','2024-05-17 16:24:09'),(568,'D35','caloría termoquímica','2024-05-17 16:24:09','2024-05-17 16:24:09'),(569,'D37','caloría termoquímica por gramo kelvin','2024-05-17 16:24:09','2024-05-17 16:24:09'),(570,'D38','calorías termoquímicas por segundo centímetro kelvin','2024-05-17 16:24:09','2024-05-17 16:24:09'),(571,'D39','calorías termoquímicas por segundo centímetro cuadrado kelvin','2024-05-17 16:24:09','2024-05-17 16:24:09'),(572,'D40','mil litros','2024-05-17 16:24:09','2024-05-17 16:24:09'),(573,'D41','tonelada por metro cúbico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(574,'D42','año tropical','2024-05-17 16:24:09','2024-05-17 16:24:09'),(575,'D43','unidad de masa atómica unificada','2024-05-17 16:24:09','2024-05-17 16:24:09'),(576,'D44','var','2024-05-17 16:24:09','2024-05-17 16:24:09'),(577,'D45','voltios al cuadrado por kelvin al cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(578,'D46','voltio – amperio','2024-05-17 16:24:09','2024-05-17 16:24:09'),(579,'D47','voltio por centímetro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(580,'D48','voltio por kelvin','2024-05-17 16:24:09','2024-05-17 16:24:09'),(581,'D49','milivoltios por kelvin','2024-05-17 16:24:09','2024-05-17 16:24:09'),(582,'D5','kilogramo por centímetro cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(583,'D50','voltios por metro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(584,'D51','voltios por milímetro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(585,'D52','vatios por kelvin','2024-05-17 16:24:09','2024-05-17 16:24:09'),(586,'D53','vatios por metro kelvin','2024-05-17 16:24:09','2024-05-17 16:24:09'),(587,'D54','vatios por metro cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(588,'D55','vatios por metro cuadrado kelvin','2024-05-17 16:24:09','2024-05-17 16:24:09'),(589,'D56','vatios por metro cuadrado de kelvin a la cuarta potencia','2024-05-17 16:24:09','2024-05-17 16:24:09'),(590,'D57','vatios por steradian','2024-05-17 16:24:09','2024-05-17 16:24:09'),(591,'D58','vatios por metro cuadrado esterlino','2024-05-17 16:24:09','2024-05-17 16:24:09'),(592,'D59','weber por metro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(593,'D6','röntgen por segundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(594,'D60','weber por milímetro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(595,'D61','minuto','2024-05-17 16:24:09','2024-05-17 16:24:09'),(596,'D62','segundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(597,'D63','libro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(598,'D64','bloquear','2024-05-17 16:24:09','2024-05-17 16:24:09'),(599,'D65','redondo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(600,'D66','casete','2024-05-17 16:24:09','2024-05-17 16:24:09'),(601,'D67','dólar por hora','2024-05-17 16:24:09','2024-05-17 16:24:09'),(602,'D69','pulgada a la cuarta potencia','2024-05-17 16:24:09','2024-05-17 16:24:09'),(603,'D7','Sandwich','2024-05-17 16:24:09','2024-05-17 16:24:09'),(604,'D70','Tabla Internacional (IT) caloría','2024-05-17 16:24:09','2024-05-17 16:24:09'),(605,'D71','Tabla Internacional (IT) calorías por segundo centímetro kelvin','2024-05-17 16:24:09','2024-05-17 16:24:09'),(606,'D72','Tabla Internacional (IT) calorías por segundo centímetro cuadrado kelvin','2024-05-17 16:24:09','2024-05-17 16:24:09'),(607,'D73','joule metro cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(608,'D74','kilogramo por mol','2024-05-17 16:24:09','2024-05-17 16:24:09'),(609,'D75','Tabla Internacional (IT) calorías por gramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(610,'D76','Tabla Internacional (IT) calorías por gramo kelvin','2024-05-17 16:24:09','2024-05-17 16:24:09'),(611,'D77','megacoulomb','2024-05-17 16:24:09','2024-05-17 16:24:09'),(612,'D79','haz','2024-05-17 16:24:09','2024-05-17 16:24:09'),(613,'D8','puntaje de drenaje','2024-05-17 16:24:09','2024-05-17 16:24:09'),(614,'D80','microwatt','2024-05-17 16:24:09','2024-05-17 16:24:09'),(615,'D81','microtesla','2024-05-17 16:24:09','2024-05-17 16:24:09'),(616,'D82','microvoltio','2024-05-17 16:24:09','2024-05-17 16:24:09'),(617,'D83','medidor de millinewton','2024-05-17 16:24:09','2024-05-17 16:24:09'),(618,'D85','microwatt por metro cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(619,'D86','Millicoulomb','2024-05-17 16:24:09','2024-05-17 16:24:09'),(620,'D87','milimol por kilogramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(621,'D88','millicoulomb por metro cúbico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(622,'D89','millicoulomb por metro cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(623,'D9','dina por centímetro cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(624,'D90','metro cúbico (neto)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(625,'D91','movimiento rápido del ojo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(626,'D92','banda','2024-05-17 16:24:09','2024-05-17 16:24:09'),(627,'D93','segundo por metro cúbico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(628,'D94','segundo por metro cúbico radianes','2024-05-17 16:24:09','2024-05-17 16:24:09'),(629,'D95','julios por gramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(630,'D96','libra bruta','2024-05-17 16:24:09','2024-05-17 16:24:09'),(631,'D97','carga de palet / unidad','2024-05-17 16:24:09','2024-05-17 16:24:09'),(632,'D98','libra de masa','2024-05-17 16:24:09','2024-05-17 16:24:09'),(633,'D99','manga','2024-05-17 16:24:09','2024-05-17 16:24:09'),(634,'DAA','despreciar','2024-05-17 16:24:09','2024-05-17 16:24:09'),(635,'DAD','diez dias','2024-05-17 16:24:09','2024-05-17 16:24:09'),(636,'día','DAY','2024-05-17 16:24:09','2024-05-17 16:24:09'),(637,'DB','libra seca','2024-05-17 16:24:09','2024-05-17 16:24:09'),(638,'DC','disco','2024-05-17 16:24:09','2024-05-17 16:24:09'),(639,'DD','la licenciatura','2024-05-17 16:24:09','2024-05-17 16:24:09'),(640,'DE','acuerdo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(641,'DEC','década','2024-05-17 16:24:09','2024-05-17 16:24:09'),(642,'DG','decigramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(643,'DI','dispensador','2024-05-17 16:24:09','2024-05-17 16:24:09'),(644,'DJ','decagramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(645,'DLT','decilitro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(646,'DMK','263nformaci cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(647,'DMQ','decímetro cúbico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(648,'DMT','decímetro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(649,'DN','medidor de decinewton','2024-05-17 16:24:09','2024-05-17 16:24:09'),(650,'DPC','docena pieza','2024-05-17 16:24:09','2024-05-17 16:24:09'),(651,'DPR','docena par','2024-05-17 16:24:09','2024-05-17 16:24:09'),(652,'DPT','tonelaje de desplazamiento','2024-05-17 16:24:09','2024-05-17 16:24:09'),(653,'DQ','registro de datos','2024-05-17 16:24:09','2024-05-17 16:24:09'),(654,'DR','tambor','2024-05-17 16:24:09','2024-05-17 16:24:09'),(655,'DRA','dram (US)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(656,'DRI','dram (Reino Unido)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(657,'DRL','docena rollo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(658,'DRM','dracma (Reino Unido)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(659,'DS','monitor','2024-05-17 16:24:09','2024-05-17 16:24:09'),(660,'DT','tonelada seca','2024-05-17 16:24:09','2024-05-17 16:24:09'),(661,'DTN','Decitonne','2024-05-17 16:24:09','2024-05-17 16:24:09'),(662,'DU','dina','2024-05-17 16:24:09','2024-05-17 16:24:09'),(663,'DWT','pennyweight','2024-05-17 16:24:09','2024-05-17 16:24:09'),(664,'DX','dina por centímetro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(665,'DY','libro de directorio','2024-05-17 16:24:09','2024-05-17 16:24:09'),(666,'DZN','docena','2024-05-17 16:24:09','2024-05-17 16:24:09'),(667,'DZP','paquete de doce','2024-05-17 16:24:09','2024-05-17 16:24:09'),(668,'E2','cinturón','2024-05-17 16:24:09','2024-05-17 16:24:09'),(669,'E3','remolque','2024-05-17 16:24:09','2024-05-17 16:24:09'),(670,'E4','kilogramo bruto','2024-05-17 16:24:09','2024-05-17 16:24:09'),(671,'E5','tonelada métrica larga','2024-05-17 16:24:09','2024-05-17 16:24:09'),(672,'EA','cada','2024-05-17 16:24:09','2024-05-17 16:24:09'),(673,'EB','casilla de correo electrónico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(674,'CE','cada uno por mes','2024-05-17 16:24:09','2024-05-17 16:24:09'),(675,'EP','paquete de once','2024-05-17 16:24:09','2024-05-17 16:24:09'),(676,'EQ','galón equivalente','2024-05-17 16:24:09','2024-05-17 16:24:09'),(677,'EV','sobre','2024-05-17 16:24:09','2024-05-17 16:24:09'),(678,'F1','mil pies cúbicos por día','2024-05-17 16:24:09','2024-05-17 16:24:09'),(679,'F9','Fibra por centímetro cúbico de aire','2024-05-17 16:24:09','2024-05-17 16:24:09'),(680,'FAH','grado Fahrenheit','2024-05-17 16:24:09','2024-05-17 16:24:09'),(681,'FAR','faradio','2024-05-17 16:24:09','2024-05-17 16:24:09'),(682,'FB','campo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(683,'FC','mil pies cúbicos','2024-05-17 16:24:09','2024-05-17 16:24:09'),(684,'FD','millón de partículas por pie cúbico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(685,'FE','pie de pista','2024-05-17 16:24:09','2024-05-17 16:24:09'),(686,'FF','cien metros cúbicos','2024-05-17 16:24:09','2024-05-17 16:24:09'),(687,'FG','parche transdérmico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(688,'FH','micromol','2024-05-17 16:24:09','2024-05-17 16:24:09'),(689,'FL','tonelada en escamas','2024-05-17 16:24:09','2024-05-17 16:24:09'),(690,'FM','millones de pies cúbicos','2024-05-17 16:24:09','2024-05-17 16:24:09'),(691,'pie','FOT','2024-05-17 16:24:09','2024-05-17 16:24:09'),(692,'FP','libra por pie cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(693,'FR','pie por minuto','2024-05-17 16:24:09','2024-05-17 16:24:09'),(694,'FS','pie por segundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(695,'FTK','pie cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(696,'FTQ','pie cubico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(697,'G2','US galones por minuto','2024-05-17 16:24:09','2024-05-17 16:24:09'),(698,'G3','Galon imperial por minuto','2024-05-17 16:24:09','2024-05-17 16:24:09'),(699,'G7','hoja de microficha','2024-05-17 16:24:09','2024-05-17 16:24:09'),(700,'GB','galón (US) por día','2024-05-17 16:24:09','2024-05-17 16:24:09'),(701,'GBQ','gigabecquerel','2024-05-17 16:24:09','2024-05-17 16:24:09'),(702,'GC','gramo por 100 gramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(703,'GD','barril bruto','2024-05-17 16:24:09','2024-05-17 16:24:09'),(704,'GE','libra por galón (US)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(705,'GF','gramo por metro (gramo por 100 centímetros)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(706,'GFI','gramo de isótopo fisionable','2024-05-17 16:24:09','2024-05-17 16:24:09'),(707,'GGR','gramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(708,'GH','medio galón (EE. UU.)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(709,'GIA','branquias','2024-05-17 16:24:09','2024-05-17 16:24:09'),(710,'GII','Gill (Reino Unido)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(711,'GJ','gramo por mililitro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(712,'GL','gramo por litro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(713,'GLD','galón seco (EE. UU.)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(714,'GLI','galón (Reino Unido)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(715,'GLL','galón','2024-05-17 16:24:09','2024-05-17 16:24:09'),(716,'GM','gramo por metro cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(717,'GN','galón bruto','2024-05-17 16:24:09','2024-05-17 16:24:09'),(718,'GO','miligramos por metro cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(719,'GP','miligramo por metro cúbico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(720,'GQ','microgramos por metro cúbico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(721,'GRM','gramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(722,'GRN','grano','2024-05-17 16:24:09','2024-05-17 16:24:09'),(723,'GRO','bruto','2024-05-17 16:24:09','2024-05-17 16:24:09'),(724,'GRT','tonelada de registro bruto','2024-05-17 16:24:09','2024-05-17 16:24:09'),(725,'GT','tonelada bruta','2024-05-17 16:24:09','2024-05-17 16:24:09'),(726,'GV','gigajoule','2024-05-17 16:24:09','2024-05-17 16:24:09'),(727,'GW','galón por mil pies cúbicos','2024-05-17 16:24:09','2024-05-17 16:24:09'),(728,'GWH','hora de gigavatios','2024-05-17 16:24:09','2024-05-17 16:24:09'),(729,'GY','patio bruto','2024-05-17 16:24:09','2024-05-17 16:24:09'),(730,'GZ','sistema de medición','2024-05-17 16:24:09','2024-05-17 16:24:09'),(731,'H1','media página – electrónica','2024-05-17 16:24:09','2024-05-17 16:24:09'),(732,'H2','medio litro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(733,'HA','madeja','2024-05-17 16:24:09','2024-05-17 16:24:09'),(734,'HAR','hectárea','2024-05-17 16:24:09','2024-05-17 16:24:09'),(735,'HBA','hectobar','2024-05-17 16:24:09','2024-05-17 16:24:09'),(736,'HBX','cien cajas','2024-05-17 16:24:09','2024-05-17 16:24:09'),(737,'HC','cien cuentas','2024-05-17 16:24:09','2024-05-17 16:24:09'),(738,'HD','media docena','2024-05-17 16:24:09','2024-05-17 16:24:09'),(739,'ÉL','centésima de quilate','2024-05-17 16:24:09','2024-05-17 16:24:09'),(740,'HF','cien pies','2024-05-17 16:24:09','2024-05-17 16:24:09'),(741,'HGM','hectogramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(742,'HH','cien pies cúbicos','2024-05-17 16:24:09','2024-05-17 16:24:09'),(743,'HI','cien hojas','2024-05-17 16:24:09','2024-05-17 16:24:09'),(744,'HIU','cien unidades internacionales','2024-05-17 16:24:09','2024-05-17 16:24:09'),(745,'HJ','caballo métrico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(746,'HK','cien kilogramos','2024-05-17 16:24:09','2024-05-17 16:24:09'),(747,'HL','cien pies (lineales)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(748,'HLT','hectolitro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(749,'HM','milla por hora','2024-05-17 16:24:09','2024-05-17 16:24:09'),(750,'HMQ','millones de metros cúbicos','2024-05-17 16:24:09','2024-05-17 16:24:09'),(751,'HMT','hectómetro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(752,'HN','milímetro convencional de mercurio','2024-05-17 16:24:09','2024-05-17 16:24:09'),(753,'HO','cien onzas troy','2024-05-17 16:24:09','2024-05-17 16:24:09'),(754,'HP','milímetro convencional de agua','2024-05-17 16:24:09','2024-05-17 16:24:09'),(755,'HPA','hectolitro de alcohol puro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(756,'HS','cien pies cuadrados','2024-05-17 16:24:09','2024-05-17 16:24:09'),(757,'HT','media hora','2024-05-17 16:24:09','2024-05-17 16:24:09'),(758,'HTZ','hertz','2024-05-17 16:24:09','2024-05-17 16:24:09'),(759,'HUR','hora','2024-05-17 16:24:09','2024-05-17 16:24:09'),(760,'HY','cien yardas','2024-05-17 16:24:09','2024-05-17 16:24:09'),(761,'IA','pulgada libra','2024-05-17 16:24:09','2024-05-17 16:24:09'),(762,'IC','contar por pulgada','2024-05-17 16:24:09','2024-05-17 16:24:09'),(763,'IE','persona','2024-05-17 16:24:09','2024-05-17 16:24:09'),(764,'IF','pulgadas de agua','2024-05-17 16:24:09','2024-05-17 16:24:09'),(765,'II','columna pulgada','2024-05-17 16:24:09','2024-05-17 16:24:09'),(766,'IL','pulgada por minuto','2024-05-17 16:24:09','2024-05-17 16:24:09'),(767,'IM','impresión','2024-05-17 16:24:09','2024-05-17 16:24:09'),(768,'INH','pulgada','2024-05-17 16:24:09','2024-05-17 16:24:09'),(769,'KI','Kilogramo por milímetro de ancho','2024-05-17 16:24:09','2024-05-17 16:24:09'),(770,'KJ','kilosegmento','2024-05-17 16:24:09','2024-05-17 16:24:09'),(771,'KJO','kilojoule','2024-05-17 16:24:09','2024-05-17 16:24:09'),(772,'KL','kilogramo por metro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(773,'KMH','kilómetro por hora','2024-05-17 16:24:09','2024-05-17 16:24:09'),(774,'KMK','kilometro cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(775,'KMQ','kilogramo por metro cúbico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(776,'KNI','kilogramo de nitrógeno','2024-05-17 16:24:09','2024-05-17 16:24:09'),(777,'KNS','kilogramo de sustancia nombrada','2024-05-17 16:24:09','2024-05-17 16:24:09'),(778,'nudo','KNT','2024-05-17 16:24:09','2024-05-17 16:24:09'),(779,'KO','Milliequivalencia de potasa cáustica por gramo de producto.','2024-05-17 16:24:09','2024-05-17 16:24:09'),(780,'KPA','kilopascal','2024-05-17 16:24:09','2024-05-17 16:24:09'),(781,'KPH','kilogramo de hidróxido de potasio (potasa cáustica)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(782,'KPO','kilogramo de óxido de potasio','2024-05-17 16:24:09','2024-05-17 16:24:09'),(783,'KPP','kilogramo de pentóxido de fósforo (anhídrido fosfórico)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(784,'KR','KilorÃ¶ntgen','2024-05-17 16:24:09','2024-05-17 16:24:09'),(785,'KS','mil libras por pulgada cuadrada','2024-05-17 16:24:09','2024-05-17 16:24:09'),(786,'KSD','kilogramo de sustancia 90% seca','2024-05-17 16:24:09','2024-05-17 16:24:09'),(787,'KSH','kilogramo de hidróxido de sodio (soda cáustica)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(788,'KT','equipo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(789,'KTM','kilómetro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(790,'KTN','kilotonne','2024-05-17 16:24:09','2024-05-17 16:24:09'),(791,'KUR','kilogramo de uranio','2024-05-17 16:24:09','2024-05-17 16:24:09'),(792,'KVA','kilovoltio – ampere','2024-05-17 16:24:09','2024-05-17 16:24:09'),(793,'KVR','kilovar','2024-05-17 16:24:09','2024-05-17 16:24:09'),(794,'KVT','kilovoltio','2024-05-17 16:24:09','2024-05-17 16:24:09'),(795,'KW','kilogramos por milímetro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(796,'KWH','kilovatios hora','2024-05-17 16:24:09','2024-05-17 16:24:09'),(797,'KWT','kilovatio','2024-05-17 16:24:09','2024-05-17 16:24:09'),(798,'KX','mililitro por kilogramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(799,'L2','litro por minuto','2024-05-17 16:24:09','2024-05-17 16:24:09'),(800,'LA','libra por pulgada cúbica','2024-05-17 16:24:09','2024-05-17 16:24:09'),(801,'LBR','libra','2024-05-17 16:24:09','2024-05-17 16:24:09'),(802,'LBT','libra troy','2024-05-17 16:24:09','2024-05-17 16:24:09'),(803,'LC','centímetro lineal','2024-05-17 16:24:09','2024-05-17 16:24:09'),(804,'LD','litro por día','2024-05-17 16:24:09','2024-05-17 16:24:09'),(805,'LE','lite','2024-05-17 16:24:09','2024-05-17 16:24:09'),(806,'LEF','hoja','2024-05-17 16:24:09','2024-05-17 16:24:09'),(807,'LF','pie lineal','2024-05-17 16:24:09','2024-05-17 16:24:09'),(808,'LH','hora de trabajo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(809,'LI','pulgada lineal','2024-05-17 16:24:09','2024-05-17 16:24:09'),(810,'LJ','spray grande','2024-05-17 16:24:09','2024-05-17 16:24:09'),(811,'LK','enlazar','2024-05-17 16:24:09','2024-05-17 16:24:09'),(812,'LM','metro lineal','2024-05-17 16:24:09','2024-05-17 16:24:09'),(813,'LN','longitud','2024-05-17 16:24:09','2024-05-17 16:24:09'),(814,'LO','mucho','2024-05-17 16:24:09','2024-05-17 16:24:09'),(815,'LP','libra liquida','2024-05-17 16:24:09','2024-05-17 16:24:09'),(816,'LPA','litro de alcohol puro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(817,'LR','capa','2024-05-17 16:24:09','2024-05-17 16:24:09'),(818,'LS','Suma global','2024-05-17 16:24:09','2024-05-17 16:24:09'),(819,'LTN','ton (Reino Unido) o longton (EE. UU.)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(820,'LTR','litro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(821,'LUM','lumen','2024-05-17 16:24:09','2024-05-17 16:24:09'),(822,'lux','LUX','2024-05-17 16:24:09','2024-05-17 16:24:09'),(823,'LX','yarda lineal por libra','2024-05-17 16:24:09','2024-05-17 16:24:09'),(824,'LY','yarda lineal','2024-05-17 16:24:09','2024-05-17 16:24:09'),(825,'M0','cinta magnética','2024-05-17 16:24:09','2024-05-17 16:24:09'),(826,'M1','miligramos por litro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(827,'M4','valor monetario','2024-05-17 16:24:09','2024-05-17 16:24:09'),(828,'M5','microcurie','2024-05-17 16:24:09','2024-05-17 16:24:09'),(829,'M7','micropulgada','2024-05-17 16:24:09','2024-05-17 16:24:09'),(830,'M9','millones de Btu por 1000 pies cúbicos','2024-05-17 16:24:09','2024-05-17 16:24:09'),(831,'MA','máquina por unidad','2024-05-17 16:24:09','2024-05-17 16:24:09'),(832,'MAL','mega litro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(833,'MAM','megametro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(834,'MAW','megavatio','2024-05-17 16:24:09','2024-05-17 16:24:09'),(835,'MBE','mil equivalentes de ladrillo estándar','2024-05-17 16:24:09','2024-05-17 16:24:09'),(836,'MBF','mil pies de tabla','2024-05-17 16:24:09','2024-05-17 16:24:09'),(837,'MBR','milibar','2024-05-17 16:24:09','2024-05-17 16:24:09'),(838,'MC','microgramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(839,'MCU','milicurie','2024-05-17 16:24:09','2024-05-17 16:24:09'),(840,'MD','aire seco tonelada métrica','2024-05-17 16:24:09','2024-05-17 16:24:09'),(841,'MF','miligramo por pie cuadrado por lado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(842,'MGM','miligramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(843,'MIK','milla cuadrada','2024-05-17 16:24:09','2024-05-17 16:24:09'),(844,'mil','MIL','2024-05-17 16:24:09','2024-05-17 16:24:09'),(845,'MIN','minuto','2024-05-17 16:24:09','2024-05-17 16:24:09'),(846,'MIO','millón','2024-05-17 16:24:09','2024-05-17 16:24:09'),(847,'MIU','millones de unidades internacionales','2024-05-17 16:24:09','2024-05-17 16:24:09'),(848,'MK','miligramo por pulgada cuadrada','2024-05-17 16:24:09','2024-05-17 16:24:09'),(849,'MLD','mil millones','2024-05-17 16:24:09','2024-05-17 16:24:09'),(850,'MLT','mililitro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(851,'MMK','milímetro cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(852,'MMQ','milímetro cúbico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(853,'MMT','milímetro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(854,'LUN','mes','2024-05-17 16:24:09','2024-05-17 16:24:09'),(855,'MPA','megapascal','2024-05-17 16:24:09','2024-05-17 16:24:09'),(856,'MQ','mil metros','2024-05-17 16:24:09','2024-05-17 16:24:09'),(857,'MQH','metro cúbico por hora','2024-05-17 16:24:09','2024-05-17 16:24:09'),(858,'MQS','metro cúbico por segundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(859,'MSK','metro por segundo al cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(860,'MT','estera','2024-05-17 16:24:09','2024-05-17 16:24:09'),(861,'MTK','metro cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(862,'MTQ','Metro cúbico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(863,'MTR','metro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(864,'MTS','metro por segundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(865,'MV','numero de mults','2024-05-17 16:24:09','2024-05-17 16:24:09'),(866,'MVA','megavolt – ampere','2024-05-17 16:24:09','2024-05-17 16:24:09'),(867,'MWH','megavatios hora (1000 kW.h)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(868,'N1','calorías de la pluma','2024-05-17 16:24:09','2024-05-17 16:24:09'),(869,'N2','número de líneas','2024-05-17 16:24:09','2024-05-17 16:24:09'),(870,'N3','punto de impresión','2024-05-17 16:24:09','2024-05-17 16:24:09'),(871,'NA','miligramo por kilogramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(872,'NAR','número de artículos','2024-05-17 16:24:09','2024-05-17 16:24:09'),(873,'NB','barcaza','2024-05-17 16:24:09','2024-05-17 16:24:09'),(874,'NBB','número de bobinas','2024-05-17 16:24:09','2024-05-17 16:24:09'),(875,'NC','coche','2024-05-17 16:24:09','2024-05-17 16:24:09'),(876,'NCL','número de celdas','2024-05-17 16:24:09','2024-05-17 16:24:09'),(877,'ND','barril neto','2024-05-17 16:24:09','2024-05-17 16:24:09'),(878,'NE','litro neto','2024-05-17 16:24:09','2024-05-17 16:24:09'),(879,'NEW','newton','2024-05-17 16:24:09','2024-05-17 16:24:09'),(880,'NF','mensaje','2024-05-17 16:24:09','2024-05-17 16:24:09'),(881,'NG','galón neto (nosotros)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(882,'NH','hora del mensaje','2024-05-17 16:24:09','2024-05-17 16:24:09'),(883,'NI','galón imperial neto','2024-05-17 16:24:09','2024-05-17 16:24:09'),(884,'NIU','número de unidades internacionales','2024-05-17 16:24:09','2024-05-17 16:24:09'),(885,'NJ','número de pantallas','2024-05-17 16:24:09','2024-05-17 16:24:09'),(886,'NL','carga','2024-05-17 16:24:09','2024-05-17 16:24:09'),(887,'MNI','milla nautica','2024-05-17 16:24:09','2024-05-17 16:24:09'),(888,'NMP','número de paquetes','2024-05-17 16:24:09','2024-05-17 16:24:09'),(889,'NN','entrenar','2024-05-17 16:24:09','2024-05-17 16:24:09'),(890,'NPL','número de parcelas','2024-05-17 16:24:09','2024-05-17 16:24:09'),(891,'NPR','numero de pares','2024-05-17 16:24:09','2024-05-17 16:24:09'),(892,'TNP','numero de partes','2024-05-17 16:24:09','2024-05-17 16:24:09'),(893,'NQ','mho','2024-05-17 16:24:09','2024-05-17 16:24:09'),(894,'NR','micromho','2024-05-17 16:24:09','2024-05-17 16:24:09'),(895,'NRL','número de rollos','2024-05-17 16:24:09','2024-05-17 16:24:09'),(896,'NT','tonelada neta','2024-05-17 16:24:09','2024-05-17 16:24:09'),(897,'NTT','registro neto de toneladas','2024-05-17 16:24:09','2024-05-17 16:24:09'),(898,'NU','medidor de newton','2024-05-17 16:24:09','2024-05-17 16:24:09'),(899,'NV','vehículo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(900,'NX','parte por mil','2024-05-17 16:24:09','2024-05-17 16:24:09'),(901,'NY','libra por aire seco tonelada métrica','2024-05-17 16:24:09','2024-05-17 16:24:09'),(902,'OA','panel','2024-05-17 16:24:09','2024-05-17 16:24:09'),(903,'OHM','ohm','2024-05-17 16:24:09','2024-05-17 16:24:09'),(904,'EN','onza por yarda cuadrada','2024-05-17 16:24:09','2024-05-17 16:24:09'),(905,'ONZ','onza','2024-05-17 16:24:09','2024-05-17 16:24:09'),(906,'OP','Dos paquetes','2024-05-17 16:24:09','2024-05-17 16:24:09'),(907,'OT','hora extra','2024-05-17 16:24:09','2024-05-17 16:24:09'),(908,'OZA','onza líquida (US)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(909,'OZI','onza líquida (Reino Unido)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(910,'P0','pagina – electronica','2024-05-17 16:24:09','2024-05-17 16:24:09'),(911,'P1','por ciento','2024-05-17 16:24:09','2024-05-17 16:24:09'),(912,'P2','libra por pie','2024-05-17 16:24:09','2024-05-17 16:24:09'),(913,'P3','paquete de tres','2024-05-17 16:24:09','2024-05-17 16:24:09'),(914,'P4','paquete de cuatro','2024-05-17 16:24:09','2024-05-17 16:24:09'),(915,'P5','paquete de cinco','2024-05-17 16:24:09','2024-05-17 16:24:09'),(916,'P6','paquete de seis','2024-05-17 16:24:09','2024-05-17 16:24:09'),(917,'P7','paquete de siete','2024-05-17 16:24:09','2024-05-17 16:24:09'),(918,'P8','paquete de ocho','2024-05-17 16:24:09','2024-05-17 16:24:09'),(919,'P9','paquete de nueve','2024-05-17 16:24:09','2024-05-17 16:24:09'),(920,'PA','paquete','2024-05-17 16:24:09','2024-05-17 16:24:09'),(921,'PAL','pascal','2024-05-17 16:24:09','2024-05-17 16:24:09'),(922,'PB','par de pulgadas','2024-05-17 16:24:09','2024-05-17 16:24:09'),(923,'PD','almohadilla','2024-05-17 16:24:09','2024-05-17 16:24:09'),(924,'PE','equivalente en libras','2024-05-17 16:24:09','2024-05-17 16:24:09'),(925,'PF','palet (ascensor)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(926,'PG','plato','2024-05-17 16:24:09','2024-05-17 16:24:09'),(927,'PGL','galón de prueba','2024-05-17 16:24:09','2024-05-17 16:24:09'),(928,'Pi','tono','2024-05-17 16:24:09','2024-05-17 16:24:09'),(929,'PK','paquete','2024-05-17 16:24:09','2024-05-17 16:24:09'),(930,'PL','cubo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(931,'PM','porcentaje de libra','2024-05-17 16:24:09','2024-05-17 16:24:09'),(932,'PN','libra neta','2024-05-17 16:24:09','2024-05-17 16:24:09'),(933,'PO','libra por pulgada de longitud','2024-05-17 16:24:09','2024-05-17 16:24:09'),(934,'PQ','página por pulgada','2024-05-17 16:24:09','2024-05-17 16:24:09'),(935,'par','PR','2024-05-17 16:24:09','2024-05-17 16:24:09'),(936,'PT','pinta','2024-05-17 16:24:09','2024-05-17 16:24:09'),(937,'PTD','pinta seca','2024-05-17 16:24:09','2024-05-17 16:24:09'),(938,'PTI','pinta (Reino Unido)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(939,'PTL','pinta liquida (US)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(940,'PU','bandeja / paquete de bandeja','2024-05-17 16:24:09','2024-05-17 16:24:09'),(941,'PV','media pinta (US)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(942,'PW','libra por pulgada de ancho','2024-05-17 16:24:09','2024-05-17 16:24:09'),(943,'PY','Peck Dry (US)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(944,'PZ','Peck Dry (Reino Unido)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(945,'Q3','comida','2024-05-17 16:24:09','2024-05-17 16:24:09'),(946,'QA','página – facsímil','2024-05-17 16:24:09','2024-05-17 16:24:09'),(947,'QAN','cuarto (de un año)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(948,'QB','página – copia impresa','2024-05-17 16:24:09','2024-05-17 16:24:09'),(949,'QD','cuarto de docena','2024-05-17 16:24:09','2024-05-17 16:24:09'),(950,'QH','un cuarto de hora','2024-05-17 16:24:09','2024-05-17 16:24:09'),(951,'QK','cuarto de kilogramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(952,'QR','mano de papel','2024-05-17 16:24:09','2024-05-17 16:24:09'),(953,'QT','cuarto de galón (US)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(954,'QTD','cuarto seco (EE. UU.)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(955,'QTI','cuarto de galón (Reino Unido)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(956,'QTL','cuarto líquido (US)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(957,'QTR','cuarto (UK)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(958,'R1','pica','2024-05-17 16:24:09','2024-05-17 16:24:09'),(959,'R4','caloría','2024-05-17 16:24:09','2024-05-17 16:24:09'),(960,'R9','mil metros cúbicos','2024-05-17 16:24:09','2024-05-17 16:24:09'),(961,'RA','estante','2024-05-17 16:24:09','2024-05-17 16:24:09'),(962,'RD','barra','2024-05-17 16:24:09','2024-05-17 16:24:09'),(963,'RG','anillo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(964,'RH','hora de funcionamiento o de funcionamiento','2024-05-17 16:24:09','2024-05-17 16:24:09'),(965,'RK','medida métrica rollo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(966,'RL','carrete','2024-05-17 16:24:09','2024-05-17 16:24:09'),(967,'RM','resma','2024-05-17 16:24:09','2024-05-17 16:24:09'),(968,'RN','medida métrica de resma','2024-05-17 16:24:09','2024-05-17 16:24:09'),(969,'RO','rodar','2024-05-17 16:24:09','2024-05-17 16:24:09'),(970,'RP','libra por resma','2024-05-17 16:24:09','2024-05-17 16:24:09'),(971,'RPM','revoluciones por minuto','2024-05-17 16:24:09','2024-05-17 16:24:09'),(972,'RPS','revoluciones por segundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(973,'RS','Reiniciar','2024-05-17 16:24:09','2024-05-17 16:24:09'),(974,'RT','ingreso tonelada milla','2024-05-17 16:24:09','2024-05-17 16:24:09'),(975,'RU','correr','2024-05-17 16:24:09','2024-05-17 16:24:09'),(976,'S3','pie cuadrado por segundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(977,'S4','metro cuadrado por segundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(978,'S5','sesenta cuartos de pulgada','2024-05-17 16:24:09','2024-05-17 16:24:09'),(979,'S6','sesión','2024-05-17 16:24:09','2024-05-17 16:24:09'),(980,'S7','unidad de almacenamiento','2024-05-17 16:24:09','2024-05-17 16:24:09'),(981,'S8','unidad de publicidad estándar','2024-05-17 16:24:09','2024-05-17 16:24:09'),(982,'SA','saco','2024-05-17 16:24:09','2024-05-17 16:24:09'),(983,'SAN','medio año (6 meses)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(984,'OCS','Puntuación','2024-05-17 16:24:09','2024-05-17 16:24:09'),(985,'SCR','escrúpulo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(986,'SD','libra solida','2024-05-17 16:24:09','2024-05-17 16:24:09'),(987,'SE','sección','2024-05-17 16:24:09','2024-05-17 16:24:09'),(988,'SEC','segundo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(989,'SET','conjunto','2024-05-17 16:24:09','2024-05-17 16:24:09'),(990,'SG','segmento','2024-05-17 16:24:09','2024-05-17 16:24:09'),(991,'SHT','tonelada de envío','2024-05-17 16:24:09','2024-05-17 16:24:09'),(992,'SIE','siemens','2024-05-17 16:24:09','2024-05-17 16:24:09'),(993,'SK','camión cisterna dividido','2024-05-17 16:24:09','2024-05-17 16:24:09'),(994,'SL','hoja de deslizamiento','2024-05-17 16:24:09','2024-05-17 16:24:09'),(995,'SMI','milla (milla estatutaria)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(996,'SN','varilla cuadrada','2024-05-17 16:24:09','2024-05-17 16:24:09'),(997,'SO','carrete','2024-05-17 16:24:09','2024-05-17 16:24:09'),(998,'SP','paquete de estante','2024-05-17 16:24:09','2024-05-17 16:24:09'),(999,'SQ','cuadrado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1000,'SR','tira','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1001,'SS','hoja métrica medida','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1002,'SST','corto estándar (7200 partidos)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1003,'ST','hoja','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1004,'ITS','piedra (Reino Unido)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1005,'STN','tonelada (US) o tonelada corta (UK / US)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1006,'SV','patinar','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1007,'SX','envío','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1008,'T0','Línea de telecomunicaciones en servicio.','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1009,'T1','mil libras brutas','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1010,'T3','mil piezas','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1011,'T4','bolsa de mil','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1012,'T5','caja de mil','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1013,'T6','mil galones (US)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1014,'T7','mil impresiones','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1015,'T8','mil pulgadas lineales','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1016,'TA','décimo pie cúbico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1017,'TAH','Kiloampere hora (mil amperios hora)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1018,'TC','camion','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1019,'TD','termia','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1020,'TE','totalizador','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1021,'TF','diez metros cuadrados','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1022,'TI','mil pulgadas cuadradas','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1023,'TJ','mil centímetros cuadrados','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1024,'TK','tanque, rectangular','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1025,'TL','mil pies (lineales)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1026,'TN','estaño','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1027,'TNE','tonelada (tonelada métrica)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1028,'TP','paquete de diez','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1029,'TPR','diez pares','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1030,'TQ','mil pies','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1031,'TQD','mil metros cúbicos por día','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1032,'TR','diez pies cuadrados','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1033,'TRL','trillón (EUR)','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1034,'TS','mil pies cuadrados','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1035,'TSD','tonelada de sustancia 90% seca','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1036,'TSH','tonelada de vapor por hora','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1037,'TT','mil metros lineales','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1038,'TU','tubo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1039,'TV','mil kilogramos','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1040,'TW','mil hojas','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1041,'TY','tanque, cilíndrico','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1042,'U1','tratamiento','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1043,'U2','tableta','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1044,'UA','torr','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1045,'UB','Línea de telecomunicaciones en servicio promedio.','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1046,'UC','puerto de telecomunicaciones','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1047,'UD','décimo minuto','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1048,'UE','décima hora','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1049,'UF','uso por línea de telecomunicación promedio','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1050,'UH','diez mil yardas','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1051,'UM','millones de unidades','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1052,'VA','voltio amperio por kilogramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1053,'VI','frasco','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1054,'VLT','voltio','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1055,'VQ','abultar','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1056,'VS','visitar','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1057,'W2','kilo mojado','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1058,'W4','dos semanas','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1059,'WA','vatio por kilogramo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1060,'WB','libra mojada','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1061,'WCD','cable','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1062,'WE','tonelada mojada','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1063,'WEB','weber','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1064,'WEE','semana','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1065,'WG','galon de vino','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1066,'WH','rueda','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1067,'WHR','vatios hora','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1068,'WI','peso por pulgada cuadrada','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1069,'WM','mes de trabajo','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1070,'WR','envolver','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1071,'WSD','estándar Servicios','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1072,'WTT','vatio','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1073,'WW','mililitro de agua','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1074,'X1','cadena','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1075,'YDK','yarda cuadrada','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1076,'YDQ','Yarda cúbica','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1077,'YL','cien yardas lineales','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1078,'YRD','yarda','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1079,'YT','diez yardas','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1080,'Z1','van de elevación','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1081,'Z2','pecho','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1082,'Z3','barril','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1083,'Z4','pipa','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1084,'Z5','arrastrar','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1085,'Z6','punto de conferencia','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1086,'Z8','línea de noticias de ágata','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1087,'ZP','página','2024-05-17 16:24:09','2024-05-17 16:24:09'),(1088,'ZZ','mutuamente definido','2024-05-17 16:24:09','2024-05-17 16:24:09');
/*!40000 ALTER TABLE `measurement_units` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=158 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (135,'2014_10_12_000000_create_users_table',1),(136,'2014_10_12_100000_create_password_reset_tokens_table',1),(137,'2014_10_12_100000_create_password_resets_table',1),(138,'2019_08_19_000000_create_failed_jobs_table',1),(139,'2019_12_14_000001_create_personal_access_tokens_table',1),(140,'2024_02_18_193718_category_products',1),(141,'2024_02_19_150608_sub_categories',1),(142,'2024_02_19_193730_brands',1),(143,'2024_02_19_193758_measurement_units',1),(144,'2024_02_19_193821_products',1),(145,'2024_03_04_215331_people',1),(146,'2024_03_05_162129_countries',1),(147,'2024_03_05_172018_departments',1),(148,'2024_03_06_161711_municipalities',1),(149,'2024_03_18_180327_purchase_suppliers',1),(150,'2024_03_19_154150_detail_purchase',1),(151,'2024_03_22_192215_create_sales_table',1),(152,'2024_03_29_123706_debit_note_suppliers',1),(153,'2024_04_03_164934_create_permission_tables',1),(154,'2024_04_04_141619_create_product_sale',1),(155,'2024_04_15_213512_create_credit_note_sales_table',1),(156,'2024_05_01_013003_create_credit_note_sales_product_table',1),(157,'2024_05_08_022734_create_jobs_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (1,'App\\Models\\User',1);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `municipalities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `municipalities` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` tinyint NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `departments_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `municipalities_departments_id_foreign` (`departments_id`),
  CONSTRAINT `municipalities_departments_id_foreign` FOREIGN KEY (`departments_id`) REFERENCES `departments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `municipalities` WRITE;
/*!40000 ALTER TABLE `municipalities` DISABLE KEYS */;
/*!40000 ALTER TABLE `municipalities` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `people`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `people` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `rol` enum('Cliente','Proveedor') COLLATE utf8mb4_unicode_ci NOT NULL,
  `identification_type` enum('CC','CE','DIE','TI','RC','TE','NIT','PP','NUIP','NITO','PEP') COLLATE utf8mb4_unicode_ci NOT NULL,
  `identification_number` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `person_type` enum('Persona natural','Persona jurídica') COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comercial_name` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other_name` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `surname` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `second_surname` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `digit_verification` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `people` WRITE;
/*!40000 ALTER TABLE `people` DISABLE KEYS */;
INSERT INTO `people` VALUES (1,'Proveedor','CC','666666','Persona natural',NULL,'GTK','Brayan','Alejandro','Pinilla','Vargas','3','bg@gmail.com','Sogamoso','calle 7','10290033',1,'2024-05-17 16:27:39','2024-05-17 16:27:39');
/*!40000 ALTER TABLE `people` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'admin.usuarios.index','web','2024-05-17 16:22:50','2024-05-17 16:22:50'),(2,'admin.usuarios.edit','web','2024-05-17 16:22:50','2024-05-17 16:22:50'),(3,'admin.usuarios.update','web','2024-05-17 16:22:50','2024-05-17 16:22:50'),(4,'','web','2024-05-17 16:22:50','2024-05-17 16:22:50'),(5,'home','web','2024-05-17 16:22:50','2024-05-17 16:22:50'),(6,'products','web','2024-05-17 16:22:50','2024-05-17 16:22:50'),(7,'category','web','2024-05-17 16:22:50','2024-05-17 16:22:50'),(8,'brand','web','2024-05-17 16:22:50','2024-05-17 16:22:50'),(9,'units','web','2024-05-17 16:22:50','2024-05-17 16:22:50'),(10,'categorySub','web','2024-05-17 16:22:50','2024-05-17 16:22:50'),(11,'sales','web','2024-05-17 16:22:51','2024-05-17 16:22:51'),(12,'credit-note-sales','web','2024-05-17 16:22:51','2024-05-17 16:22:51'),(13,'person','web','2024-05-17 16:22:51','2024-05-17 16:22:51'),(14,'customer','web','2024-05-17 16:22:51','2024-05-17 16:22:51'),(15,'supplier','web','2024-05-17 16:22:51','2024-05-17 16:22:51'),(16,'indexAll','web','2024-05-17 16:22:51','2024-05-17 16:22:51'),(17,'purchase_supplier','web','2024-05-17 16:22:51','2024-05-17 16:22:51'),(18,'detail-purchases','web','2024-05-17 16:22:51','2024-05-17 16:22:51'),(19,'debit-note-supplier','web','2024-05-17 16:22:51','2024-05-17 16:22:51'),(20,'report','web','2024-05-17 16:22:51','2024-05-17 16:22:51');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `product_sale`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_sale` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `sale_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `references` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` int NOT NULL,
  `selling_price` decimal(10,2) NOT NULL,
  `discounts` decimal(8,2) NOT NULL,
  `tax` decimal(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_sale_sale_id_foreign` (`sale_id`),
  KEY `product_sale_product_id_foreign` (`product_id`),
  CONSTRAINT `product_sale_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_sale_sale_id_foreign` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `product_sale` WRITE;
/*!40000 ALTER TABLE `product_sale` DISABLE KEYS */;
INSERT INTO `product_sale` VALUES (1,1,1,'QWER',3,8000.00,15.00,0.00,'2024-05-17 16:28:47','2024-05-17 16:28:47'),(2,2,2,'TYU89',7,3000.00,0.00,19.00,'2024-05-17 17:25:45','2024-05-17 17:25:45');
/*!40000 ALTER TABLE `product_sale` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name_product` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_long` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `factory_reference` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `classification_tax` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `selling_price` decimal(10,2) NOT NULL,
  `purchase_price` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `stock` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `subcategory_product` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_products_id` bigint unsigned NOT NULL,
  `brands_id` bigint unsigned NOT NULL,
  `measurement_units_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `products_category_products_id_foreign` (`category_products_id`),
  KEY `products_brands_id_foreign` (`brands_id`),
  KEY `products_measurement_units_id_foreign` (`measurement_units_id`),
  CONSTRAINT `products_brands_id_foreign` FOREIGN KEY (`brands_id`) REFERENCES `brands` (`id`),
  CONSTRAINT `products_category_products_id_foreign` FOREIGN KEY (`category_products_id`) REFERENCES `category_products` (`id`),
  CONSTRAINT `products_measurement_units_id_foreign` FOREIGN KEY (`measurement_units_id`) REFERENCES `measurement_units` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'Popelle Master',NULL,'OPL','0%',8000.00,'0',NULL,1,'7','Ceramica Suave',3,3,11,'2024-05-17 16:26:29','2024-05-17 22:41:49'),(2,'Madera OP',NULL,'TYU89','19%',3000.00,'0',NULL,1,'13','Madera A',2,1,48,'2024-05-17 17:24:29','2024-05-17 17:24:29'),(3,'Ceramica HY',NULL,'QWER','5%',10000.00,'0',NULL,1,'0','Ceramica Suave',3,1,10,'2024-05-17 22:40:35','2024-05-17 22:40:35'),(4,'OPYU',NULL,'ABN','5%',10000.00,'0',NULL,1,'0','Madera A',2,4,47,'2024-05-17 22:42:29','2024-05-17 22:42:29');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `purchase_suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_suppliers` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `invoice_number_purchase` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_invoice_purchase` date NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `users_id` int NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `people_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `purchase_suppliers` WRITE;
/*!40000 ALTER TABLE `purchase_suppliers` DISABLE KEYS */;
INSERT INTO `purchase_suppliers` VALUES (1,'1','2024-05-17','pos',1,1,1,'2024-05-17 16:28:02','2024-05-17 16:28:02'),(2,'1','2024-05-17','Es',1,1,1,'2024-05-17 17:25:17','2024-05-17 17:25:17');
/*!40000 ALTER TABLE `purchase_suppliers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES (1,1),(2,1),(3,1),(4,1),(5,1),(6,1),(7,1),(8,1),(9,1),(10,1),(11,1),(12,1),(13,1),(14,1),(15,1),(16,1),(17,1),(18,1),(19,1),(20,1),(5,2),(6,2),(7,2),(8,2),(9,2),(10,2),(11,2),(12,2),(13,2),(14,2),(15,2),(16,2),(17,2),(18,2),(19,2),(20,2);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Administrador','web','2024-05-17 16:22:50','2024-05-17 16:22:50'),(2,'Trabajador','web','2024-05-17 16:22:50','2024-05-17 16:22:50');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `dates` date NOT NULL,
  `bill_numbers` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sellers` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payments_methods` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gross_totals` decimal(8,2) NOT NULL,
  `taxes_total` decimal(8,2) NOT NULL,
  `net_total` decimal(8,2) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `clients_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sales_clients_id_foreign` (`clients_id`),
  CONSTRAINT `sales_clients_id_foreign` FOREIGN KEY (`clients_id`) REFERENCES `people` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` VALUES (1,'2024-05-17','Po-1','1','Efectivo',23985.00,0.00,23985.00,1,1,'2024-05-17 16:28:47','2024-05-17 16:28:47'),(2,'2024-05-17','Pre-1','1','Efectivo',21000.00,3990.00,24990.00,1,1,'2024-05-17 17:25:45','2024-05-17 17:25:45');
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sub_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sub_categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sub_categories_category_id_foreign` (`category_id`),
  CONSTRAINT `sub_categories_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `category_products` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sub_categories` WRITE;
/*!40000 ALTER TABLE `sub_categories` DISABLE KEYS */;
INSERT INTO `sub_categories` VALUES (1,'Ceramica Suave','Ceramica Suave',3,'2024-05-17 16:25:26','2024-05-17 16:25:26'),(2,'Madera A','Madera A',2,'2024-05-17 17:23:49','2024-05-17 17:23:49');
/*!40000 ALTER TABLE `sub_categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `phone_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `document_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `identification_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Brayan Pinilla','B@gmail.com',NULL,'1111111111','CC','1053442698','$2y$12$S.IgdgcG/Ke5JZT1nociDOli2wkbTmZyM289J9RsWCfLbFMDHsMaa',NULL,'2024-05-17 16:23:44','2024-05-17 16:23:44');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

